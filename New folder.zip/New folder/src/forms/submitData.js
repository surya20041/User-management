import React from "react";
import './css/style.css'
import { useFormContext } from '../button/signleButton';
import axios from "axios";



function SubmitData() {
    const { formMap } = useFormContext();

    const handleSubmit = () => {
        // Gather all form data from the context
        const allFormData = {};
        formMap.forEach((value, key) => {
            allFormData[key] = value;
        });

        const financialInstitution = allFormData.financialInstitution;
        const transactionCapabilityData = allFormData.allTransactionDetailsData;
        const flowRoute = allFormData.flowRouteData;
        const dataMapping = allFormData.dataMappingData;
        const fiId = allFormData.fiId;
        const coreConnectivitydetails = allFormData.coreConnectivityData

        axios.post('http://localhost:8083/onbording/submitData', {
            financialInstitution, transactionCapabilityData, flowRoute, dataMapping,
              coreConnectivitydetails

        }, fiId)
            .then((res) => {
                console.log(res)
            }).catch((err) => { console.log(err) })
        // console.log("all data", allFormData)
        // console.log("financialInstitution data", allFormData.financialInstitution)
        // console.log("allTransactionDetails data", allFormData.allTransactionDetailsData)
        // console.log("flowRoute data", allFormData.flowRouteData)
        // console.log("datamapping data", allFormData.dataMappingData)
        // console.log("datamapping data", allFormData.coreConnectivityData)
        // console.log("fiId", allFormData.fiId.headers)
    };

    return <>
        <div className="container">
            <div className="row" >
                <div className="submitData">
                    <h2>Submit your data</h2>
                    <button onClick={handleSubmit}>Submit All Forms</button>
                </div>
            </div>
        </div>
    </>
}

export default SubmitData;