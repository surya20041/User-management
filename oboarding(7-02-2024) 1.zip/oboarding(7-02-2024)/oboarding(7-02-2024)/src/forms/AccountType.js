import React, { useState, useEffect } from "react";
import axios from "axios";
import 'bootstrap/dist/css/bootstrap.min.css';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEye, faPencilAlt } from "@fortawesome/free-solid-svg-icons";
//import AddAccountType from "../AddAccountType.css"
import EditAccounts1 from "./EditAccountsTypes"
import AddAccountType from "./AddAccountType"
import ViewAccountType from "./ViewAccountType"

const SearchIng = () => {
  const [id, setId] = useState('');
  const [standarizedAccountType, setStandarizedAccountType] = useState('');
  const [accountType, setAccountType] = useState('');
  const [accountSubType, setAccountSubType] = useState('');
  const [accountSubType2, setAccountSubType2] = useState('');
  const [description, setDescription] = useState('');
  const [selectedValue, setSelectedValue] = useState('');
  const [dataById, setDataById] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [editItem, setEdititem] = useState({});
  const [currentPage, setCurrentPage] = useState(1);
  const[createdAt,setCreatedAt]=useState("");
  const [recordsPerPage] = useState(10); // Number of records per page
  const [errorModalVisible, setErrorModalVisible] = useState(false);
  const [errorModalVisibleDelete, setErrorModalVisibleDelete] = useState(false);
  const [viewItem, setViewItem] = useState(false);

  const options = ['standarizedAccountType', 'accountType', 'accountSubType', 'accountSubType2', 'description'];

  useEffect(() => {
    // Fetch all transaction data when the component mounts
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:8083/onbording/displayAllAccounts');
        const sortedData = Array.isArray(response.data) ? response.data.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)) : [];
        setDataById(sortedData); // Ensure the fetched data is an array
        setFilteredData(sortedData); // Set the filtered data initially to the full dataset
      } catch (error) {
        setErrorModalVisible(true)
        console.error("Error fetching data:", error);
      }
    };
    fetchData();
  }, []);

  const handleEditClick = (item) => {
    setEdititem(item);
  };



  
  const deleteItem = async (item) => {
    try {
      await axios.post("http://localhost:8083/onbording/deleteRecord", item);
      const updatedData = dataById.filter(dataItem => dataItem.id !== item.id);
      setDataById(updatedData);
      setFilteredData(updatedData);
      
    } catch (error) {
      setErrorModalVisibleDelete(true);
      console.error("Error deleting item:", error);
    }
  };
    
 
  

  

  const handleSubmit = (e) => {
    e.preventDefault();
  
    let filtered = [...dataById]; // Make a copy of dataById to preserve original data
    console.log("Initial filteredData:", filtered);
    const exactMatch = (value) => value.startsWith('"') && value.endsWith('"');
    const cleanValue = (value) => value.replace(/"/g, '');
  
    switch (selectedValue) {
      case 'standarizedAccountType':
        filtered = filtered.filter(item => {
          const searchTerm = standarizedAccountType.toLowerCase();
          if (exactMatch(searchTerm)) {
            return item.standarizedAccountType?.toLowerCase() === cleanValue(searchTerm);
          } else {
            return item.standarizedAccountType?.toLowerCase().includes(searchTerm);
          }
        });
        break;
      case 'accountType':
        filtered = filtered.filter(item => {
          const searchTerm = accountType.toLowerCase();
          if (exactMatch(searchTerm)) {
            return item.accountType?.toLowerCase() === cleanValue(searchTerm);
          } else {
            return item.accountType?.toLowerCase().includes(searchTerm);
          }
        });
        break;
      case 'accountSubType':
        filtered = filtered.filter(item => {
          const searchTerm = accountSubType.toLowerCase();
          if (exactMatch(searchTerm)) {
            return item.accountSubType?.toLowerCase() === cleanValue(searchTerm);
          } else {
            return item.accountSubType?.toLowerCase().includes(searchTerm);
          }
        });
        break;
      case 'accountSubType2':
        filtered = filtered.filter(item => {
          const searchTerm = accountSubType2.toLowerCase();
          if (exactMatch(searchTerm)) {
            return item.accountSubType2?.toLowerCase() === cleanValue(searchTerm);
          } else {
            return item.accountSubType2?.toLowerCase().includes(searchTerm);
          }
        });
        break;
      case 'description':
        filtered = filtered.filter(item => {
          const searchTerm = description.toLowerCase();
          if (exactMatch(searchTerm)) {
            return item.description?.toLowerCase() === cleanValue(searchTerm);
          } else {
            return item.description?.toLowerCase().includes(searchTerm);
          }
        });
        break;
      default:
        break;
    }
  
    setFilteredData(filtered);
    setCurrentPage(1); // Reset to first page after filtering
  };

  // Calculate the current records to display
  const indexOfLastRecord = currentPage * recordsPerPage;
  const indexOfFirstRecord = indexOfLastRecord - recordsPerPage;
  const currentRecords = filteredData.slice(indexOfFirstRecord, indexOfLastRecord);
  
  const totalPages = Math.ceil(filteredData.length / recordsPerPage);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const renderPageNumbers = () => {
    const pageNumbers = [];
    for (let i = 1; i < totalPages; i++) {
      pageNumbers.push(
        <li key={i} className={`page-item ${i === currentPage ? 'active' : ''}`}>
          <button className="page-link" onClick={() => handlePageChange(i)}>
            {i}
          </button>
        </li>
      );
    }
    return pageNumbers;
  };

  return (
    <div className="row">
       <h4>Account Types</h4>
      <div className="col-12">
        
               
          <div className="card">
            <div className="card-body">
              <div className="mb-3">
                <form onSubmit={handleSubmit} className="d-flex align-items-center">
                
                  <div className=" col-auto me-2">
                    <select
                      id="AccounTypes"
                      name="selectedValue"
                      className="form-select"
                      value={selectedValue}
                      onChange={(e) => setSelectedValue(e.target.value)}
                    >
                      <option value="">Filter</option>
                      {options.map((option, index) => (
                        <option key={index} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  </div>
                 
                
                  {selectedValue === 'id' && (
                    <div className="col-auto">
                      <input
                        type="text"
                        id="id"
                        name="id"
                        className="form-control"
                        placeholder="Search by ID"
                        value={id}
                        onChange={(e) => setId(e.target.value)}
                      />
                    </div>
                  )}
                  {selectedValue === 'standarizedAccountType' && (
                    <div className="col-auto">
                      <input
                        type="text"
                        id="standarizedAccountType"
                        name="standarizedAccountType"
                        className="form-control"
                        placeholder="Search by Standarized Account Type"
                        value={standarizedAccountType}
                        onChange={(e) => setStandarizedAccountType(e.target.value)}
                      />
                    </div>
                  )}
                  {selectedValue === 'accountType' && (
                    <div className="col-auto">
                      <input
                        type="text"
                        id="accountType"
                        name="accountType"
                        className="form-control"
                        placeholder="Search by Account Type"
                        value={accountType}
                        onChange={(e) => setAccountType(e.target.value)}
                      />
                    </div>
                  )}
                  {selectedValue === 'accountSubType' && (
                    <div className="col-auto">
                      <input
                        type="text"
                        id="accountSubType"
                        name="accountSubType"
                        className="form-control"
                        placeholder="Search by Account SubType"
                        value={accountSubType}
                        onChange={(e) => setAccountSubType(e.target.value)}
                      />
                    </div>
                  )}
                  {selectedValue === 'accountSubType2' && (
                    <div className="col-auto">
                      <input
                        type="text"
                        id="accountSubType2"
                        name="accountSubType2"
                        className="form-control"
                        placeholder="Search by Account SubType2"
                        value={accountSubType2}
                        onChange={(e) => setAccountSubType2(e.target.value)}
                      />
                    </div>
                  )}
                  {selectedValue === 'description' && (
                    <div className="col-auto">
                      <input
                        type="text"
                        id="description"
                        name="description"
                        className="form-control"
                        placeholder="Search by Description"
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                      />
                    </div>
                  )}
                  <div className="col-auto">
                    <button type="submit" className="btn btn-primary  btn-md m-2">Search</button>
                  </div>
                 
                </form>
              </div>
              <div className="mt-3 card-body">
                <table className="table table-striped text-center">
                  <thead>
                    <tr>
                      <th>S.no</th>
                      <th>Account</th>
                      <th>AccountType</th>
                      <th>SubType1</th>
                      {/* <th>SubType2</th> */}
                      <th>Description</th>
                      <th>View</th>
                      {/* <th>IsEnabled</th> */}
                      {/* <th>CreatedAt</th> */}
                      <th>Edit</th>
                      <th>Delete</th>
                    </tr>
                  </thead>
                  <tbody>
                    {currentRecords.map((item, index) => (
                      <tr key={index}>
                        <td>{item.id}</td>
                        <td>{item.standarizedAccountType}</td>
                        <td>{item.accountType}</td>
                        <td>{item.accountSubType}</td>
                        {/* <td>{item.accountSubType2}</td> */}
                       
                        <td>{item.description}</td>
                        {/* <td>{item.isEnabled ? "true" : "false"}</td> */}
                        {/* <td>{new Date(item.createdAt).toLocaleString()}</td> */}
                        {/* <td>
                          <div className="edit-btn" data-bs-toggle="modal" data-bs-target="#ViewAccount" onClick={() => handleViewClick(item)}>
                            <FontAwesomeIcon icon={faEye} />
                          </div>
                        </td> */}
                         <td>
                           <a data-bs-toggle="modal" data-bs-target="#ViewAccount" onClick={() =>handleEditClick(item) }>
                           <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-eye" viewBox="0 0 16 16">
                           <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8M1.173 8a13 13 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5s3.879 1.168 5.168 2.457A13 13 0 0 1 14.828 8q-.086.13-.195.288c-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5s-3.879-1.168-5.168-2.457A13 13 0 0 1 1.172 8z" />
                           <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5M4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0" />
                           </svg>
                          </a>
                         </td>
                         <td>
                           <a data-bs-toggle="modal" data-bs-target="#editAccount" onClick={() =>handleEditClick(item) }>
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-pencil" viewBox="0 0 16 16">
                               <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325" />
                                  </svg>
                          </a>
                         </td>
                        <td>
                         <a onClick={() => deleteItem(item)}>
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-trash" viewBox="0 0 16 16">
                            <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z" />
                               <path d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z" />
                          </svg>
                        </a>
                      </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
                {/* Pagination */}
                <nav aria-label="Page navigation">
                  <ul className="pagination justify-content-center">
                    <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                      <button className="page-link" onClick={() => handlePageChange(currentPage - 1)}>
                        Previous
                      </button>
                    </li>
                    {renderPageNumbers()}
                    <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
                      <button className="page-link" onClick={() => handlePageChange(currentPage + 1)}>
                        Next
                      </button>
                    </li>
                  </ul>
                </nav>

                {/* Edit Modal */}
                <div className="modal fade" id="editAccount" tabIndex="-1" aria-labelledby="eaccount" aria-hidden="true">
                  <div className="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
                    <div className="modal-content">
                      <div className="modal-header">
                        <h5 className="modal-title" id="Vaccount">Edit Account</h5>
                        <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div className="modal-body">
                        <EditAccounts1 editData={editItem} />
                      </div>
                    </div>
                  </div>
                </div>

                
               {/* View Modal */}
               <div className="modal fade" id="ViewAccount" tabIndex="-1" aria-labelledby="Vaccount" aria-hidden="true">
                  <div className="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
                    <div className="modal-content">
                      <div className="modal-header">
                        <h5 className="modal-title" id="Vaccount">View Account</h5>
                        <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div className="modal-body">
                        <ViewAccountType editData={editItem} />
                      </div>
                    </div>
                  </div>
                </div>


                {/* Add Modal */}
                <div className="float-end" data-bs-toggle="modal" data-bs-target="#newAccount">
                  <button type="button" className="btn btn-primary">
                    Add Account
                  </button>
                </div>
                <div className="modal fade" id="newAccount" tabIndex="-1" aria-labelledby="account" aria-hidden="true">
                  <div className="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
                    <div className="modal-content">
                      <div className="modal-header">
                        <h5 className="modal-title" id="account">Add New Account</h5>
                        <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div className="modal-body">
                        <AddAccountType />
                      </div>
                    </div>
                  </div>
                </div>

             
         
        
     
      {errorModalVisible && (
                <div className="modal fade show custom-modal box-required-size" style={{ display: "block" }} tabIndex="-1">
                    <div className="modal-dialog col-sm-3">
                        <div className="modal-content">
                            <div className="modal-header bg-danger text-white">
                                <h5 className="modal-title">Failed</h5>
                                <button type="button" className="btn-close" onClick={() => setErrorModalVisible(false)}></button>
                            </div>
                            <div className="modal-body error-res">
                                <p>Unable to add account</p>
                            </div>
                        </div>
                    </div>
                </div>
            )}

    {errorModalVisibleDelete && (
                    <div className="modal fade show custom-modal box-required-size" style={{ display: "block" }} tabIndex="-1">
                        <div className="modal-dialog col-sm-3">
                            <div className="modal-content">
                                <div className="modal-header bg-danger text-white">
                                    <h5 className="modal-title">Unable to Delete</h5>
                                    <button type="button" className="btn-close" onClick={() => setErrorModalVisibleDelete(false)}></button>
                                </div>
                                <div className="modal-body error-res">
                                    <p>Can't Delete some other values are depending on it</p>
                                </div>
                            </div>
                        </div>
                    </div>
                )}
    </div>
            </div>
            </div>
    </div>
  );
};

export default SearchIng;
