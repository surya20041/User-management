import React, { useState, useEffect } from "react";
import axios from "axios";
import 'bootstrap/dist/css/bootstrap.min.css';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPencilAlt } from "@fortawesome/free-solid-svg-icons";
import ViewTransactionDetails from "./ViewTransactionDetails"


//import EditTransactionData from './EditTransactionData';

const TransactionDataDetails = () => {
  const [fromAccountNumber, setFromAccountNumber] = useState("");
  const [rrn, setRrn] = useState("");
  const [toAccountNumber, setToAccountNumber] = useState("");
  const [instId, setInstId] = useState("");
  const [authId, setAuthId] = useState("");
  const [acquirerid, setAcquirerid] = useState("");
  const [selectedValue, setSelectedValue] = useState('');
  const [data, setData] = useState([]); // Original fetched data
  const [filteredData, setFilteredData] = useState([]); // Filtered data to display
  const [currentPage, setCurrentPage] = useState(1);
  const [recordsPerPage] = useState(10); // Number of records per page
  const [errorModalVisible, setErrorModalVisible] = useState(false);
  const [editItem, setEdititem] = useState({});

  const options = ['fromAccountNumber', 'rrn', 'toAccountNumber', 'instId', 'authId', 'acquirerid'];

  useEffect(() => {
    // Fetch all transaction data when the component mounts
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:8083/onbording/allTrnData');
        const sortedData = response.data.sort((a, b) => new Date(b.date) - new Date(a.date)); // Sort data by date in descending order
        setData(sortedData); // Set the fetched data
        setFilteredData(sortedData); // Initially, all data is displayed
      } catch (error) {
        setErrorModalVisible(true);
      }
    };
    fetchData();
  }, []);

  const handleEditClick = (item) => {
    setEdititem(item);
  };

  const handleFilter = () => {
    let filtered = data;
    const exactMatch = (value) => value.startsWith('"') && value.endsWith('"');
    const cleanValue = (value) => value.replace(/"/g, '');
  
    switch (selectedValue) {
      case 'fromAccountNumber':
        filtered = data.filter(item => {
          const searchTerm = fromAccountNumber.toLowerCase();
          if (exactMatch(searchTerm)) {
            return item.fromAccountNumber.toLowerCase() === cleanValue(searchTerm);
          } else {
            return item.fromAccountNumber.toLowerCase().includes(searchTerm);
          }
        });
        break;
      case 'rrn':
        filtered = data.filter(item => {
          const searchTerm = rrn.toLowerCase();
          if (exactMatch(searchTerm)) {
            return item.rrn.toLowerCase() === cleanValue(searchTerm);
          } else {
            return item.rrn.toLowerCase().includes(searchTerm);
          }
        });
        break;
      case 'toAccountNumber':
        filtered = data.filter(item => {
          const searchTerm = toAccountNumber.toLowerCase();
          if (exactMatch(searchTerm)) {
            return item.toAccountNumber.toLowerCase() === cleanValue(searchTerm);
          } else {
            return item.toAccountNumber.toLowerCase().includes(searchTerm);
          }
        });
        break;
      case 'instId':
        filtered = data.filter(item => {
          const searchTerm = instId.toLowerCase();
          if (exactMatch(searchTerm)) {
            return item.instId.toLowerCase() === cleanValue(searchTerm);
          } else {
            return item.instId.toLowerCase().includes(searchTerm);
          }
        });
        break;
      case 'authId':
        filtered = data.filter(item => {
          const searchTerm = authId.toLowerCase();
          if (exactMatch(searchTerm)) {
            return item.authId.toLowerCase() === cleanValue(searchTerm);
          } else {
            return item.authId.toLowerCase().includes(searchTerm);
          }
        });
        break;
      case 'acquirerid':
        filtered = data.filter(item => {
          const searchTerm = acquirerid.toLowerCase();
          if (exactMatch(searchTerm)) {
            return item.acquirerid.toLowerCase() === cleanValue(searchTerm);
          } else {
            return item.acquirerid.toLowerCase().includes(searchTerm);
          }
        });
        break;
      default:
        break;
    }
    const sortedFiltered = filtered.sort((a, b) => new Date(b.date) - new Date(a.date)); // Sort filtered data by date in descending order
    setFilteredData(sortedFiltered);
    setCurrentPage(1); // Reset to first page after filtering
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    handleFilter();
  };

  // Calculate the current records to display
  const indexOfLastRecord = currentPage * recordsPerPage;
  const indexOfFirstRecord = indexOfLastRecord - recordsPerPage;
  const currentRecords = filteredData.slice(indexOfFirstRecord, indexOfLastRecord);
  
  const totalPages = Math.ceil(filteredData.length / recordsPerPage);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const renderPageNumbers = () => {
    const pageNumbers = [];
    for (let i = 1; i <= totalPages; i++) {
      pageNumbers.push(
        <li key={i} className={`page-item ${i === currentPage ? 'active' : ''}`}>
          <button className="page-link" onClick={() => handlePageChange(i)}>
            {i}
          </button>
        </li>
      );
    }
    return pageNumbers;
  };

  return (
    <div className="row">
       <h4>TransactionData</h4>
       <div className="col-12">
        
               
        <div className="card">
          <div className="card-body">
            <div className="mb-3">
      <form onSubmit={handleSubmit} className="d-flex align-items-center">
        <div className="col-auto m-2">
          <select
            id="AccounTypes"
            name="selectedValue"
            className="form-select"
            value={selectedValue}
            onChange={(e) => setSelectedValue(e.target.value)}
          >
            <option value="">Filter</option>
            {options.map((option, index) => (
              <option key={index} value={option}>
                {option}
              </option>
            ))}
          </select>
        </div>
        <div className="col-auto">
          {selectedValue === 'fromAccountNumber' && (
            <input
              type="text"
              id="fromAccountNumber"
              name="fromAccountNumber"
              className="form-control"
              placeholder="Search by fromAccountNumber"
              value={fromAccountNumber}
              onChange={(e) => setFromAccountNumber(e.target.value)}
            />
          )}
          {selectedValue === 'rrn' && (
            <input
              type="text"
              id="rrn"
              name="rrn"
              className="form-control"
              placeholder="Search by rrn"
              value={rrn}
              onChange={(e) => setRrn(e.target.value)}
            />
          )}
          {selectedValue === 'toAccountNumber' && (
            <input
              type="text"
              id="toAccountNumber"
              name="toAccountNumber"
              className="form-control"
              placeholder="Search by toAccountNumber"
              value={toAccountNumber}
              onChange={(e) => setToAccountNumber(e.target.value)}
            />
          )}
          {selectedValue === 'instId' && (
            <input
              type="text"
              id="instId"
              name="instId"
              className="form-control"
              placeholder="Search by instId"
              value={instId}
              onChange={(e) => setInstId(e.target.value)}
            />
          )}
          {selectedValue === 'acquirerid' && (
            <input
              type="text"
              id="acquirerid"
              name="acquirerid"
              className="form-control"
              placeholder="Search by acquirerid"
              value={acquirerid}
              onChange={(e) => setAcquirerid(e.target.value)}
            />
          )}
          {selectedValue === 'authId' && (
            <input
              type="text"
              id="authId"
              name="authId"
              className="form-control"
              placeholder="Search by authId"
              value={authId}
              onChange={(e) => setAuthId(e.target.value)}
            />
          )}
        </div>
        <div className="col-auto ms-2">
          <button type="submit" className="btn btn-primary btn-md">Search</button>
        </div>
      </form>
      <div className="row mt-3">
        <div className="col">
          <table className="table table-striped text-center">
            <thead>
              <tr>
                <th>ID</th>
                <th>From Account</th>
                <th>RRN</th>
                <th>To Account </th>
                <th>Institution</th>
                <th>Auth ID</th>
                <th>Acquirer ID</th>
                <th>View</th>
                {/* <th>Amount</th> */}
                {/* <th>Terminal Id</th> */}
                {/* <th>Transaction Type</th>   */}
                {/* <th>Date</th>  */}
                {/* <th>Edit</th> */}
              </tr>
            </thead>
            <tbody>
              {currentRecords.map((item, index) => (
                <tr key={index}>
                  <td>{item.id}</td>
                  <td>{item.fromAccountNumber}</td>
                  <td>{item.rrn}</td>
                  <td>{item.toAccountNumber}</td>
                  <td>{item.instId}</td>
                  <td>{item.authId}</td>
                  <td>{item.acquirerid}</td>
                  <td>
                    <a data-bs-toggle="modal" data-bs-target="#ViewTrn" onClick={() =>handleEditClick(item) }>
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-eye" viewBox="0 0 16 16">
                      <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8M1.173 8a13 13 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5s3.879 1.168 5.168 2.457A13 13 0 0 1 14.828 8q-.086.13-.195.288c-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5s-3.879-1.168-5.168-2.457A13 13 0 0 1 1.172 8z" />
                      <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5M4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0" />
                      </svg>
                    </a>
                  </td>
                  {/* <td>{item.amount}</td> */}
                  {/* <td>{item.terminalId}</td>
                  <td>{item.transactionType}</td> */}
                  {/* <td>{new Date(item.date).toLocaleString()}</td> */}
                  {/* <td>
                    <div className="edit-btn" data-bs-toggle="modal" data-bs-target="#editTrnData" onClick={() => handleEditClick(item)}>
                      <FontAwesomeIcon icon={faPencilAlt} />
                    </div>
                  </td> */}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      {/* Pagination */}
      <nav aria-label="Page navigation">
        <ul className="pagination justify-content-center">
          <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
            <button className="page-link" onClick={() => handlePageChange(currentPage - 1)}>
              Previous
            </button>
          </li>
          {renderPageNumbers()}
          <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
            <button className="page-link" onClick={() => handlePageChange(currentPage + 1)}>
              Next
            </button>
          </li>
        </ul>
      </nav>

      {/*View Modal */}
      <div className="modal fade" id="ViewTrn" tabIndex="-1" aria-labelledby="viewTrn" aria-hidden="true">
        <div className="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title" id="viewTrn">Transaction Details</h5>
              <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div className="modal-body">
              <ViewTransactionDetails editData={editItem} />
            </div>
          </div>
        </div>
      </div>
      {/* Add Account Modal */}
      {/* <div className="float-end" data-bs-toggle="modal" data-bs-target="#newTrn">
        <button type="button" className="btn btn-primary">
          Add TransactionData
        </button>
      </div>
      <div className="modal fade" id="newTrn" tabIndex="-1" aria-labelledby="trnData" aria-hidden="true">
        <div className="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title" id="trnData">Add New TransactionData</h5>
              <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div className="modal-body">
              <AddTransactionData />
            </div>
          </div>
        </div>
      </div> */}
    </div>
    </div>
    </div>
    </div>
    </div>
  );
};

export default TransactionDataDetails;
