import React, { useState } from "react";
import axios from "axios";
import 'bootstrap/dist/css/bootstrap.min.css';
import './AddAccountType.css'; // Ensure you have appropriate CSS for styling

const AddTransactionData = () => {
    const [fromAccountNumber, setFromAccountNumber] = useState("");
    const [amount, setAmount] = useState(0);

    const [acquirerid, setAcquirerid] = useState("");
    const [transactionType, setTransactionType] = useState("");
    const [fromAccountType, setFromAccountType] = useState("");
    const [authId, setAuthId] = useState("");
    const [terminalId, setTerminalId] = useState("");
    const [instId, setInstId] = useState("");
    const [rrn, setRrn] = useState("");
    const [toAccountNumber, setToAccountNumber] = useState("");
    const [toAccountType, setToAccountType] = useState("");
    const [formDataArray, setFormDataArray] = useState([]);
    const [modalVisible, setModalVisible] = useState(false);
    const [errorModalVisible, setErrorModalVisible] = useState(false);

    const handleAddInputData = () => {
        const transactionData = {
            fromAccountNumber,
            amount,
            acquirerid,
            transactionType,
            fromAccountType,
            authId,
            terminalId,
            instId,
            rrn,
            toAccountNumber,
            toAccountType,
            date: new Date().toISOString() // Set current date
        };
        setFormDataArray([...formDataArray, transactionData]);
        setFromAccountNumber("");
        setAmount(0);
       
        setAcquirerid("");
        setTransactionType("");
        setFromAccountType("");
        setAuthId("");
        setTerminalId("");
        setInstId("");
        setRrn("");
        setToAccountNumber("");
        setToAccountType("");
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const transactionData = {
            fromAccountNumber,
            amount,
            acquirerid,
            transactionType,
            fromAccountType,
            authId,
            terminalId,
            instId,
            rrn,
            toAccountNumber,
            toAccountType,
            date: new Date().toISOString() // Set current date
        };
        const updatedFormDataArray = [...formDataArray, transactionData];
        try {
            console.log("Sending data:", updatedFormDataArray);
            const response = await axios.post("http://localhost:8083/onbording/trnDataInsert", updatedFormDataArray);
            console.log("Response received:", response.data);
            setFormDataArray([]);
            setFromAccountNumber("");
            setAmount(0);
            setAcquirerid("");
            setTransactionType("");
            setFromAccountType("");
            setAuthId("");
            setTerminalId("");
            setInstId("");
            setRrn("");
            setToAccountNumber("");
            setToAccountType("");
            setModalVisible(true);
        } catch (error) {
            console.error("There was an error adding the transaction data!", error);
            setErrorModalVisible(true);
        }
    };

    return (
        <div className="container mt-4">
            <form onSubmit={handleSubmit}>
                <div className="row mb-3">
                    <label className="col-sm-3 col-form-label font-weight-bold"><strong>From Account Number</strong></label>
                    <div className="col-sm-4">
                        <input
                            type="text"
                            className="form-control"
                            name="fromAccountNumber"
                            onChange={(e) => setFromAccountNumber(e.target.value)}
                            value={fromAccountNumber}
                            required
                        />
                    </div>
                </div>
                <div className="row mb-3">
                    <label className="col-sm-3 col-form-label font-weight-bold"><strong>From Account Type</strong></label>
                    <div className="col-sm-4">
                        <input
                            type="text"
                            className="form-control"
                            name="fromAccountType"
                            onChange={(e) => setFromAccountType(e.target.value)}
                            value={fromAccountType}
                            required
                        />
                    </div>
                </div>
                <div className="row mb-3">
                    <label className="col-sm-3 col-form-label font-weight-bold"><strong>To Account Number</strong></label>
                    <div className="col-sm-4">
                        <input
                            type="text"
                            className="form-control"
                            name="toAccountNumber"
                            onChange={(e) => setToAccountNumber(e.target.value)}
                            value={toAccountNumber}
                        />
                    </div>
                </div>
                <div className="row mb-3">
                    <label className="col-sm-3 col-form-label font-weight-bold"><strong>To Account Type</strong></label>
                    <div className="col-sm-4">
                        <input
                            type="text"
                            className="form-control"
                            name="toAccountType"
                            onChange={(e) => setToAccountType(e.target.value)}
                            value={toAccountType}
                        />
                    </div>
                </div>
                <div className="row mb-3">
                    <label className="col-sm-3 col-form-label font-weight-bold"><strong>Acquirer ID</strong></label>
                    <div className="col-sm-4">
                        <input
                            type="text"
                            className="form-control"
                            name="acquirerid"
                            onChange={(e) => setAcquirerid(e.target.value)}
                            value={acquirerid}
                            required
                        />
                    </div>
                </div>
                <div className="row mb-3">
                    <label className="col-sm-3 col-form-label font-weight-bold"><strong>Inst ID</strong></label>
                    <div className="col-sm-4">
                        <input
                            type="text"
                            className="form-control"
                            name="instId"
                            onChange={(e) => setInstId(e.target.value)}
                            value={instId}
                        />
                    </div>
                </div>
                <div className="row mb-3">
                    <label className="col-sm-3 col-form-label font-weight-bold"><strong>Auth ID</strong></label>
                    <div className="col-sm-4">
                        <input
                            type="text"
                            className="form-control"
                            name="authId"
                            onChange={(e) => setAuthId(e.target.value)}
                            value={authId}
                        />
                    </div>
                </div>
                <div className="row mb-3">
                    <label className="col-sm-3 col-form-label font-weight-bold"><strong>RRN</strong></label>
                    <div className="col-sm-4">
                        <input
                            type="text"
                            className="form-control"
                            name="rrn"
                            onChange={(e) => setRrn(e.target.value)}
                            value={rrn}
                        />
                    </div>
                </div>
                <div className="row mb-3">
                    <label className="col-sm-3 col-form-label font-weight-bold"><strong>Terminal ID</strong></label>
                    <div className="col-sm-4">
                        <input
                            type="text"
                            className="form-control"
                            name="terminalId"
                            onChange={(e) => setTerminalId(e.target.value)}
                            value={terminalId}
                        />
                    </div>
                </div>
                <div className="row mb-3">
                    <label className="col-sm-3 col-form-label font-weight-bold"><strong>Transaction Type</strong></label>
                    <div className="col-sm-4">
                        <input
                            type="text"
                            className="form-control"
                            name="transactionType"
                            onChange={(e) => setTransactionType(e.target.value)}
                            value={transactionType}
                            required
                        />
                    </div>
                </div>
                <div className="row mb-3">
                    <label className="col-sm-3 col-form-label font-weight-bold"><strong>Amount</strong></label>
                    <div className="col-sm-4">
                        <input
                            type="number"
                            className="form-control"
                            name="amount"
                            onChange={(e) => setAmount(parseFloat(e.target.value))}
                            value={amount}
                            required
                        />
                    </div>
                </div>

                <div className="row mb-3">
                    <div className="col-sm-4 offset-sm-3 d-flex justify-content-between">
                        <button type="button" className="btn btn-secondary" onClick={handleAddInputData}>Add Another Transaction</button>
                        <button type="submit" className="btn btn-primary">Submit</button>
                    </div>
                </div>
            </form>

            {modalVisible && (
                <div className="modal fade show custom-modal  box-required-size" style={{ display: "block" }} tabIndex="-1">
                    <div className="modal-dialog col-sm-3">
                        <div className="modal-content">
                            <div className="modal-header bg-success text-white">
                                <h5 className="modal-title">Added</h5>
                                <button type="button" className="btn-close" onClick={() => setModalVisible(false)}></button>
                            </div>
                            <div className="modal-body success.res">
                                <p>Account successfully added</p>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {errorModalVisible && (
                <div className="modal fade show  custom-modal box-required-size" style={{ display: "block" }} tabIndex="-1">
                    <div className="modal-dialog col-sm-3">
                        <div className="modal-content">
                            <div className="modal-header bg-danger text-white">
                                <h5 className="modal-title">Failed</h5>
                                <button type="button" className="btn-close" onClick={() => setErrorModalVisible(false)}></button>
                            </div>
                            <div className="modal-body error-res">
                                <p>Unable to add account</p>
                            </div>
                        </div>
                    </div>
                </div>
            )}
    </div>
)};
export default AddTransactionData;
