import React, { useState } from "react";
import axios from "axios";
import 'bootstrap/dist/css/bootstrap.min.css';
import './AddAccountType.css';

const AddAccountType = () => {
    const [standarizedAccountType, setStandarizedAccountType] = useState("");
    const [accountType, setAccountType] = useState("");
    const [accountSubType, setAccountSubType] = useState("");
    const [accountSubType2, setAccountSubType2] = useState("");
    const [description, setDescription] = useState("");
    const [isEnabled, setIsEnabled] = useState(false);
    const [formDataArray, setFormDataArray] = useState([]);
    const [modalVisible, setModalVisible] = useState(false);
    const [errorModalVisible, setErrorModalVisible] = useState(false);

    const handleAddInputData = () => {
        const accountData = {
            standarizedAccountType,
            accountType,
            accountSubType,
            accountSubType2,
            description,
            isEnabled,
            createdAt: new Date().toISOString() // Set current date
        };
        setFormDataArray([...formDataArray, accountData]);
        setStandarizedAccountType("");
        setAccountType("");
        setAccountSubType("");
        setAccountSubType2("");
        setDescription("");
        setIsEnabled(false);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const accountData = {
            standarizedAccountType,
            accountType,
            accountSubType,
            accountSubType2,
            description,
            isEnabled,
            createdAt: new Date().toISOString() // Set current date
        };
        const updatedFormDataArray = [...formDataArray, accountData];
        try {
          //  console.log("Sending data:", updatedFormDataArray);
            const response = await axios.post("http://localhost:8083/onbording/addAccountType", updatedFormDataArray);
          //  console.log("Response received:", response.data);
            setFormDataArray([]);
            setStandarizedAccountType("");
            setAccountType("");
            setAccountSubType("");
            setAccountSubType2("");
            setDescription("");
            setIsEnabled(false);
            setModalVisible(true);
        } catch (error) {
            console.error("There was an error adding the account type!", error);
            setErrorModalVisible(true);
        }
    };

    return (
        <div className="col-lg-12">
            <form onSubmit={handleSubmit}>
                <div className="row">
                    <div className="col-12 col-lg-4 mb-3">
                    <label className="form-label">Standarized Account Type<span className="text-danger">*</span></label>
                    <input
                            type="text"
                            className="form-control"
                            name="standarizedAccountType"
                            onChange={(e) => setStandarizedAccountType(e.target.value)}
                            value={standarizedAccountType}
                            required
                        />
                </div>
                <div className="col-12 col-lg-4 mb-3">
                    <label className="form-label">Account Type<span className="text-danger">*</span></label>
                    <input
                            type="text"
                            className="form-control"
                            name="accountType"
                            onChange={(e) => setAccountType(e.target.value)}
                            value={accountType}
                            required
                        />
                </div>
                <div className="col-12 col-lg-4 mb-3">
                    <label className="form-label">Account SubType<span className="text-danger">*</span></label>
                        <input
                            type="text"
                            className="form-control"
                            name="accountSubType"
                            onChange={(e) => setAccountSubType(e.target.value)}
                            value={accountSubType}
                            required
                        />
                </div>
                <div className="col-12 col-lg-4 mb-3">
                    <label className="form-label">Account SubType2</label>
                        <input
                            type="text"
                            className="form-control"
                            name="accountSubType2"
                            onChange={(e) => setAccountSubType2(e.target.value)}
                            value={accountSubType2}
                        />
                </div>
                <div className="col-12 col-lg-4 mb-3">
                    <label className="form-label">Description<span className="text-danger">*</span></label>
                        <input
                            type="text"
                            className="form-control"
                            name="description"
                            onChange={(e) => setDescription(e.target.value)}
                            value={description}
                            required
                        />
                </div>
                <div className="col-12 col-lg-4 mt-4 mb-3 form-check radio-enable text-center">
                    <label className="form-check-label">
                        <input
                            type="radio"
                            className="form-check-input"
                            onChange={(e) => setIsEnabled(e.target.checked)}
                            checked={isEnabled}
                            required
                        />Is Enabled<span className="text-danger">*</span>
                        </label>
                </div>
                    <div className="col-12 mt-4 text-right two-btns">
                        <button type="button" className="btn btn-secondary" onClick={handleAddInputData}>Add Another Account</button>
                        <button type="submit" className="btn btn-info">Submit</button>
                    </div>
                </div>
            </form>

            {modalVisible && (
                <div className="modal fade show custom-modal  box-required-size" style={{ display: "block" }} tabIndex="-1">
                    <div className="modal-dialog col-sm-3">
                        <div className="modal-content">
                            <div className="modal-header bg-success text-white">
                                <h5 className="modal-title">Added</h5>
                                <button type="button" className="btn-close" onClick={() => setModalVisible(false)}></button>
                            </div>
                            <div className="modal-body success.res">
                                <p>Account successfully added</p>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {errorModalVisible && (
                <div className="modal fade show custom-modal box-required-size" style={{ display: "block" }} tabIndex="-1">
                    <div className="modal-dialog col-sm-3">
                        <div className="modal-content">
                            <div className="modal-header bg-danger text-white">
                                <h5 className="modal-title">Failed</h5>
                                <button type="button" className="btn-close" onClick={() => setErrorModalVisible(false)}></button>
                            </div>
                            <div className="modal-body error-res">
                                <p>Unable to add account</p>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default AddAccountType;
