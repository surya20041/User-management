import React, { useState, useEffect } from 'react';
import './css/style.css';
// import { useLocation, useNavigate } from 'react-router-dom';
import { useFormContext } from '../button/signleButton';  
import axios from 'axios';

function FlowRoute({ onSubmitClick, fiId }) {
  const { updateForm } = useFormContext();
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({

    financialInstitutionId: '',
    operation_type: '',
    flowName: '',
    isEnabled: false,
    createdAt: ''
  });
  // const location = useLocation();
  // const navigate = useNavigate();
  // const { financial_institution_id = '', a = '' } = location.state || {};

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prevFormData) => ({
      ...prevFormData,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  // useEffect(() => {
  //   setFormData((prevFormData) => ({
  //     ...prevFormData
    
  //   }));
  // }, [fiId, a]);

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form submitted with data:", formData);

  };

  const submitFlowRoute = (e) => {
    e.preventDefault();
   // console.log(a);
    // const headers = {
    //   'fiId': a
    // };
    updateForm('flowRouteData', [formData]);
   // updateForm('fiId', {headers}); 
    onSubmitClick("data-mapping");
   // navigate('/data-mapping', { state: { financial_institution_id, a } })
    // axios.post("http://localhost:8083/onbording/flowRoute", [formData], { headers })
    //   .then((res) => {
    //     navigate('/data-mapping', { state: { financial_institution_id, a } })
    //     console.log(res)
    //   })
    //   .catch((err) => console.log(err));
  };


  return (
    <div className="main-section">
      <div className='row'>

     
       <div className="col-12 mt-3 mb-3">
          <b><p className="form-label">Financial Institution: {fiId}</p></b>
        </div>
      
      {!showForm &&
        <div className="col-12 text-center two-btns">
           <button onClick={(e) => submitFlowRoute(e)} className="btn btn-info ">next</button>
          <button onClick={() => setShowForm(true)} className="btn btn-secondary ">add Script</button>         
        </div>}


      {showForm && (

        <form onSubmit={handleSubmit} style={{ marginTop: '20px' }}>
          <div className='row'>

            <div className='col-12 col-lg-3 mb-3'>
              <label className="form-label">Operation Type<span className="text-danger">*</span></label>
              <input
                type="text"
                name="operation_type"
                 className="form-control form-control-lg"
                value={formData.operation_type}
                onChange={handleChange}
                required
              />
            </div>
            <div className='col-12 col-lg-3 mb-3'>
              <label className="form-label">Flow Name<span className="text-danger">*</span></label>
              <input
                type="text"
                name="flowName"
                 className="form-control form-control-lg"
                value={formData.flowName}
                onChange={handleChange}
                required
              />
            </div>

            <div className='col-12 col-lg-3 mb-3 '>
              <label className="form-label">Created At<span className="text-danger">*</span></label>
              <input
                type="date"
                 className="form-control form-control-lg"
                name="createdAt"
                value={formData.createdAt}
                onChange={handleChange}
                required
              />
            </div>
            <div className='col-12 col-lg-3 form-check mt-4 mb-3 radio-enable text-center'>
            <label  className="form-check-label">
              <input
                type="checkbox"
                className="form-check-input"
                name="isEnabled"
                checked={formData.isEnabled}
                onChange={handleChange}
              />
              Active<span className="text-danger">*</span></label>
            </div>
            <div className="col-12 text-right">
              <button type="submit" className="btn btn-info">next</button>
            </div>

          </div>
        </form>

      )}
      {/* </div> */}
    </div>
    </div>
  );
}

export default FlowRoute;
