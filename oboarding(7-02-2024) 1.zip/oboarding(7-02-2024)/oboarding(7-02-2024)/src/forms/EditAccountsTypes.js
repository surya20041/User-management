import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import './AddAccountType.css';

const EditAccounts1 = ({ editData }) => {
    const [account, setAccount] = useState({});
    const navigate = useNavigate();
    const [modalVisible, setModalVisible] = useState(false);
    const [errorModalVisible, setErrorModalVisible] = useState(false);

    useEffect(() => {
        setAccount(editData);
    }, [editData]);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setAccount({ ...account, [name]: value });
    };

    const handleCheckboxChange = (e) => {
        setAccount({ ...account, isEnabled: e.target.checked });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        // Set the createdAt field to the current date
        const updatedAccount = { ...account, createdAt: new Date().toISOString() };

        axios.put(`http://localhost:8083/onbording/editData`, updatedAccount)
            .then((res) => {
                setModalVisible(true);
                setAccount({});
                navigate('/');
            })
            .catch((err) => {
                setErrorModalVisible(true);
            });
    };

    return (
        <div className="col-lg-12">
                    <form onSubmit={handleSubmit}>
                    <div className="row">
                        <div className="col-12 col-lg-4 mb-3">
                            <label className="form-label">Standardized Account Type<span className="text-danger">*</span></label>
                            <input
                                    type="text"
                                    className="form-control"
                                    name="standarizedAccountType"
                                    value={account.standarizedAccountType || ""}
                                    onChange={handleInputChange}
                                    required
                                />
                        </div>
                        <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Account Type<span className="text-danger">*</span></label>
                                <input
                                    type="text"
                                    className="form-control"
                                    name="accountType"
                                    value={account.accountType || ""}
                                    onChange={handleInputChange}
                                    required
                                />
                            </div>
                        
                            <div className="col-12 col-lg-4 mb-3">
                            <label className="form-label">Account SubType1<span className="text-danger">*</span></label>
                           
                                <input
                                    type="text"
                                    className="form-control"
                                    name="accountSubType"
                                    value={account.accountSubType || ""}
                                    onChange={handleInputChange}
                                    required
                                />
                            
                        </div>
                        <div className="col-12 col-lg-4 mb-3">
                            <label className="form-label">Account SubType2</label>
                            
                                <input
                                    type="text"
                                    className="form-control"
                                    name="accountSubType2"
                                    value={account.accountSubType2 || ""}
                                    onChange={handleInputChange}
                                />
                            </div>
                      
                        <div className="col-12 col-lg-4 mb-3">
                            <label className="form-label">Description<span className="text-danger">*</span></label>
                                <input
                                    type="text"
                                    className="form-control"
                                    name="description"
                                    value={account.description || ""}
                                    onChange={handleInputChange}
                                    required
                                />
                        </div>
                        <div className="col-12 col-lg-4 mt-4 mb-3 form-check radio-enable text-center">
                            <label className="form-check-label">
                                <input
                                    type="radio"
                                    name="isEnabled"
                                    className="form-check-input"
                                    checked={account.isEnabled || false}
                                    onChange={handleCheckboxChange}
                                    required
                                />Is Enabled
                                </label>
                        </div>
                        <div className="col-12 mt-4 text-right">
                        <button className="btn btn-info" type="submit">Save</button>
                        </div>
                        </div>
                    </form>
                    {modalVisible && (
                        <div className="modal fade show custom-modal box-required-size" style={{ display: "block" }} tabIndex="-1">
                            <div className="modal-dialog col-sm-3">
                                <div className="modal-content">
                                    <div className="modal-header bg-success text-white">
                                        <h5 className="modal-title">Updated</h5>
                                        <button type="button" className="btn-close" onClick={() => setModalVisible(false)}></button>
                                    </div>
                                    <div className="modal-body success.res">
                                        <p>Account successfully updated</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}
                    {errorModalVisible && (
                        <div className="modal fade show custom-modal box-required-size" style={{ display: "block" }} tabIndex="-1">
                            <div className="modal-dialog col-sm-3">
                                <div className="modal-content">
                                    <div className="modal-header bg-danger text-white">
                                        <h5 className="modal-title">Failed</h5>
                                        <button type="button" className="btn-close" onClick={() => setErrorModalVisible(false)}></button>
                                    </div>
                                    <div className="modal-body error-res">
                                        <p>Unable to update account</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
    );
};

export default EditAccounts1;
