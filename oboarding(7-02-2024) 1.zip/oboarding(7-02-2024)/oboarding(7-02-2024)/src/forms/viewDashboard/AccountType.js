import React, { useState, useEffect } from "react";
import axios from "axios";
import 'bootstrap/dist/css/bootstrap.min.css';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPencilAlt } from "@fortawesome/free-solid-svg-icons";
import { Link, useNavigate } from "react-router-dom";
import AddAccountType from "../AddAccountType";

const SearchIng = () => {
  const [id, setId] = useState(0);
  const [standarizedAccountType, setStandarizedAccountType] = useState("");
  const [accountType, setAccountType] = useState("");
  const [accountSubType, setAccountSubType] = useState("");
  const [accountSubType2, setAccountSubType2] = useState("");
  const [description, setDescription] = useState("");
  const [selectedValue, setSelectedValue] = useState('');
  const [dataById, setDataById] = useState([]);
  const [isEnabled, setIsEnabled] = useState(false);
  const [createdAt, setCreatedAt] = useState("");
  const options = ['standarizedAccountType', 'accountType', 'description'];
  const navigate = useNavigate(); // Initialize useNavigate hook

  useEffect(() => {
    // Fetch all transaction data when the component mounts
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:8083/onbording/displayAllAccounts');
        setDataById(Array.isArray(response.data) ? response.data : []); // Ensure the fetched data is an array
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
    fetchData();
  }, []);

  const handleEditClick = (item) => {
    navigate('/editAccounts', { state: { item } });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    let endpoint = '';
    let param = '';

    switch (selectedValue) {
      case 'id':
        endpoint = 'findById';
        param = `id=${id}`;
        break;
      case 'standarizedAccountType':
        endpoint = 'findByStandarizedAccountType';
        param = `standarizedAccountType=${standarizedAccountType}`;
        break;
      case 'accountType':
        endpoint = 'findByaccountType';
        param = `accountType=${accountType}`;
        break;
      case 'accountSubType':
        endpoint = 'findByAccountSubType';
        param = `accountSubType=${accountSubType}`;
        break;
      case 'accountSubType2':
        endpoint = 'findByAccountSubType2';
        param = `accountSubType2=${accountSubType2}`;
        break;
      case 'description':
        endpoint = 'findByDes';
        param = `des=${description}`;
        break;
      default:
        break;
    }

    try {
      const response = await axios.get(`http://localhost:8083/onbording/${endpoint}?${param}`);
      setDataById(Array.isArray(response.data) ? response.data : []); // Ensure the fetched data is an array
      alert("Data found!");
    } catch (error) {
      console.error("Error fetching data:", error);
      alert("There was an error fetching data!");
    }
  };

  return (

  
   
    <div className="row">
        <div className="col-12">
            <div className="card">
               
                <div className="card-body">
               
        <div className=" mb-3">
          <form onSubmit={handleSubmit} className="d-flex align-items-center">
            <div className="col-auto me-2">
              <select
                id="AccounTypes"
                name="id"
                className="form-select"
                value={selectedValue}
                onChange={(e) => setSelectedValue(e.target.value)}
              >
                <option value="">Filter</option>
                {options.map((option, index) => (
                  <option key={index} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </div>
            {selectedValue === 'id' && (
              <div className="col-auto">
                <input
                  type="text"
                  id="id"
                  name="id"
                  className="form-control"
                  placeholder="Search by ID"
                  value={id}
                  onChange={(e) => setId(e.target.value)}
                />
              </div>
            )}
            {selectedValue === 'standarizedAccountType' && (
              <div className="col-auto">
                <input
                  type="text"
                  id="standarizedAccountType"
                  name="standarizedAccountType"
                  className="form-control"
                  placeholder="Search by Standarized Account Type"
                  value={standarizedAccountType}
                  onChange={(e) => setStandarizedAccountType(e.target.value)}
                />
              </div>
            )}
            {selectedValue === 'accountType' && (
              <div className="col-auto">
                <input
                  type="text"
                  id="accountType"
                  name="accountType"
                  className="form-control"
                  placeholder="Search by Account Type"
                  value={accountType}
                  onChange={(e) => setAccountType(e.target.value)}
                />
              </div>
            )}
            {selectedValue === 'description' && (
              <div className="col-auto">
                <input
                  type="text"
                  id="description"
                  name="description"
                  className="form-control"
                  placeholder="Search by Description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                />
              </div>
            )}
            <div className="col-auto">
              <button type="submit" className="btn btn-primary btn-md m-2">Search</button>
            </div>
          </form>
        </div>
        <div className=" mt-3">
            <table className="table table-striped">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>StandarizedAccountType</th>
                  <th>AccountType</th>
                  <th>AccountSubType</th>
                  <th>AccountSubType2</th>
                  <th>Description</th>
                  <th>IsEnabled</th>
                  <th>CreatedAt</th>
                  <th>Edit</th>
                </tr>
              </thead>
              <tbody>
                {Array.isArray(dataById) && dataById.map((item, index) => (
                  <tr key={index}>
                    <td>{item.id}</td>
                    <td>{item.standarizedAccountType}</td>
                    <td>{item.accountType}</td>
                    <td>{item.accountSubType}</td>
                    <td>{item.accountSubType2}</td>
                    <td>{item.description}</td>
                    <td>{item.isEnabled ? "true" : "false"}</td>
                    <td>{new Date(item.createdAt).toLocaleString()}</td>
                    <td>
                      <div className="edit-btn" onClick={() => handleEditClick(item)}>
                        <FontAwesomeIcon icon={faPencilAlt} />
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table> 
            <div className="float-end" data-bs-toggle="modal" data-bs-target="#newAccount" >
            <button type="button" className="btn btn-primary">
                Add Account
            </button>
            </div>
            <div className="modal fade" id="newAccount" tabindex="-1" aria-labelledby="account" aria-hidden="true">
            <div className="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
                <div className="modal-content">
                    <div className="modal-header">
                        <h5 className="modal-title" id="account">Add New Account</h5>
                        <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div className="modal-body">
                        
                        <AddAccountType/>
                      
                    </div>
                </div>
            </div>
        </div>
        
        </div>
      </div>            
            </div>
        </div>
    </div>





  );
};

export default SearchIng;
