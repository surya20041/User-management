import React, { useEffect, useState, useCallback } from 'react';
import axios from 'axios';
import AddDataForm from './AddDataForm';
import EditDataForm from './EditDataForm';
// import { useNavigate } from 'react-router-dom';
 
const ViewData = () => {
    const [allData, setAllData] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);
    const [editingItem, setEditingItem] = useState(null);
    const [viewingItem, setViewingItem] = useState(null);
    const [showAddModal, setShowAddModal] = useState(false);
    const [showEditModal, setShowEditModal] = useState(false);
    const [showViewModal, setShowViewModal] = useState(false);
    const [selectedFilter, setSelectedFilter] = useState('');
    const [searchQuery, setSearchQuery] = useState('');
    const itemsPerPage = 100;
    // const navigate = useNavigate();
 
    const fetchData = useCallback(async () => {
        setIsLoading(true);
        setError(null);
        setSearchQuery('');
        setSelectedFilter('');
        try {
            const response = await axios.get('http://localhost:8083/onbording/all-app-properties');
            console.log('API Response:', response.data);
 
            if (Array.isArray(response.data)) {
                setAllData(response.data);
            } else {
                throw new Error('Invalid data format received from server');
            }
        } catch (error) {
            console.error('Failed to fetch data:', error);
            setError('Failed to load data. Please try again later.');
            setAllData([]);
        } finally {
            setIsLoading(false);
        }
    }, []);
 
    useEffect(() => {
        fetchData();
    }, [fetchData]);
 
    const handlePageChange = (newPage) => {
        setCurrentPage(newPage);
    };
 
    const handleEdit = (item) => {
        setEditingItem(item);
        setShowEditModal(true);
    };
 
    const handleView = (item) => {
        setViewingItem(item);
        setShowViewModal(true);
    };
 
    const handleUpdate = async (updatedItem) => {
        try {
            await axios.put(`http://localhost:8083/onbording/edit/${updatedItem.id}`, updatedItem);
            setEditingItem(null);
            setShowEditModal(false);
            fetchData();
        } catch (error) {
            console.error('Failed to update item:', error);
        }
    };
 
    const handleAdd = () => {
        fetchData();
        setShowAddModal(false);
    };
 
    const handleSearch = () => {
        if (selectedFilter && searchQuery) {
            const filteredData = allData.filter(item => {
                const value = item[selectedFilter]?.toLowerCase();
                return value?.includes(searchQuery.toLowerCase());
            });
            setAllData(filteredData);
        }
    };
 
    const totalPages = Math.ceil(allData.length / itemsPerPage);
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const currentData = allData.slice(startIndex, endIndex);
 
    if (isLoading) return <div>Loading...</div>;
    if (error) return <div>{error}</div>;
 
    return (
        <div>
            <h1 className="h3 mb-3">Application Properties</h1>
            <div className="row">
                <div className="col-12">
                    <div className="card">
                        <div className="card-body">
                            <div className="mb-3 d-flex">
                                <select
                                    className="form-select me-2"
                                    style={{width: 'auto'}}
                                    value={selectedFilter}
                                    onChange={(e) => {
                                        setSelectedFilter(e.target.value);
                                        setSearchQuery('');
                                    }}
                                >
                                    <option value="">Select Filter</option>
                                    <option value="env">Environment</option>
                                    <option value="appName">Application Name</option>
                                    <option value="propKey">Property Key</option>
                                    <option value="propVal">Property Value</option>
                                </select>
                                {selectedFilter && (
                                    <input
                                        type="text"
                                        className="form-control me-2"
                                        placeholder={`Search ${selectedFilter}...`}
                                        value={searchQuery}
                                        onChange={(e) => setSearchQuery(e.target.value)}
                                        style={{width: 'auto'}}
                                    />
                                )}
                                <button className="btn btn-primary" onClick={handleSearch} disabled={!selectedFilter || !searchQuery}>Search</button>
                            </div>
                            {currentData.length > 0 ? (
                                <>
                                    <div className="table-responsive">
                                        <table className="table table-striped table-hover">
                                            <thead className="thead-light">
                                                <tr>
                                                    <th>ID</th>
                                                    <th>Application Name</th>
                                                    <th>Environment</th>
                                                    <th>Property Key</th>
                                                    <th>Created Date</th>
                                                    <th>Modified Date</th>
                                                    <th>Created By</th>
                                                    <th>Modified By</th>
                                                    <th>Edit</th>
                                                    <th>View</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {currentData.map((item) => (
                                                    <tr key={item.id}>
                                                        <td>{item.id}</td>
                                                        <td>{item.appName}</td>
                                                        <td>{item.env}</td>
                                                        <td>{item.propKey}</td>
                                                        <td>{item.createdDate}</td>
                                                        <td>{item.modifiedDate}</td>
                                                        <td>{item.createdBy}</td>
                                                        <td>{item.modifiedBy}</td>
                                                        <td>
                                                            <button className="btn btn-sm" onClick={() => handleEdit(item)}>
                                                                <i className="fas fa-pencil-alt"></i>
                                                            </button>
                                                        </td>
                                                        <td>
                                                            <button className="btn btn-sm" onClick={() => handleView(item)}>
                                                                <i className="fas fa-eye"></i>
                                                            </button>
                                                        </td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                    <div className="d-flex justify-content-between align-items-center mb-3 mt-4">
                                        <div>
                                            <button className="btn btn-secondary me-2" onClick={() => handlePageChange(currentPage - 1)} disabled={currentPage === 1}>
                                                Previous
                                            </button>
                                            <span> Page {currentPage} of {totalPages} </span>
                                            <button className="btn btn-secondary ms-2" onClick={() => handlePageChange(currentPage + 1)} disabled={currentPage === totalPages}>
                                                Next
                                            </button>
                                        </div>
                                        <div className="float-end" data-bs-toggle="modal" data-bs-target="#newappproperties">
                                            <button type="button" className="btn btn-info">
                                                Add Properties
                                            </button>
                                        </div>
                                    </div>
                                    <div className="modal fade" id="newappproperties" tabIndex="-1" aria-labelledby="Institution" aria-hidden="true">
                                        <div className="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
                                            <div className="modal-content">
                                                <div className="modal-header">
                                                    <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div className="modal-body">
                                                    <AddDataForm />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </>
                            ) : (
                                <p>No data available.</p>
                            )}
                        </div>
                    </div>
                </div>
            </div>
           
            {/* Edit Modal */}
            <div className={`modal fade ${showEditModal ? 'show' : ''}`} id="editModal" tabIndex="-1" aria-labelledby="editModalLabel" aria-hidden={!showEditModal} style={{display: showEditModal ? 'block' : 'none'}}>
                <div className="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
                    <div className="modal-content">
                        <div className="modal-header">
                            <button type="button" className="btn-close" onClick={() => setShowEditModal(false)} aria-label="Close"></button>
                        </div>
                        <div className="modal-body">
                            {editingItem && (
                                <EditDataForm
                                    data={editingItem}
                                    onUpdate={handleUpdate}
                                    onCancel={() => setShowEditModal(false)}
                                />
                            )}
                        </div>
                    </div>
                </div>
            </div>
            {showEditModal && <div className="modal-backdrop fade show"></div>}
 
            {/* View Modal */}
            {showViewModal && (
                <div className="modal fade show" id="viewModal" tabIndex="-1" aria-labelledby="viewModalLabel" aria-hidden="false" style={{display: 'block'}}>
                    <div className="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title" id="viewModalLabel">View App Properties</h5>
                                <button type="button" className="btn-close" onClick={() => setShowViewModal(false)} aria-label="Close"></button>
                            </div>
                            <div className="modal-body">
                                {viewingItem && (
                                    <table className="table table-bordered">
                                        <tbody>
                                            <tr>
                                                <th>ID</th>
                                                <td>{viewingItem.id}</td>
                                            </tr>
                                            <tr>
                                                <th>Application Name</th>
                                                <td>{viewingItem.appName}</td>
                                            </tr>
                                            <tr>
                                                <th>Environment</th>
                                                <td>{viewingItem.env}</td>
                                            </tr>
                                            <tr>
                                                <th>Property Key</th>
                                                <td>{viewingItem.propKey}</td>
                                            </tr>
                                            <tr>
                                                <th>Property Value</th>
                                                <td>{viewingItem.propVal}</td>
                                            </tr>
                                            <tr>
                                                <th>Last Modified Time</th>
                                                <td>{viewingItem.lastModifiedTime}</td>
                                            </tr>
                                            <tr>
                                                <th>Created Date</th>
                                                <td>{viewingItem.createdDate}</td>
                                            </tr>
                                            <tr>
                                                <th>Modified Date</th>
                                                <td>{viewingItem.modifiedDate}</td>
                                            </tr>
                                            <tr>
                                                <th>Created By</th>
                                                <td>{viewingItem.createdBy}</td>
                                            </tr>
                                            <tr>
                                                <th>Modified By</th>
                                                <td>{viewingItem.modifiedBy}</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            )}
            {showViewModal && <div className="modal-backdrop fade show"></div>}
        </div>
    );
};
 
export default ViewData;