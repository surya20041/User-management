import React, { useState, useEffect } from "react";
import axios from "axios";
import 'bootstrap/dist/css/bootstrap.min.css';
import CoreConnectivity from "./CoreConnectivity";
import EditCoreConnectivity from "./EditCoreConnectivity";
import AddCoreConnectivity from "./AddCoreConnectivity";
import ViewCoreConnectivity from "./ViewCoreConnectivity";

const CoreConnectivityDetails = () => {
  const [data, setData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [searchField, setSearchField] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [recordsPerPage] = useState(10); // Number of records per page
  const [errorModalVisible, setErrorModalVisible] = useState(false);
  const [editItem, setEdititem] = useState({});
  const [errorModalVisibleDelete, setErrorModalVisibleDelete] = useState(false);
  const [deletedModalVisible,setDeletedModalVisible] = useState(false)
  const fields = [
    'financialInstitutionId', 'coreName', 'host', 'port', 'basepath', 'messageId', 'branchId',
    'processorUser', 'deviceType', 'deviceNumber', 'userName',
    'findbyServicePath', 'accountServicePath', 'transactionServicePath'
  ];

  useEffect(() => {
    // Fetch all data when the component mounts
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:8083/onbording/coreAllData');
        const sortedData = Array.isArray(response.data) ? response.data.sort((a, b) => new Date(b.createdDate) - new Date(a.createdDate)) : [];
        setData(sortedData); // Ensure the fetched data is an array
        setFilteredData(sortedData); // Set the filtered data initially to the full dataset
      } catch (error) {
        setErrorModalVisible(true);
        console.error("Error fetching data:", error);
      }
    };
    fetchData();
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    const cleanValue = (value) => value.replace(/"/g, '');

    const filtered = data.filter(item => {
      const value = item[searchField]?.toString().toLowerCase();
      const term = cleanValue(searchTerm.toLowerCase());
      return value && value.includes(term);
    });

    setFilteredData(filtered);
    setCurrentPage(1); // Reset to first page after filtering
  };

  const handleEditClick = (item) => {
    setEdititem(item);
  };

  const deleteItem = async (item) => {
    try {
      await axios.post("http://localhost:8083/onbording/deleteCoreData", item);
       const updatedData = dataById.filter(dataItem => dataItem.id !== item.id);
      setDataById(updatedData);
      setFilteredData(updatedData);
      setDeletedModalVisible(true)
      
    } catch (error) {
      setErrorModalVisibleDelete(true);
      console.error("Error deleting item:", error);
    }
  };


  // Calculate the current records to display
  const indexOfLastRecord = currentPage * recordsPerPage;
  const indexOfFirstRecord = indexOfLastRecord - recordsPerPage;
  const currentRecords = filteredData.slice(indexOfFirstRecord, indexOfLastRecord);
  const totalPages = Math.ceil(filteredData.length / recordsPerPage);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const renderPageNumbers = () => {
    const pageNumbers = [];
    for (let i = 1; i <= totalPages; i++) {
      pageNumbers.push(
        <li key={i} className={`page-item ${i === currentPage ? 'active' : ''}`}>
          <button className="page-link" onClick={() => handlePageChange(i)}>
            {i}
          </button>
        </li>
      );
    }
    return pageNumbers;
  };

  return (
    <div className="container">
      <h4>Core Connectivity Details</h4>
      <div className="card">
        <div className="card-body">
          <form onSubmit={handleSubmit} className="d-flex align-items-center">
            <div className="col-auto me-2">
              <select
                id="searchField"
                name="searchField"
                className="form-select"
                value={searchField}
                onChange={(e) => setSearchField(e.target.value)}
              >
                <option value="">Filter</option>
                {fields.map((field, index) => (
                  <option key={index} value={field}>
                    {field}
                  </option>
                ))}
              </select>
            </div>
            <div className="col-auto">
               <input
                type="text"
                id="searchTerm"
                name="searchTerm"
                className="form-control"
                placeholder="Search term"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="col-auto">
              <button type="submit" className="btn btn-primary btn-md m-2">Search</button>
            </div>
          </form>
        </div>
        <div className="card-body">
          <table className="table table-striped text-center">
            <thead>
              <tr>
                <th>S.no</th>
                <th>Institution ID</th>
                <th>Core Name</th>
                <th>Host</th>
                {/* <th>Port</th> */}
                <th>Base Path</th>
                {/* <th>Message ID</th>
                <th>Branch ID</th> */}
                {/* <th>Processor User</th>
                <th>Device Type</th>
                <th>Device Number</th> */}
                <th>User Name</th>
                {/* <th>Password</th>
                <th>Admin Password</th>
                <th>FindBy Service Path</th> */}
                {/* <th>Account Service Path</th>
                <th>Transaction Service Path</th>
                <th>Active Flag</th>
                <th>Created Date</th>
                <th>Modified Date</th> */}
                {/* <th>Created By</th> */}
                <th>View</th>
                <th>Edit</th>
                <th>Delete</th>
              </tr>
            </thead>
            <tbody>
              {currentRecords.map((item, index) => (
                <tr key={index}>
                  <td>{index + 1}</td>
                  <td>{item.financialInstitutionId}</td>
                  <td>{item.coreName}</td>
                  <td>{item.host}</td>
                  {/* <td>{item.port}</td> */}
                  <td>{item.basepath}</td>
                  {/* <td>{item.messageId}</td>
                  <td>{item.branchId}</td> */}
                  {/* <td>{item.processorUser}</td>
                  <td>{item.deviceType}</td>
                  <td>{item.deviceNumber}</td> */}
                  <td>{item.userName}</td>
                  {/* <td>{item.password}</td>
                  <td>{item.adminPassword}</td>
                  <td>{item.findbyServicePath}</td>
                  <td>{item.accountServicePath}</td>
                  <td>{item.transactionServicePath}</td>
                  <td>{item.activeFlag ? "Yes" : "No"}</td>
                  <td>{new Date(item.createdDate).toLocaleString()}</td>
                  <td>{new Date(item.modifiedDate).toLocaleString()}</td>
                  <td>{item.createdBy}</td> */}
                  <td>
                    <a data-bs-toggle="modal" data-bs-target="#ViewCore" onClick={() =>handleEditClick(item) }>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-eye" viewBox="0 0 16 16">
                    <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8M1.173 8a13 13 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5s3.879 1.168 5.168 2.457A13 13 0 0 1 14.828 8q-.086.13-.195.288c-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5s-3.879-1.168-5.168-2.457A13 13 0 0 1 1.172 8z" />
                    <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5M4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0" />
                    </svg>
                    </a>
                </td>
                <td>
                    <a data-bs-toggle="modal" data-bs-target="#editCore" onClick={() =>handleEditClick(item) }>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-pencil" viewBox="0 0 16 16">
                    <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325" />
                    </svg>
                    </a>
                </td>
                <td>
                    <a onClick={() => deleteItem(item)}>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-trash" viewBox="0 0 16 16">
                    <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z" />
                    <path d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z" />
                    </svg>
                    </a>
                </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <nav aria-label="Page navigation">
          <ul className="pagination justify-content-center">
            <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
              <button className="page-link" onClick={() => handlePageChange(currentPage - 1)}>
                Previous
              </button>
            </li>
            {renderPageNumbers()}
            <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
              <button className="page-link" onClick={() => handlePageChange(currentPage + 1)}>
                Next
              </button>
            </li>
          </ul>
        </nav>
        {/* Add Modal */}
        <div className="float-end" data-bs-toggle="modal" data-bs-target="#newCore">
                  <button type="button" className="btn btn-primary float-end m-3">
                    Add Core
                  </button>
        </div>
                <div className="modal fade" id="newCore" tabIndex="-1" aria-labelledby="core" aria-hidden="true">
                  <div className="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
                    <div className="modal-content">
                      <div className="modal-header">
                        <h5 className="modal-title" id="core">Core Details</h5>
                        <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div className="modal-body">
                        <AddCoreConnectivity />
                      </div>
                    </div>
                  </div>
                </div>
      </div>

         {/* Edit Modal */}
         <div className="modal fade" id="editCore" tabIndex="-1" aria-labelledby="Caccount" aria-hidden="true">
                  <div className="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
                    <div className="modal-content">
                      <div className="modal-header">
                        <h5 className="modal-title" id="Caccount">Edit Account</h5>
                        <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div className="modal-body">
                        <EditCoreConnectivity editData={editItem} />
                      </div>
                    </div>
                  </div>
         </div>
        

         {/* View Modal */}
         <div className="modal fade" id="ViewCore" tabIndex="-1" aria-labelledby="Vcore" aria-hidden="true">
                  <div className="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
                    <div className="modal-content">
                      <div className="modal-header">
                        <h5 className="modal-title" id="Vcore">Core Details</h5>
                        <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div className="modal-body">
                        <ViewCoreConnectivity editData={editItem} />
                      </div>
                    </div>
                  </div>
                </div>
{/* Unable to add */}
      {errorModalVisible && (
        <div className="modal fade show custom-modal box-required-size" style={{ display: "block" }} tabIndex="-1">
          <div className="modal-dialog col-sm-3">
            <div className="modal-content">
              <div className="modal-header bg-danger text-white">
                <h5 className="modal-title">Failed</h5>
                <button type="button" className="btn-close" onClick={() => setErrorModalVisible(false)}></button>
              </div>
              <div className="modal-body error-res">
                <p>Unable to fetch data</p>
              </div>
            </div>
          </div>
        </div>
      )}

{/* Unable to delete */}
      {errorModalVisibleDelete && (
        <div className="modal fade show custom-modal box-required-size" style={{ display: "block" }} tabIndex="-1">
          <div className="modal-dialog col-sm-3">
            <div className="modal-content">
              <div className="modal-header bg-danger text-white">
                <h5 className="modal-title">Unable to Delete</h5>
                  <button type="button" className="btn-close" onClick={() => setErrorModalVisibleDelete(false)}></button>
              </div>
            <div className="modal-body error-res">
         <p>Can't Delete some other values are depending on it</p>
        </div>
       </div>
      </div>
    </div>
    )}
      {/*  delete d*/}
      {deletedModalVisible && (
                    <div className="modal fade show custom-modal box-required-size" style={{ display: "block" }} tabIndex="-1">
                        <div className="modal-dialog col-sm-3">
                            <div className="modal-content">
                                <div className="modal-header bg-danger text-white">
                                    <h5 className="modal-title"> Delete</h5>
                                    <button type="button" className="btn-close" onClick={() => setDeletedModalVisible(false)}></button>
                                </div>
                                <div className="modal-body error-res">
                                    <p>Core Details are deleted !!!</p>
                                </div>
                            </div>
                        </div>
                    </div>
    )}
    </div>
  );
};

export default CoreConnectivityDetails;
