import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { FormProvider } from './button/signleButton';
import TabletView from './forms/TabletView';
import Dashboard from './forms/Dashboard';
import ViewFiIdDetails from './forms/ViewDetails';
import UpdateFinancialInstitution from './forms/updateDetails/updateFinancialInstitution';
import UpdatedTransactionForm from './forms/updateDetails/updateTransactioncapbality';
import EditAccounts1 from './forms/EditAccountsTypes';
import ViewAccounts1 from './forms/ViewAccountsTypes';
import AddAccountType from './forms/AddAccountType';
import AddDataForm from './forms/appProperties/AddDataForm';
import EditDataForm from './forms/appProperties/EditDataForm';
import ViewData from './forms/appProperties/ViewData';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import '@fortawesome/fontawesome-free/css/all.min.css';

function App() {
  return (
    <FormProvider>
      <Router>
        
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/*" element={<TabletView />} />
          <Route path='/viewDetails' element={<ViewFiIdDetails />} />
          <Route path='/updateFiId' element={<UpdateFinancialInstitution />} />
          <Route path='/updateTransactionCapability' element={<UpdatedTransactionForm />} />
          <Route path='/addAccountType' element={<AddAccountType />} />
          <Route path='/view-account-data' element={<ViewAccounts1 />} />
          <Route path='/editAccounts' element={<EditAccounts1 />} />
          <Route path='/addAppProperties' element={<AddDataForm />} />
          <Route path='/editAppProperties' element={<EditDataForm />} />
          <Route path='/viewAppProperites' element={<ViewData />} />
        </Routes>
      </Router>
    </FormProvider>
  );
}

export default App;
