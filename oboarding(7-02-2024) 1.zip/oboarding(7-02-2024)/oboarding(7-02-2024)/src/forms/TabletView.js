import React, { useState } from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import FinancialInstitution from './financialInstitution';
import FlowRoute from './flowRoute';
import NextForm from './transactioncapbality';
import './css/style.css';
import DataMapping from './dataMapping';
import CoreConfig from './CoreConnectivity';
import SubmitData from './submitData';

function TabletView() {
  const location = useLocation();
  const currentPath = location.pathname;

  // State to manage button enable/disable states
  const [firstButtonEnabled, setFirstButtonEnabled] = useState(false);
  const [secondButtonEnabled, setSecondButtonEnabled] = useState(false);

  // Function to enable the second button
  const handleEnableSecondButton = () => {
    setSecondButtonEnabled(true);
  };

  return (
    <div className="container">
      <nav className='mt-5'>
        <div className="nav nav-tabs" id="nav-tab" role="tablist">
          <Link
            to="/fiId"
            className={`nav-link col-2 ${currentPath === '/' ? 'active' : ''}`}
            id="nav-tab-1"
          >
            Financial Institution
          </Link>
          <Link
            to="/next-form"
            className={`nav-link col-2 ${currentPath === '/next-form' ? 'active' : ''}`}
            id="nav-tab-2"
            onClick={() => setFirstButtonEnabled(true)}
          >
            Transaction Capability
          </Link>
          <Link
            to="/flow-route"
            className={`nav-link col-2 ${currentPath === '/flow-route' ? 'active' : ''}`}
            id="nav-tab-3"
            onClick={handleEnableSecondButton} // Enable the second button
            disabled={!firstButtonEnabled} // Disable if first button is not enabled
          >
            Flow Route
          </Link>
          <Link
            to="/data-mapping"
            className={`nav-link col-2 ${currentPath === '/data-mapping' ? 'active' : ''}`}
            id="nav-tab-3"
            disabled={!secondButtonEnabled} // Disable if second button is not enabled
          >
            Data Mapping
          </Link>
          <Link
            to="/core-config"
            className={`nav-link col-2 ${currentPath === '/core-config' ? 'active' : ''}`}
            id="nav-tab-3"
            disabled={!secondButtonEnabled} // Disable if second button is not enabled
          >
            Core Connectivity
          </Link>
          <Link
            to="/submit-form"
            className={`nav-link col-2 ${currentPath === '/submit-form' ? 'active' : ''}`}
            id="nav-tab-3"
            disabled={!secondButtonEnabled} // Disable if second button is not enabled
          >
            Onboard Institution
          </Link>
        </div>
      </nav>
      <div className="tab-content" id="nav-tabContent">
        <Routes>
          <Route path="/fiId" element={<FinancialInstitution />} />
          <Route path="/next-form" element={<NextForm />} />
          <Route path="/flow-route" element={<FlowRoute />} />
          <Route path='/data-mapping' element={<DataMapping />} />
          <Route path='/core-config' element={<CoreConfig />} />
          <Route path='/submit-form' element={<SubmitData />} />
        </Routes>
      </div>
    </div>
  );
}

export default TabletView;
