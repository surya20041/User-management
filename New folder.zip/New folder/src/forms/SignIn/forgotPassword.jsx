import React, { useContext, useEffect, useState } from "react";
import { userContext } from "../../App";
import Button from "../Button/Button";
import InputBox from "../InputBox/InputBox";
import { MD5 } from "crypto-js";
import styles from "./SignIn.module.css";
import logo from './techrev-logo.png';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Link } from 'react-router-dom';
import axios from "axios";


const ForgotPassword = () => {
 

  {/*useEffect(() => {
    fetch("http://localhost:8083/getusersdata")
        .then(response => response.json())
        .then(data => {
            console.log("Fetched users data:", data); // Check console for user data structure
            setUsersData(data); // Update usersData state
        })
        .catch(error => console.error("Error fetching user data:", error));
}, [setUsersData]);*/}

axios.put("http://localhost:8083/updatepassword?password=" + pass).then((data)=>{
  data.data
}).catch((error) => {
  error
})

  






  <body>
    <section className={`${styles.main} col-7`}>
      <div className={styles.container}>
        <div className={styles.row}>
        <div className={`${styles.text} col-12 col-lg-12`}>
          <section className={styles.mainbx}>
      
        <img src={logo} alt={logo}></img>

        <form>
			<div className={`${styles.formGroup} mt-4 mb-3`}>
        
          <h1 className={styles.heading}>Reset Password</h1>
            <InputBox
              labelFor="Username"
              type="text"
              
            />
            </div>
            
            <div className={`${styles.belowlinks} mt-4 text-center`}>
            {/*<Button name={"Sign In"} size="small" onclick={validateCredentials} />*/}
            {/*<Button className="btn btn-info" name={"Sign In"} size="small" onclick={validateCredentials} />*/}
            {/*<p>{status}</p>*/}
            </div>
           
        
          
        </form>
     

      </section>
      </div>
      </div>
      </div>
    </section>
  </body>



    
  
};
			

export default ForgotPassword;
