import React, { useState, useEffect } from 'react';
import axios from 'axios';

const EditDataForm = ({ data, onUpdate, onCancel }) => {
    const [applicationName, setApplicationName] = useState(data.appName);
    const [environment, setEnvironment] = useState(data.env);
    const [propertyKey, setPropertyKey] = useState(data.propKey);
    const [propertyVal, setPropertyVal] = useState(data.propVal);
    const [modifiedBy, setModifiedBy] = useState(data.modifiedBy);
    const [createdBy, setCreatedBy] = useState(data.createdBy);
    const [lastModifiedTime, setLastModifiedTime] = useState(data.lastModifiedTime);
    const [createdDate, setCreatedDate] = useState(data.createdDate);
    const [modifiedDate, setModifiedDate] = useState(data.modifiedDate);
    console.log(data)
    useEffect(() => {
        setApplicationName(data.applicationName);
        setEnvironment(data.environment);
        setPropertyKey(data.propertyKey);
        setPropertyVal(data.propertyVal);
        setModifiedBy(data.modifiedBy);
        setCreatedBy(data.createdBy);
        setLastModifiedTime(data.lastModifiedTime);
        setCreatedDate(data.createdDate);
        setModifiedDate(data.modifiedDate);
    }, [data]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        const updatedItem = {
            id: data.id,
            applicationName,
            environment,
            propertyKey,
            propertyVal,
            modifiedBy,
            createdBy,
            lastModifiedTime,
            createdDate,
            modifiedDate
        };

        try {
            await axios.put(`http://localhost:8083/onbording/edit/${data.id}`, updatedItem);
            onUpdate(updatedItem);
        } catch (error) {
            console.error('Failed to update item:', error);
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <div className="row">
                <div className="col-12 col-lg-3 mt-3 mb-3">
                    <label className="form-label">Application Name</label>
                    <input
                        type="text"
                        className="form-control form-control-lg"
                        name="AppName"
                        onChange={(e) => setApplicationName(e.target.value)}
                        value={applicationName}
                        required
                    />
                </div>
                <div className="col-12 col-lg-3 mt-3 mb-3">
                    <label className="form-label">Environment</label>
                    <select
                        className="form-control form-control-lg form-select"
                        name="Environment"
                        onChange={(e) => setEnvironment(e.target.value)}
                        value={environment}
                        required
                    >
                        <option value="">Select Environment</option>
                        <option value="local">Local</option>
                        <option value="dev">Dev</option>
                        <option value="qa">QA</option>
                        <option value="uat">UAT</option>
                    </select>
                </div>
                <div className="col-12 col-lg-3 mt-3 mb-3">
                    <label className="form-label">Property Key</label>
                    <input
                        type="text"
                        className="form-control form-control-lg"
                        name="PropertyKey"
                        onChange={(e) => setPropertyKey(e.target.value)}
                        value={propertyKey}
                        required
                    />
                </div>
                <div className="col-12 col-lg-3 mt-3 mb-3">
                    <label className="form-label">Property Val</label>
                    <input
                        type="text"
                        className="form-control form-control-lg"
                        name="PropertyVal"
                        onChange={(e) => setPropertyVal(e.target.value)}
                        value={propertyVal}
                        required
                    />
                </div>
                <div className="col-12 col-lg-3 mb-3">
                    <label className="form-label">Last Modified Time</label>
                    <input
                        type="date"
                        className="form-control form-control-lg"
                        name="LastModifiedTime"
                        onChange={(e) => setLastModifiedTime(e.target.value)}
                        value={lastModifiedTime}
                        required
                    />
                </div>
                <div className="col-12 col-lg-3 mb-3">
                    <label className="form-label">Created Date</label>
                    <input
                        type="date"
                        className="form-control form-control-lg"
                        name="CreatedDate"
                        onChange={(e) => setCreatedDate(e.target.value)}
                        value={createdDate}
                        required
                    />
                </div>
                <div className="col-12 col-lg-3 mb-3">
                    <label className="form-label">Modified Date</label>
                    <input
                        type="date"
                        className="form-control form-control-lg"
                        name="ModifiedDate"
                        onChange={(e) => setModifiedDate(e.target.value)}
                        value={modifiedDate}
                        required
                    />
                </div>
                <div className="col-12 col-lg-3 mb-3">
                    <label className="form-label">Created By</label>
                    <input
                        type="text"
                        className="form-control form-control-lg"
                        name="CreatedBy"
                        onChange={(e) => setCreatedBy(e.target.value)}
                        value={createdBy}
                        required
                    />
                </div>
                <div className="col-12 col-lg-3 mb-3">
                    <label className="form-label">Modified By</label>
                    <input
                        type="text"
                        className="form-control form-control-lg"
                        name="ModifiedBy"
                        onChange={(e) => setModifiedBy(e.target.value)}
                        value={modifiedBy}
                        required
                    />
                </div>
                <div className="col-12 mt-4 text-right two-btns">
                    <button type="submit" className="btn btn-info">Update</button>
                    <button type="button" className="btn btn-secondary" onClick={onCancel}>Cancel</button>
                </div>
            </div>
        </form>
    );
};

export default EditDataForm;