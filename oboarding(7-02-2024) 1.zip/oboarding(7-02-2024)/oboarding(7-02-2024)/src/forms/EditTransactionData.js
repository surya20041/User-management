import React from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import './AddAccountType.css';
import { useState, useEffect } from "react";

const EditTransactionData = ({ editData }) => {
    const [account, setAccount] = useState({});
    const navigate = useNavigate();
    const [modalVisible, setModalVisible] = useState(false);
    const [errorModalVisible, setErrorModalVisible] = useState(false);


    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setAccount({ ...account, [name]: value });
    };

    useEffect(() => {
        setAccount(editData);
    }, [editData]);

    const handleSubmit = (e) => {

        const updatedAccount = { ...account, date: new Date().toISOString() };
        e.preventDefault();
        

        axios.put(`http://localhost:8083/onbording/editTrnData`, updatedAccount)
            .then((res) => {
                setModalVisible(true);
                setAccount({});
                navigate('/');
            })
            .catch((err) => {
                setErrorModalVisible(true);
            });
    };


    return(
        <div>
              <div className="row">
            <div className="col-12">
                <div className="mb-3">
                    <form onSubmit={handleSubmit}>
                        <div className="row mb-3">
                            <label className="col-sm-3 col-form-label font-weight-bold"><strong>From AccountNumber</strong></label>
                            <div className="col-sm-4">
                                <input
                                    type="text"
                                    className="form-control"
                                    name="fromAccountNumber"
                                    value={account.fromAccountNumber || ""}
                                    onChange={handleInputChange}
                                    required
                                />
                            </div>
                        </div>
                        <div className="row mb-3">
                            <label className="col-sm-3 col-form-label font-weight-bold"><strong>To AccountNumber </strong></label>
                            <div className="col-sm-4">
                                <input
                                    type="text"
                                    className="form-control"
                                    name="toAccountNumber"
                                    value={account.toAccountNumber || ""}
                                    onChange={handleInputChange}
                                    required
                                />
                            </div>
                        </div>
                        <div className="row mb-3">
                            <label className="col-sm-3 col-form-label font-weight-bold"><strong>To AccountType</strong></label>
                            <div className="col-sm-4">
                                <input
                                    type="text"
                                    className="form-control"
                                    name="toAccountType"
                                    value={account.toAccountType || ""}
                                    onChange={handleInputChange}
                                    required
                                />
                            </div>
                        </div>
                        <div className="row mb-3">
                            <label className="col-sm-3 col-form-label font-weight-bold"><strong>Acquirer Id</strong></label>
                            <div className="col-sm-4">
                                <input
                                    type="text"
                                    className="form-control"
                                    name="acquirerid"
                                    value={account.acquirerid || ""}
                                    onChange={handleInputChange}
                                />
                            </div>
                        </div>
                        <div className="row mb-3">
                            <label className="col-sm-3 col-form-label font-weight-bold"><strong>AuthId</strong></label>
                            <div className="col-sm-4">
                                <input
                                    type="text"
                                    className="form-control"
                                    name="authId"
                                    value={account.authId || ""}
                                    onChange={handleInputChange}
                                    required
                                />
                            </div>
                        </div>
                        <div className="row mb-3">
                            <label className="col-sm-3 col-form-label font-weight-bold"><strong>Institution Id</strong></label>
                            <div className="col-sm-4">
                                <input
                                    type="text"
                                    className="form-control"
                                    name="instId"
                                    value={account.instId || ""}
                                    onChange={handleInputChange}
                                    required
                                />
                            </div>
                        </div>
                        <div className="row mb-3">
                            <label className="col-sm-3 col-form-label font-weight-bold"><strong>terminal Id</strong></label>
                            <div className="col-sm-4">
                                <input
                                    type="text"
                                    className="form-control"
                                    name="terminalId"
                                    value={account.terminalId || ""}
                                    onChange={handleInputChange}
                                    required
                                />
                            </div>
                        </div>
                        <div className="row mb-3">
                            <label className="col-sm-3 col-form-label font-weight-bold"><strong>rrn</strong></label>
                            <div className="col-sm-4">
                                <input
                                    type="text"
                                    className="form-control"
                                    name="rrn"
                                    value={account.rrn || ""}
                                    onChange={handleInputChange}
                                    required
                                />
                            </div>
                        </div>
                        <div className="row mb-3">
                            <label className="col-sm-3 col-form-label font-weight-bold"><strong>amount</strong></label>
                            <div className="col-sm-4">
                                <input
                                    type="Number"
                                    className="form-control"
                                    name="amount"
                                    value={account.amount || ""}
                                    onChange={handleInputChange}
                                    required
                                />
                            </div>
                        </div>
                        <div className="row mb-3">
                            <label className="col-sm-3 col-form-label font-weight-bold"><strong>transactionType</strong></label>
                            <div className="col-sm-4">
                                <input
                                    type="text"
                                    className="form-control"
                                    name="transactionType"
                                    value={account.transactionType || ""}
                                    onChange={handleInputChange}
                                    required
                                />
                            </div>
                        </div>
                     
                        
                        <button className="mt-2 btn btn-primary" type="submit">Save</button>
                    </form>
                    {modalVisible && (
                        <div className="modal fade show custom-modal box-required-size" style={{ display: "block" }} tabIndex="-1">
                            <div className="modal-dialog col-sm-3">
                                <div className="modal-content">
                                    <div className="modal-header bg-success text-white">
                                        <h5 className="modal-title">Updated</h5>
                                        <button type="button" className="btn-close" onClick={() => setModalVisible(false)}></button>
                                    </div>
                                    <div className="modal-body success.res">
                                        <p>Account successfully updated</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}
                    {errorModalVisible && (
                        <div className="modal fade show custom-modal box-required-size" style={{ display: "block" }} tabIndex="-1">
                            <div className="modal-dialog col-sm-3">
                                <div className="modal-content">
                                    <div className="modal-header bg-danger text-white">
                                        <h5 className="modal-title">Failed</h5>
                                        <button type="button" className="btn-close" onClick={() => setErrorModalVisible(false)}></button>
                                    </div>
                                    <div className="modal-body error-res">
                                        <p>Unable to update account</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
        </div>
    )
}
export default EditTransactionData;
