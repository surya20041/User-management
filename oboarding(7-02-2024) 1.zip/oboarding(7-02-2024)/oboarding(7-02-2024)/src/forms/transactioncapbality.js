import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useFormContext } from '../button/signleButton';  

import './css/style.css';

const TransactionForm = ({ onSubmitClick, fiId, fiIdTransactionType}) => {

 // console.log(fiId, fiIdTransactionType);
  const initialFormData = {
    financialInstitutionId: 0,
    fromAccountTypeIds: 0,
    toAccountTypeIds: {},
    transactionType: '',
    coreInterfaceOperation: '',
    isEnabled: false,
    createdAt: '',
    isoCode: ''
  };

  const [formData, setFormData] = useState(initialFormData);
  const { updateForm } = useFormContext();


  const [enableFromAccountTypeId, setEnableFromAccountTypeId] = useState(false);
  const [allTransactionDetails, setAllTransactionDetails] = useState([]);
  const location = useLocation();
  const navigate = useNavigate();
  
  //const { fiId = '', transactionType = '', a = '' } = location.state || {};
  
  const transactionTypeArray = fiIdTransactionType.split(',');
  // const transactionTypeArray = fiIdTransactionType.split(',');

  const [accountTypes, setAccountTypes] = useState([]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    
    setFormData((prevFormData) => ({
      ...prevFormData,
      [name]: type === 'checkbox' ? checked : name === 'isEnabled' ? value === 'true' : value
    }));
  };
  
  const handleAccountTypeChange = (e, field) => {
    const { value, checked } = e.target;
    if (field === "fromAccountTypeIds") {
      setFormData((prevFormData) => ({
        ...prevFormData,
        fromAccountTypeIds: parseInt(value)
      }));
    } else {
      setFormData((prevFormData) => {
        const updatedIdsMap = {
          ...prevFormData[field],
          [prevFormData.transactionType]: checked
            ? [...(prevFormData[field]?.[prevFormData.transactionType] || []), parseInt(value)]
            : (prevFormData[field]?.[prevFormData.transactionType] || []).filter((id) => id !== parseInt(value))
        };
        return {
          ...prevFormData,
          [field]: updatedIdsMap
        };
      });
    }
  };

  const handleTransactionTypeChange = (e) => {
    const { value } = e.target;
    setFormData((prevFormData) => ({
      ...prevFormData,
      transactionType: value
    }));
  };

  // useEffect(() => {
 
  //   setFormData((prevFormData) => ({
  //     ...prevFormData,
  //     financialInstitutionId: fiId
  //   }));
 
  // }, [financial_institution_id, a]);

  useEffect(() => {
    if (formData.transactionType === "TRANSFER" || formData.transactionType === "TRANSFERREVERSAL") {
      setEnableFromAccountTypeId(true);
    } else {
      setEnableFromAccountTypeId(false);
    }
  }, [formData.transactionType]);

  useEffect(() => {     

    axios.get("http://localhost:8083/onbording/accountType")
      .then((response) => {
        const descriptions = response.data.map(accountType => ({ id: accountType.id, description: accountType.description }));
        setAccountTypes(descriptions);
      //  console.log(descriptions);
      }).catch((error) => {
      //  console.log(error);
      });
  }, []);

  // useEffect(() =>{

  //   // if(){

  //   // }
  //   const toAccountType = {};
  //   const fromAccountType = formData.fromAccountTypeIds;

  //   Object.entries(formData.toAccountTypeIds).forEach(([key, value]) => {
  //     if(toAccountType)
  //     toAccountType[key] = value.map(id => parseInt(id));
  //   });

  //   const transactionCapabilityData = {
  //     financialInstitutionId: formData.financialInstitutionId,
  //     toAccountType,
  //     fromAccountType,
  //     coreInterfaceOperation: formData.coreInterfaceOperation,
  //     isEnabled: formData.isEnabled,
  //     createdAt: formData.createdAt,
  //     isoCode: formData.isoCode
  //   };

  //   setAllTransactionDetails((previousValues) => {
  //     if (!Array.isArray(previousValues)) {
  //       previousValues = [];
  //     }
  //     return [
  //       ...previousValues,
  //       transactionCapabilityData
  //     ];
  //   });

    // Reset form data to initial state
  //   setFormData(initialFormData);

  // }, [formData.fromAccountTypeIds, formData.toAccountTypeIds])

  const handleSubmit = (e) => {
    e.preventDefault();

    const toAccountType = {};
    const fromAccountType = formData.fromAccountTypeIds;

    Object.entries(formData.toAccountTypeIds).forEach(([key, value]) => {
      toAccountType[key] = value.map(id => parseInt(id));
    });

    const transactionCapabilityData = {
      financialInstitutionId: fiId,
      toAccountType,
      fromAccountType,
      coreInterfaceOperation: formData.coreInterfaceOperation,
      isEnabled: formData.isEnabled,
      createdAt: formData.createdAt,
      isoCode: formData.isoCode
    };

    setAllTransactionDetails((previousValues) => {
      if (!Array.isArray(previousValues)) {
        previousValues = [];
      }
      return [
        ...previousValues,
        transactionCapabilityData
      ];
    });

    // Reset form data to initial state
    setFormData(initialFormData);
  };

  useEffect(() => {
    if (allTransactionDetails.length > 0) {
    //  console.log("Updated transaction details:", allTransactionDetails);
    }
  }, [allTransactionDetails]);

  const isChecked = (field, id) => {
    if (field === 'fromAccountTypeIds') {
      return formData[field] === id;
    }
    return (formData[field]?.[formData.transactionType] || []).includes(id);
  };

  const submitAllDetails = () => {
    updateForm('allTransactionDetailsData', allTransactionDetails);
    const financial_institution_id = fiId
    onSubmitClick("flow-route")
   // navigate('/flow-route', { state: { financial_institution_id, a } });

    // axios.post('http://localhost:8083/onbording/transactionCapability', allTransactionDetails)
    //   .then((response) => {
    //     console.log(response);
    //     navigate('/flow-route', { state: { financial_institution_id, a } });
    //   })
    //   .catch((error) => {
    //     console.error("There was an error submitting the form!", error);
    //   });
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className='row'>
        <div className="col-12 mt-3 mb-3">
          <b><p className="form-label">Financial Institution ID: {fiId}</p></b>
        </div>
        <div className="col-12 mb-3">
          <label className="form-label">Transaction Types<span className="text-danger">*</span></label>
          <select
            id="transactionTypes"
            name="transactionType"
            className="form-select"
            value={formData.transactionType}
            onChange={handleTransactionTypeChange}
          >
            <option value="">Select Transaction Type</option>
            {transactionTypeArray.map((type) => (
              <option key={type} value={type}>{type}</option>
            ))}
          </select>
        </div>
       
        {enableFromAccountTypeId && (
          <div className="col-12 mb-3 mt-3">
            <div className="accordion accordion-flush" id="accordionFlushExample">
              <div className="accordion-item">
                <h2 className="accordion-header" id="flush-headingOne">
                  <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
                    From Account Type IDs<span className="text-danger">*</span>
                  </button>
                </h2>
                <div id="flush-collapseOne" className="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                  <div className="accordion-body">
                    {accountTypes.map((accountType) => (
                      <div key={accountType.id} className="form-check form-check-inline">
                        <input
                          type="checkbox"
                          className="form-check-input"
                          id={`from-${accountType.id}`}
                          name="fromAccountTypeIds"
                          value={accountType.id}
                          checked={isChecked('fromAccountTypeIds', accountType.id)}
                          onChange={(e) => handleAccountTypeChange(e, 'fromAccountTypeIds')}
                        />
                        <label className="form-check-label" htmlFor={`from-${accountType.id}`}>{accountType.description}</label>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="col-12 mt-3">
          <div className="accordion accordion-flush" id="accordionFlushExample">
            <div className="accordion-item">
              <h2 className="accordion-header" id="flush-headingTwo">
                <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
                  To Account Type IDs<span className="text-danger">*</span>
                </button>
              </h2>
              <div id="flush-collapseTwo" className="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample">
                <div className="accordion-body">
                  {accountTypes.map((accountType) => (
                    <div key={accountType.id} className="form-check form-check-inline">
                      <input
                        type="checkbox"
                        className="form-check-input"
                        id={`to-${accountType.id}`}
                        name="toAccountTypeIds"
                        value={accountType.id}
                        checked={isChecked('toAccountTypeIds', accountType.id)}
                        onChange={(e) => handleAccountTypeChange(e, 'toAccountTypeIds')}
                      />
                      <label className="form-check-label" htmlFor={`to-${accountType.id}`}>{accountType.description}</label>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="col-12 col-lg-3 mb-3">
          <label className="form-label">Core Interface Operation<span className="text-danger">*</span></label>
          <input
            type="text"
            className="form-control"
            name="coreInterfaceOperation"
            value={formData.coreInterfaceOperation}
            onChange={handleChange}
          />
        </div>

        <div className="col-12 col-lg-3 mb-3 form-check radio-enable">
          <label className="form-check-label">
            <input
              className="form-check-input"
              type="radio"
              name="isEnabled"
              value={formData.isEnabled}
              checked={formData.isEnabled === true}
              onChange={() => {
                setFormData({...formData, isEnabled: true});
                console.log(formData);
              }}
            /> Active<span className="text-danger">*</span>
          </label>
          {/* <label className="form-check-label">
            <input
              className="form-check-input"
              type="radio"
              name="isEnabled"
              value={false}
              checked={formData.isEnabled === false}
              onChange={handleChange}
            /> Is Not Enabled
          </label> */}
        </div>

        <div className="col-12 col-lg-3 mb-3">
          <label className="form-label">Created At<span className="text-danger">*</span></label>
          <input
            type="date"
            className="form-control"
            name="createdAt"
            value={formData.createdAt}
            onChange={handleChange}
          />
        </div>

        <div className="col-12 col-lg-3 mb-3">
          <label className="form-label">ISO Code<span className="text-danger">*</span></label>
          <input
            type="text"
            className="form-control"
            name="isoCode"
            value={formData.isoCode}
            onChange={handleChange}
          />
        </div>

        <div className="col-12 mb-3">
          <button type="submit" className="btn btn-primary">add</button>
          <button type="button" className="btn btn-secondary" onClick={submitAllDetails}>next</button>
        </div>
      </div>
    </form>
  );
};

export default TransactionForm;
