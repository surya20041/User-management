import React, { useState } from 'react';
import axios from 'axios';

const AddDataForm = ({ onAdd, onClose }) => {
    const [appName, setAppName] = useState("");
    const [env, setEnv] = useState("");
    const [propKey, setPropKey] = useState("");
    const [propVal, setPropVal] = useState("");
    const [lastModifiedTime, setLastModifiedTime] = useState("");
    const [createdDate, setCreatedDate] = useState("");
    const [modifiedDate, setModifiedDate] = useState("");
    const [createdBy, setCreatedBy] = useState("");
    const [modifiedBy, setModifiedBy] = useState("");

    const handleSubmit = async (e) => {
        e.preventDefault();
        const newData = {
            appName,
            env,
            propKey,
            propVal,
            createdBy,
            modifiedBy,
            lastModifiedTime,
            createdDate,
            modifiedDate
        };

        try {
            const response = await axios.post("http://localhost:8083/onbording/add", newData);
            console.log('Response:', response.data);
            
            onAdd(); // Call the onAdd function to refresh the data in the parent component
            resetForm();
            onClose(); // Call the onClose function to close the modal
            alert("Data added successfully!");
        } catch (err) {
            console.log('Error:', err);
            alert("Failed to add data. Please try again.");
        }
    };

    const resetForm = () => {
        setAppName("");
        setEnv("");
        setPropKey("");
        setPropVal("");
        setCreatedBy("");
        setModifiedBy("");
        setLastModifiedTime("");
        setCreatedDate("");
        setModifiedDate("");
    };

    return (
        <div className='container'>
            <form onSubmit={handleSubmit}>
                <div className="row mb-3">
                    <div className="col-lg-3">
                        <label>App Name</label>
                    </div>
                    <div className="col-lg-9">
                        <input
                            type="text"
                            className="form-control"
                            name="AppName"
                            onChange={(e) => setAppName(e.target.value)}
                            value={appName}
                            required
                        />
                    </div>
                </div>
                <div className="row mb-3">
                    <div className="col-lg-3">
                        <label>Env</label>
                    </div>
                    <div className="col-lg-9">
                        <input
                            type="text"
                            className="form-control"
                            name="Env"
                            onChange={(e) => setEnv(e.target.value)}
                            value={env}
                            required
                        />
                    </div>
                </div>
                <div className="row mb-3">
                    <div className="col-lg-3">
                        <label>PropKey</label>
                    </div>
                    <div className="col-lg-9">
                        <input
                            type="text"
                            className="form-control"
                            name="PropKey"
                            onChange={(e) => setPropKey(e.target.value)}
                            value={propKey}
                            required
                        />
                    </div>
                </div>
                <div className="row mb-3">
                    <div className="col-lg-3">
                        <label>PropVal</label>
                    </div>
                    <div className="col-lg-9">
                        <input
                            type="text"
                            className="form-control"
                            name="PropVal"
                            onChange={(e) => setPropVal(e.target.value)}
                            value={propVal}
                            required
                        />
                    </div>
                </div>
                <div className="row mb-3">
                    <div className="col-lg-3">
                        <label>Last Modified Time</label>
                    </div>
                    <div className="col-lg-9">
                        <input
                            type="date"
                            className="form-control"
                            name="LastModifiedTime"
                            onChange={(e) => setLastModifiedTime(e.target.value)}
                            value={lastModifiedTime}
                            required
                        />
                    </div>
                </div>
                <div className="row mb-3">
                    <div className="col-lg-3">
                        <label>Created Date</label>
                    </div>
                    <div className="col-lg-9">
                        <input
                            type="date"
                            className="form-control"
                            name="CreatedDate"
                            onChange={(e) => setCreatedDate(e.target.value)}
                            value={createdDate}
                            required
                        />
                    </div>
                </div>
                <div className="row mb-3">
                    <div className="col-lg-3">
                        <label>Modified Date</label>
                    </div>
                    <div className="col-lg-9">
                        <input
                            type="date"
                            className="form-control"
                            name="ModifiedDate"
                            onChange={(e) => setModifiedDate(e.target.value)}
                            value={modifiedDate}
                            required
                        />
                    </div>
                </div>
                <div className="row mb-3">
                    <div className="col-lg-3">
                        <label>Created By</label>
                    </div>
                    <div className="col-lg-9">
                        <input
                            type="text"
                            className="form-control"
                            name="CreatedBy"
                            onChange={(e) => setCreatedBy(e.target.value)}
                            value={createdBy}
                            required
                        />
                    </div>
                </div>
                <div className="row mb-3">
                    <div className="col-lg-3">
                        <label>Modified By</label>
                    </div>
                    <div className="col-lg-9">
                        <input
                            type="text"
                            className="form-control"
                            name="ModifiedBy"
                            onChange={(e) => setModifiedBy(e.target.value)}
                            value={modifiedBy}
                            required
                        />
                    </div>
                </div>
                <div className="d-flex justify-content-end">
                    <button type="button" className="btn btn-secondary me-2" onClick={resetForm}>Reset</button>
                    <button type="submit" className="btn btn-primary me-2">Add Data</button>
                    <button type="button" className="btn btn-danger" onClick={onClose}>Close</button>
                </div>
            </form>
        </div>
    );
};

export default AddDataForm;
