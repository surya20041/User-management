import React, { useEffect, useState } from "react";
import axios from "axios";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPencilAlt } from "@fortawesome/free-solid-svg-icons";
import { Link, useNavigate } from "react-router-dom";

const ViewAccounts1 = () => {
    const [accountTypes, setAccountTypes] = useState([]);
    const [errors, setErrors] = useState("");
    const navigate = useNavigate(); // Initialize useNavigate hook

    useEffect(() => {
        axios.get("http://localhost:8083/onbording/displayAllAccounts")
            .then((res) => {
                setAccountTypes(res.data);
            })
            .catch((error) => {
                
                setErrors("Data not received");
            });
    }, []);

    const handleEditClick = (account) => {
        navigate('/editAccounts',{state : {account}});
    };
    function redirectToAddAccount() {
        navigate('/addAccountType');
    }

    return (
        <>
        <div className="container">
            <button className="btn btn-success" onClick={redirectToAddAccount}>add</button>
            <table border="1" className="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>StandardizedAccountType</th>
                        <th>AccountType</th>
                        <th>AccountSubType</th>
                        <th>AccountSubType2</th>
                        <th>Description</th>
                        <th>IsEnabled</th>
                        <th>CreatedAt</th>
                        <th>Edit</th>
                    </tr>
                </thead>
                <tbody>
                    {accountTypes.map((account, index) => (
                        <tr key={index}>
                            <td>{account.id}</td>
                            <td>{account.standarizedAccountType}</td>
                            <td>{account.accountType}</td>
                            <td>{account.accountSubType}</td>
                            <td>{account.accountSubType2}</td>
                            <td>{account.description}</td>
                            <td>{account.isEnabled ? "true" : "false"}</td>
                            <td>{new Date(account.createdAt).toLocaleString()}</td>
                            <td>
                                <div className="edit-btn" onClick={() => handleEditClick(account)}>
                                    <FontAwesomeIcon icon={faPencilAlt} />
                                </div>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
            </div>
        </>
    );
};

export default ViewAccounts1;
