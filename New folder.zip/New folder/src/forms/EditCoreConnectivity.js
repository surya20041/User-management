import React, { useState, useEffect } from "react";
 import { useNavigate } from "react-router-dom";
import axios from "axios";
import 'bootstrap/dist/css/bootstrap.min.css';


const EditCoreConnectivity = ({ editData }) => {
    const [coreData, setCoreData] = useState({});
     const navigate = useNavigate();
    const [modalVisible, setModalVisible] = useState(false);
    const [errorModalVisible, setErrorModalVisible] = useState(false);

    useEffect(() => {
        setCoreData(editData);
    }, [editData]);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setCoreData({ ...coreData, [name]: value });
    };

    const handleCheckboxChange = (e) => {
        setCoreData({ ...coreData, activeFlag: e.target.checked });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        // Set the modifiedDate field to the current date
        const updatedCoreData = { ...coreData, modifiedDate: new Date().toISOString() };

        axios.put(`http://localhost:8083/onbording/editCoreData`, updatedCoreData)
            .then((res) => {
                setModalVisible(true);
                setCoreData({});
                 navigate('/dashboard');
            })
            .catch((err) => {
                setErrorModalVisible(true);
            });
    };

    return (
        <div className="col-lg-12">
            <form onSubmit={handleSubmit}>
                <div className="row">
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Financial Institution ID<span className="text-danger">*</span></label>
                        <input
                            type="text"
                            className="form-control"
                            name="financialInstitutionId"
                            value={coreData.financialInstitutionId || ""}
                            onChange={handleInputChange}
                            required
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Core Name<span className="text-danger">*</span></label>
                        <input
                            type="text"
                            className="form-control"
                            name="coreName"
                            value={coreData.coreName || ""}
                            onChange={handleInputChange}
                            required
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Host<span className="text-danger">*</span></label>
                        <input
                            type="text"
                            className="form-control"
                            name="host"
                            value={coreData.host || ""}
                            onChange={handleInputChange}
                            required
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Port</label>
                        <input
                            type="text"
                            className="form-control"
                            name="port"
                            value={coreData.port || ""}
                            onChange={handleInputChange}
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Basepath</label>
                        <input
                            type="text"
                            className="form-control"
                            name="basepath"
                            value={coreData.basepath || ""}
                            onChange={handleInputChange}
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Message ID</label>
                        <input
                            type="text"
                            className="form-control"
                            name="messageId"
                            value={coreData.messageId || ""}
                            onChange={handleInputChange}
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Branch ID</label>
                        <input
                            type="text"
                            className="form-control"
                            name="branchId"
                            value={coreData.branchId || ""}
                            onChange={handleInputChange}
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Processor User</label>
                        <input
                            type="text"
                            className="form-control"
                            name="processorUser"
                            value={coreData.processorUser || ""}
                            onChange={handleInputChange}
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Device Type</label>
                        <input
                            type="text"
                            className="form-control"
                            name="deviceType"
                            value={coreData.deviceType || ""}
                            onChange={handleInputChange}
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Device Number</label>
                        <input
                            type="text"
                            className="form-control"
                            name="deviceNumber"
                            value={coreData.deviceNumber || ""}
                            onChange={handleInputChange}
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">User Name</label>
                        <input
                            type="text"
                            className="form-control"
                            name="userName"
                            value={coreData.userName || ""}
                            onChange={handleInputChange}
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Password</label>
                        <input
                            type="password"
                            className="form-control"
                            name="password"
                            value={coreData.password || ""}
                            onChange={handleInputChange}
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Admin Password</label>
                        <input
                            type="password"
                            className="form-control"
                            name="adminPassword"
                            value={coreData.adminPassword || ""}
                            onChange={handleInputChange}
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Find By Service Path</label>
                        <input
                            type="text"
                            className="form-control"
                            name="findbyServicePath"
                            value={coreData.findbyServicePath || ""}
                            onChange={handleInputChange}
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Account Service Path</label>
                        <input
                            type="text"
                            className="form-control"
                            name="accountServicePath"
                            value={coreData.accountServicePath || ""}
                            onChange={handleInputChange}
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Transaction Service Path</label>
                        <input
                            type="text"
                            className="form-control"
                            name="transactionServicePath"
                            value={coreData.transactionServicePath || ""}
                            onChange={handleInputChange}
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3 form-check">
                        <input
                            type="checkbox"
                            className="form-check-input"
                            name="activeFlag"
                            checked={coreData.activeFlag || false}
                            onChange={handleCheckboxChange}
                        />
                        <label className="form-check-label">Active Flag</label>
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Created By</label>
                        <input
                            type="text"
                            className="form-control"
                            name="createdBy"
                            value={coreData.createdBy || ""}
                            onChange={handleInputChange}
                        />
                    </div>
                    <div className="col-12 mt-4 text-right">
                        <button className="btn btn-info" type="submit">Save</button>
                    </div>
                </div>
            </form>
            {modalVisible && (
                <div className="modal fade show custom-modal box-required-size" style={{ display: "block" }} tabIndex="-1">
                    <div className="modal-dialog col-sm-3">
                        <div className="modal-content">
                            <div className="modal-header bg-success text-white">
                                <h5 className="modal-title">Updated</h5>
                                <button type="button" className="btn-close" onClick={() => setModalVisible(false)}></button>
                            </div>
                            <div className="modal-body success.res">
                                <p>Core connectivity details successfully updated</p>
                            </div>
                        </div>
                    </div>
                </div>
            )}
            {errorModalVisible && (
                <div className="modal fade show custom-modal box-required-size" style={{ display: "block" }} tabIndex="-1">
                    <div className="modal-dialog col-sm-3">
                        <div className="modal-content">
                            <div className="modal-header bg-danger text-white">
                                <h5 className="modal-title">Failed</h5>
                                <button type="button" className="btn-close" onClick={() => setErrorModalVisible(false)}></button>
                            </div>
                            <div className="modal-body error-res">
                                <p>Unable to update core connectivity details</p>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default EditCoreConnectivity;
