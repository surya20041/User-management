import { useLocation, useNavigate } from 'react-router-dom';
import React, { useState } from 'react';
import { useFormContext } from '../button/signleButton';  
import './css/style.css';
   
const DataMapping = ({ onSubmitClick, fiId }) => {
  const [formData, setFormData] = useState({
    flowRouteId: '',
    operation: '',
    script: '',
    isEnabled: false,
    createdAt: '',
    delOperation: ''
  });

  const { updateForm } = useFormContext();
  const location = useLocation();
  const navigate = useNavigate();
  const [showForm, setShowForm] = useState(false);
  // const { financial_institution_id = '', a = '' } = location.state || {};

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
   // console.log(formData)
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value,
    });
  };

  const handleNextForm = (e) => {
    e.preventDefault();
    // const headers = {
    //   'fiId': a
    // };

   // console.log(formData);
    updateForm('dataMappingData', [formData]);
   // updateForm('dataMappingfiId', {headers}); 
    onSubmitClick("core-config" );
   //navigate('/core-config', { state: { financial_institution_id, a }});
   // console.log('Proceeding to the next form with data:', formData);
  };

  const handleOpenForm = (e) => {
    e.preventDefault();
    setShowForm(true);
  //  console.log('Opening a different form.');
  };

  return (
    <div className="container">
      <b> <p>Financial Institution ID: {fiId}</p> </b>
      {!showForm &&
        <div className="col-12 text-center">
          <button onClick={handleNextForm} className="btn btn-info btn-lg mr-2">next</button>
          <button onClick={handleOpenForm} className="btn btn-info btn-lg">add new script</button>
        </div>}
      {showForm &&
        <form onSubmit={handleNextForm}>

          <div className="row">
            
            <div className="col-12 col-lg-4 mb-3">
              <label>Operation<span className="text-danger">*</span></label>
              <input
                type="text"
                name="operation"
                value={formData.operation}
                onChange={handleChange}
                required
              />
            </div>            
            <div className="col-12 col-lg-4 mb-3">
              <label>Created At<span className="text-danger">*</span></label>
              <input
                type="date"
                name="createdAt"
                value={formData.createdAt}
                onChange={handleChange}
                required
              />
            </div>
            <div className="col-12 col-lg-4 mb-3">
              <label>Del operation<span className="text-danger">*</span></label>
              <input
                type="text"
                name="delOperation"
                value={formData.delOperation}
                onChange={handleChange}
                required
              />
            </div>
            <div className="col-12 col-lg-4 mb-3">
              <label>Active<span className="text-danger">*</span></label>
              <input
                type="checkbox"
                name="isEnabled"
                checked={formData.isEnabled}
                onChange={handleChange}
              />
            </div>
            <div className="col-12 col-lg-3 mb-3">
              <label>Script<span className="text-danger">*</span></label>
              <textarea
                name="script"
                value={formData.script}
                onChange={handleChange}
                required
              />
            </div>
          </div>
          <div className="col-12 text-right">
              <button type="submit" className="btn btn-info btn-lg">next</button>
            </div>
        </form>
      }
    </div>
  );
};

export default DataMapping;
