import axios from 'axios';
import React, { useEffect, useState } from 'react';

import '../css/style.css';


const UpdatedTransactionForm = ({ id, updatedTransactionType }) => {
  const initialFormData = {
    financialInstitutionId: 0,
    fromAccountTypeIds: 0,
    toAccountTypeIds: {},
    transactionType: '',
    coreInterfaceOperation: '',
    isEnabled: false,
    createdAt: '',
    isoCode: ''
  };

  const [formData, setFormData] = useState(initialFormData);
  
  const [enableFromAccountTypeId, setEnableFromAccountTypeId] = useState(false);
  const [allTransactionDetails, setAllTransactionDetails] = useState([]);
  const [transfersFromType, setTransfersFromType] = useState(0);
  const [allFromAccountTypesWithIds, setAllFromAccountTypesWithIds] = useState([]);
  const [isoAndCore, setIsoAndCore] = useState([]);
  const [fromAccountTypeIds, setFromAccountTypeIds] = useState([]);
  const [accountTypes, setAccountTypes] = useState([]);  
  const [alreadyPresentData, setAlreadyPresentData] = useState({})
 
  const transactionTypeArray = updatedTransactionType.split(',');

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prevFormData) => ({
      ...prevFormData,
      [name]: type === 'checkbox' ? checked : name === 'isEnabled' ? value === 'true' : value
    }));
  };

  const handleAccountTypeChange = (e, field) => {
    const { value, checked } = e.target;
    if (field === "fromAccountTypeIds") {
      setFormData((prevFormData) => ({
        ...prevFormData,
        fromAccountTypeIds: parseInt(value)
      }));
    } else {
      setFormData((prevFormData) => {
        const updatedIdsMap = {
          ...prevFormData[field],
          [prevFormData.transactionType]: checked
            ? [...(prevFormData[field]?.[prevFormData.transactionType] || []), parseInt(value)]
            : (prevFormData[field]?.[prevFormData.transactionType] || []).filter((id) => id !== parseInt(value))
        };
        return {
          ...prevFormData,
          [field]: updatedIdsMap
        };
      });
    }
  };
  


  const handleTransactionTypeChange = (e) => {
    const { value } = e.target;
    setFormData((prevFormData) => ({
      ...prevFormData,
      transactionType: value
    }));
  };

  const getTransactionCapablilityData = () =>{
    const isEmpty = (obj) => Object.keys(obj).length === 0;

    if (!isEmpty(alreadyPresentData)) {
      Object.entries(alreadyPresentData).forEach((singleAccountType) => {
          // console.log("alreadyToPresentAccountTypes", alreadyPresentData);
          singleAccountType.map((alreadyToPresentAccountTypes) => {
          //  console.log(formData.transactionType)       
          if (formData.transactionType === "TRANSFER" || formData.transactionType === "TRANSFERREVERSAL") {
            setEnableFromAccountTypeId(true);
            Object.entries(alreadyToPresentAccountTypes).forEach(([subKey, data]) => {
             
              if (subKey === transfersFromType) {
                Object.entries(isoAndCore).forEach(([key, value]) => {
                  if (key === formData.transactionType) {
                    setFormData((prevData) => ({ 
                      ...prevData,
                      isoCode: value.isoCode,
                      coreInterfaceOperation: value.coreInterfaceOperation
                    }));
                  }
                });  
             //   console.log(transfersFromType);
         
            //  if (typeof data === "object" && data !== null) {
            //    console.log("formData", formData.toAccountTypeIds);
            //    console.log("data", data);
            
            //    setFormData((prevData) => ({
            //      ...prevData,
            //      toAccountTypeIds: {
            //       ...prevData.toAccountTypeIds,
            //        [formData.transactionType]: data
            //      }
            //    }));
            //  }
            if (typeof data === "object" && data !== null) {
              console.log("formData", formData.toAccountTypeIds);
              console.log("data", data);
            
              setFormData((prevData) => {
                const currentToAccountTypeIds = prevData.toAccountTypeIds[prevData.transactionType] || [];
                const newData = Array.isArray(data) ? data : [];
                
                // Merge arrays without duplicates
                const updatedToAccountTypeIds = Array.from(new Set([...currentToAccountTypeIds, ...newData]));
            
                return {
                  ...prevData,
                  toAccountTypeIds: {
                    ...prevData.toAccountTypeIds,
                    [prevData.transactionType]: updatedToAccountTypeIds
                  }
                };
              });
            }
            
             
              }
            });           
  
          } else {
            setEnableFromAccountTypeId(false);
            const tempToAccountTypeIds = alreadyPresentData[formData.transactionType];
            const tempIsoCode = isoAndCore[formData.transactionType]?.isoCode;
            const tempCoreInter = isoAndCore[formData.transactionType]?.coreInterfaceOperation;
            if (tempToAccountTypeIds != null) {
              setFormData((prevData) => {
                const currentToAccountTypeIds = prevData.toAccountTypeIds[prevData.transactionType] || [];
    
                // Merge arrays without duplicates
                const updatedToAccountTypeIds = Array.from(new Set([...currentToAccountTypeIds, ...tempToAccountTypeIds]));
            
                return {
                  ...prevData,
                  isoCode: tempIsoCode,
                  coreInterfaceOperation: tempCoreInter,
                  toAccountTypeIds: {
                    ...prevData.toAccountTypeIds,
                    [formData.transactionType]: updatedToAccountTypeIds
                  }
                };
              });
            } 
          }
        })  
      })
      }    
  }
  useEffect(() => {
    getTransactionCapablilityData();
  }, [formData.transactionType, transfersFromType]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const accountTypesResponse = await axios.get("http://localhost:8083/onbording/accountType");
        const accountTypesData = accountTypesResponse.data.map(accountType => ({ id: accountType.id, description: accountType.description }));
        setAccountTypes(accountTypesData);
       

        const transactionCapabilitiesResponse = await axios.get("http://localhost:8083/onbording/getTransactionCapablility?fiId=" + id);
        
        const temp = transactionCapabilitiesResponse.data;
       
        let transformedDisplay = {};
        let transfersObject = {};

        const newFromAccountTypeIds = [];
        let core_iso = []
        let singleIsoCode = '';
        let singleCoreInterfaceOperation = ''
        let singleTrnsType = ''
        let uniqueAccountTypes = new Set();
        let allfromAccTypeId = {};
        temp.map((tranType) => {
        //  console.log("tranType--------",tranType);
          const tempAccount = tranType.toAccountType;
          allfromAccTypeId = { ...allfromAccTypeId, [tranType.transactionType]: tempAccount }

          Object.entries(tranType).forEach(([key, transactionTypevalue]) => {
            if (Array.isArray(transactionTypevalue)) {
              if (tranType.transactionType === 'TRANSFER' || tranType.transactionType === 'TRANSFERREVERSAL') {
                transactionTypevalue.forEach((value) => {
                  let fromAccountTypeId = 0;
                  value.map((value) => {
                    //  console.log(value) 
                    if (typeof value === 'number') {
                      fromAccountTypeId = value;

                      transactionTypevalue.forEach((value) => {
                      
                        value.forEach((item) => {
                          if (typeof item === 'number') {
                            //  console.log("iiiii", item);
                            const matchedAccountType = accountTypesData.find(accountType => accountType.id === item);
                            if (matchedAccountType) {
                              if (!uniqueAccountTypes.has(matchedAccountType.id)) {
                                uniqueAccountTypes.add(matchedAccountType.id);
                                newFromAccountTypeIds.push(matchedAccountType);
                              }

                            }
                          }
                        });
                      });
                      //   console.log(tranType.isoCode, tranType.coreInterfaceOperation);
                      singleIsoCode = tranType.isoCode
                      singleCoreInterfaceOperation = tranType.coreInterfaceOperation;
                      singleTrnsType = tranType.transactionType;
                      core_iso = {
                        ...core_iso,
                        [singleTrnsType]: {
                          isoCode: singleIsoCode,
                          coreInterfaceOperation: singleCoreInterfaceOperation
                        }
                      };
                    }
                    else if (typeof value === 'object' && value !== null) {
                      const objKey = Object.keys(value)[0];
                      const objVal = value[objKey];
                      if (!transfersObject[fromAccountTypeId]) {
                        transfersObject[fromAccountTypeId] = [objVal];
                      } else {
                        transfersObject[fromAccountTypeId].push(objVal);
                      }
                    }
                    else {

                      // transfersObject[fromAccountTypeId].push(value);
                    }
                  })
                  transformedDisplay[tranType.transactionType] = transfersObject;
                  //  transfersObject= {...transformedDisplay, coreInterOper};
                  //console.log(coreInterOper)
                })

              } else {
                //  console.log("in the else",tranType)
                //If `value` is an array, iterate through each item
                transactionTypevalue.forEach((item) => {
                  // console.log("item----",item)
                  if (typeof item === 'object' && item !== null) {

                    const objKey = Object.keys(item)[0];
                    const objVal = item[objKey];

                    if (!transformedDisplay[tranType.transactionType]) {
                      transformedDisplay[tranType.transactionType] = []; // Initialize the array if it doesn't exist
                    }
                    transformedDisplay[tranType.transactionType].push(objVal); // Push the extracted value
                  }
                });
                singleIsoCode = tranType.isoCode
                singleCoreInterfaceOperation = tranType.coreInterfaceOperation;
                singleTrnsType = tranType.transactionType;
                core_iso = {
                  ...core_iso,
                  [singleTrnsType]: {
                    isoCode: singleIsoCode,
                    coreInterfaceOperation: singleCoreInterfaceOperation
                  }
                };
              }
            }
          });
        });
        setAllFromAccountTypesWithIds(allfromAccTypeId);
        setIsoAndCore(core_iso);
        setAlreadyPresentData(transformedDisplay)
        setFromAccountTypeIds(newFromAccountTypeIds);
      } catch (error) {
        console.error("Error fetching data: ", error);
      }
    };

    fetchData();
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();

    let toAccountType = {};
    const fromAccountType = formData.fromAccountTypeIds;
  
    Object.entries(formData.toAccountTypeIds).forEach(([key, value]) => {
      toAccountType[key] = value.map(id => parseInt(id));
    });


    const transactionCapabilityData = {
      financialInstitutionId: id,
      toAccountType,
      fromAccountType,
      coreInterfaceOperation: formData.coreInterfaceOperation,
      isEnabled: formData.isEnabled,
      createdAt: formData.createdAt,
      isoCode: formData.isoCode
    };

   // console.log(transactionCapabilityData);
    setAllTransactionDetails((previousValues) => {
      if (!Array.isArray(previousValues)) {
        previousValues = [];
      }
      return [
        ...previousValues,
        transactionCapabilityData
      ];
    });

    // setFormData(initialFormData);
  };

  // useEffect(() => {
  //   if (allTransactionDetails.length > 0) {

  //   }
  // }, [allTransactionDetails]);

  const isChecked = (field, id) => {
    if (field === 'fromAccountTypeIds') {
      return formData[field] === id;
    }
   // console.log(formData[field]?.[formData.transactionType])
    return (formData[field]?.[formData.transactionType] || []).includes(id);
  };

  const submitAllDetails = () => {
    console.log("alldata------", allTransactionDetails);

    const uniqueDetails = allTransactionDetails.map(detail => {
      const toAccountTypeCopy = {};

      for (const [key, value] of Object.entries(detail.toAccountType)) {
        toAccountTypeCopy[key] = [...value]; 
      }

      return {
        ...detail,
        toAccountType: toAccountTypeCopy
      };
    });

    axios.put("http://localhost:8083/onbording/updatedTransactionCap", uniqueDetails)
      .then((data) => {
        setAllTransactionDetails([])
        getTransactionCapablilityData();
        console.log(data);
      }).catch((err) => {
        console.log(err);
      });
  };



  return (
    <form onSubmit={handleSubmit}>
      <div className='row'>
        <div className="col-12 mt-3 mb-3">
          <b><p className="form-label">Financial Institution ID: {formData.financialInstitutionId} </p></b>
        </div>
        <div className="col-12 mb-3">
          <label className="form-label">Transaction Types:</label>
          <select
            id="transactionTypes"
            name="transactionType"
            className="form-select"
            value={formData.transactionType}
            onChange={handleTransactionTypeChange}
          >
            <option value="">Select Transaction Type</option>
            {transactionTypeArray.map((type) => (
              <option key={type} value={type} >{type}</option>
            ))}
          </select>
        </div>

        {/* {enableFromAccountTypeId && (
          <div className="col-12 mb-3 mt-3">

            <div className="form-check form-check-inline">
              <select onChange={(e) => {
                const selectedAccountId = e.target.value;
                setTransfersFromType(selectedAccountId);
                 console.log("Selected account ID:", selectedAccountId);
              }}>
                {fromAccountTypeIds.map((accountType) => (
                  <option value={accountType.id} >{accountType.description}</option>
                ))}
              </select>

            </div>
          </div>
        )} */}
        {enableFromAccountTypeId && (
  <div className="col-12 mb-3 mt-3">
    <div className="form-check form-check-inline">
      <select 
        onChange={(e) => {
          const selectedAccountId = e.target.value;
          setTransfersFromType(selectedAccountId);
          console.log("Selected account ID:", selectedAccountId);
        }}
       // checked={isChecked('toAccountTypeIds', accountType.id)}
        defaultValue="" // Set the default value to an empty string
      >
        <option value="" disabled>Select an account type</option> {/* Placeholder option */}
        {fromAccountTypeIds.map((accountType) => (
          
          <option key={accountType.id} value={accountType.id}>{accountType.description}</option>
        ))}
      </select>
    </div>
  </div>
)}


        <div className="col-12 mt-3">
          <div className="accordion accordion-flush" id="accordionFlushExample">
            <div className="accordion-item">
              <h2 className="accordion-header" id="flush-headingTwo">
                <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
                  To Account Type IDs:
                </button>
              </h2>
              <div id="flush-collapseTwo" className="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample">
                <div className="accordion-body">
                  {accountTypes.map((accountType) => (
                    <div key={accountType.id} className="form-check form-check-inline col-6 col-lg-3">
                      <input
                        type="checkbox"
                        className="form-check-input"
                        id={`to-${accountType.id}`}
                        name="toAccountTypeIds"
                        value={accountType.id}
                        checked={isChecked('toAccountTypeIds', accountType.id)}
                        onChange={(e) => handleAccountTypeChange(e, 'toAccountTypeIds')}
                      />
                      <label className="form-check-label" htmlFor={`to-${accountType.id}`}>{accountType.description}</label>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="col-12 col-lg-3 mb-3">
          <label className="form-label">Core Interface Operation:</label>
          <input
            type="text"
            className="form-control"
            name="coreInterfaceOperation"
            value={formData.coreInterfaceOperation}
            onChange={handleChange}
          />
        </div>

       

        {/* <div className="col-12 col-lg-3 mb-3 form-check radio-disable">
          <label className="form-check-label">
            <input
              className="form-check-input"
              type="radio"
              name="isEnabled"
              value="false"
              checked={formData.isEnabled === false}
              onChange={handleChange}
            />
            Disable
          </label> 
        </div>*/}

        <div className="col-12 col-lg-3 mb-3">
          <label className="form-label">Created At:</label>
          <input
            type="date"
            className="form-control"
            name="createdAt"
            value={formData.createdAt}
            onChange={handleChange}
          />
        </div>

        <div className="col-12 col-lg-3 mb-3">
          <label className="form-label">ISO Code:</label>
          <input
            type="text"
            className="form-control"
            name="isoCode"
            value={formData.isoCode}
            onChange={handleChange}
          />
        </div>
      </div>
      <div className="col-12 col-lg-2 mb-3 form-check radio-enable">
          <label className="form-check-label">
            <input
              className="form-check-input"
              type="checkbox"
              name="isEnabled"
              value="true"
              checked={formData.isEnabled === true}
              onChange={handleChange}
            />
            Enable
          </label>
        </div>
      <div className="col-12 col-lg-3 mb-3">
        <button type="submit" className="btn btn-primary">add</button>
      </div>
      <div className="col-12 col-lg-3 mb-3">
        <button type="button" className="btn btn-secondary" onClick={submitAllDetails}>submit</button>
      </div>
    </form>
  );
};

export default UpdatedTransactionForm;
