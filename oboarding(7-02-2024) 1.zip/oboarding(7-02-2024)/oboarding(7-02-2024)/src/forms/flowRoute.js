import React, { useState, useEffect } from 'react';
import './css/style.css';
import { useLocation, useNavigate } from 'react-router-dom';
import { useFormContext } from '../button/signleButton';  
import axios from 'axios';

function FlowRoute({ onSubmitClick, fiId }) {
  const { updateForm } = useFormContext();
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({

    financialInstitutionId: '',
    operation_type: '',
    flowName: '',
    isEnabled: false,
    createdAt: ''
  });
  const location = useLocation();
  const navigate = useNavigate();
  const { financial_institution_id = '', a = '' } = location.state || {};

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prevFormData) => ({
      ...prevFormData,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  // useEffect(() => {
  //   setFormData((prevFormData) => ({
  //     ...prevFormData
    
  //   }));
  // }, [fiId, a]);

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form submitted with data:", formData);

  };

  const submitFlowRoute = (e) => {
    e.preventDefault();
    console.log(a);
    // const headers = {
    //   'fiId': a
    // };
    updateForm('flowRouteData', [formData]);
   // updateForm('fiId', {headers}); 
    onSubmitClick("data-mapping");
   // navigate('/data-mapping', { state: { financial_institution_id, a } })
    // axios.post("http://localhost:8083/onbording/flowRoute", [formData], { headers })
    //   .then((res) => {
    //     navigate('/data-mapping', { state: { financial_institution_id, a } })
    //     console.log(res)
    //   })
    //   .catch((err) => console.log(err));
  };


  return (
    <div className="container">
      {/* <div className="col-12 mt-3 mb-3"> */}
      {/* <h1>If you want to add any flow click on add otherwise next</h1> */}
      <b> <p>Financial Institution ID: {fiId}</p> </b>
      {!showForm &&
        <div className="col-12 text-center">
           <button onClick={(e) => submitFlowRoute(e)} className="btn btn-info btn-lg">next</button>
          <button onClick={() => setShowForm(true)} className="btn btn-info btn-lg mr-2">add new script</button>         
        </div>}


      {showForm && (

        <form onSubmit={handleSubmit} style={{ marginTop: '20px' }}>
          <div className='row'>

            <div className='col-12 col-lg-3 mb-3'>
              <label>Operation Type<span className="text-danger">*</span></label>
              <input
                type="text"
                name="operation_type"
                value={formData.operation_type}
                onChange={handleChange}
                required
              />
            </div>
            <div className='col-12 col-lg-3 mb-3'>
              <label>Flow Name<span className="text-danger">*</span></label>
              <input
                type="text"
                name="flowName"
                value={formData.flowName}
                onChange={handleChange}
                required
              />
            </div>

            <div className='col-12 col-lg-3 mb-3 '>
              <label>Created At<span className="text-danger">*</span></label>
              <input
                type="date"
                name="createdAt"
                value={formData.createdAt}
                onChange={handleChange}
                required
              />
            </div>
            <div className='col-12 col-lg-3 mb-3 mt-4'>

              <input
                type="radio"
                name="isEnabled"
                checked={formData.isEnabled}
                onChange={handleChange}
              />
              <label>Active<span className="text-danger">*</span></label>
            </div>
            <div className="col-12 text-right">
              <button type="submit" className="btn btn-info btn-lg">Submit</button>
            </div>

          </div>
        </form>

      )}
      {/* </div> */}
    </div>
  );
}

export default FlowRoute;
