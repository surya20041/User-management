import React, { useEffect, useState } from "react";

const ViewCoreConnectivity = ({ editData }) => {
  const [coreConnectivity, setCoreConnectivity] = useState({});

  useEffect(() => {
    setCoreConnectivity(editData);
  }, [editData]);

  console.log(coreConnectivity);

  return (
    <>
      <div className="col-12">
        <div className="row">
          <div className="col-4">
            <p><b>Financial Institution ID:</b> {coreConnectivity.financialInstitutionId}</p>
            <p><b>Core Name:</b> {coreConnectivity.coreName}</p>
            <p><b>Host:</b> {coreConnectivity.host}</p>
            <p><b>Port:</b> {coreConnectivity.port}</p>
          </div>
          <div className="col-4">
            <p><b>Base Path:</b> {coreConnectivity.basepath}</p>
            <p><b>Message ID:</b> {coreConnectivity.messageId}</p>
            <p><b>Branch ID:</b> {coreConnectivity.branchId}</p>
            <p><b>Processor User:</b> {coreConnectivity.processorUser}</p>
          </div>
          <div className="col-4">
            <p><b>Device Type:</b> {coreConnectivity.deviceType}</p>
            <p><b>Device Number:</b> {coreConnectivity.deviceNumber}</p>
            <p><b>User Name:</b> {coreConnectivity.userName}</p>
            <p><b>Password:</b> ***********</p>
          </div>
          <div className="col-4">
          <p><b>Admin Password:</b> ***********</p>
            <p><b>Findby Service Path:</b> {coreConnectivity.findbyServicePath}</p>
            <p><b>Account Service Path:</b> {coreConnectivity.accountServicePath}</p>
            <p><b>Transaction Service Path:</b> {coreConnectivity.transactionServicePath}</p>
          </div>
          <div className="col-4">
            <p><b>Active Flag:</b> {coreConnectivity.activeFlag ? "Active" : "Inactive"}</p>
            <p><b>Created Date:</b> {coreConnectivity.createdDate}</p>
            <p><b>Modified Date:</b> {coreConnectivity.modifiedDate}</p>
            <p><b>Created By:</b> {coreConnectivity.createdBy}</p>
          </div>
        </div>
      </div>
    </>
  );
};

export default ViewCoreConnectivity;
