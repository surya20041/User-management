import axios from "axios";
import React, { useEffect, useState } from "react";
// import { useLocation } from "react-router-dom";

function ViewFiIdDetails(viewFiId) {
    // console.log(viewFiId)
    // const location = useLocation();
    // const { fiId } = location.state;

    const [financialInstitution, setFinancialInstitution] = useState(null);
    const [transactionCapability, setTransactionCapability] = useState([]);
    const fiId = viewFiId.viewFiId;
    useEffect(() => {

        console.log("fiId", fiId)

        axios.get("http://localhost:8083/onbording/getAllData?fiId=" + fiId)

            
            .then((res) => {
                setFinancialInstitution(res.data.financialInstitution);
                setTransactionCapability(res.data.transactionCapability);
                //   console.log(res.data);
            }).catch((err) => {
                //  console.error("API Error:", err);
            });
    }, [fiId]);

    return (
        <>

            {/* <nav>
<div class="nav nav-tabs" id="nav-tab" role="tablist">
<button class="nav-link col-4 active" id="nav-tab-1" data-bs-toggle="tab" data-bs-target="#nav-1" type="button" role="tab" aria-controls="nav-1" aria-selected="true">Tab 1</button>
<button class="nav-link col-4" id="nav-tab-2" data-bs-toggle="tab" data-bs-target="#nav-2" type="button" role="tab" aria-controls="nav-2" aria-selected="false" tabindex="-1">Tab 2</button>
<button class="nav-link col-4" id="nav-tab-3" data-bs-toggle="tab" data-bs-target="#nav-3" type="button" role="tab" aria-controls="nav-3" aria-selected="false" tabindex="-1">Tab 3</button>
</div>
</nav> */}
            <nav>
                <div className="nav nav-tabs" id="nav-tab" role="tablit">
                    <button className="nav-link col-6 active" id="nav-tab-1" data-bs-toggle="tab" data-bs-target="#nav-1"
                        role="tab" aria-controls="nav-1" aria-selected="true"
                    >Financial Institution</button>
                    <button className="nav-link col-6 " id="nav-tab-2" data-bs-toggle="tab" data-bs-target="#nav-2"
                        role="tab" aria-controls="nav-2" aria-selected="false" tabIndex="-1">
                        Transaction Capablility
                    </button>
                </div>
            </nav>



            <div className="tab-content" id="nav-tabContent">
                {financialInstitution ? (
                    <div id="nav-1" className="tab-pane fade show active" role="tabpanel" aria-labelledby="nav-tab-1">
                        <div className="row mt-4">
                            <div className="col-4">
                                <p><b>Financial Institution:</b> {financialInstitution.financialInstitutionId}</p>
                                <p><b>Name:</b> {financialInstitution.name}</p>
                                <p><b>Bin:</b> {financialInstitution.bin}</p>
                                <p><b>Api Type:</b> {financialInstitution.apiType}</p>
                              
                            </div>
                            <div className="col-4 brdr">
                                <p><b>Core Name:</b> {financialInstitution.coreName}</p>
                                <p><b>Created At:</b> {financialInstitution.createdAt}</p>
                                <p><b>Default Account Type:</b> {financialInstitution.defAccTypeId}</p>
                                <p><b>Include Unlinked Accounts:</b> {financialInstitution.includeUnlinkedAccounts ? 'Yes' : 'No'}</p>
                               
                            </div>
                            <div className="col-4 ">
                                    <p><b>Is Enabled:</b> {financialInstitution.isEnabled ? 'Yes' : 'No'}</p>
                                    <p><b>Maximum Amount:</b> {financialInstitution.maxAmount}</p>
                                    <p><b>Minimum Amount:</b> {financialInstitution.minAmount}</p>
                                    
                                </div>
<hr/>
                            <div className="col-12">
                            <p><b>Transaction Types:</b> {financialInstitution.transactionType}</p>
  <p><b>Api Url: </b> {financialInstitution.apiUrl}</p>
                                </div>
                        </div>

                    </div>
                ) : (
                    <p><b>No data available</b></p>
                )}

                {transactionCapability.length > 0 ? (
                    <div className="tab-pane fade" id="nav-2" role="tabpanel" aria-labelledby="nav-tab-2">
                        <table className="table table-striped table-hover ">
                            <thead>
                                <tr>
                                    <th scope="col">s.no</th>
                                    <th scope="col">financialInstitutionId</th>
                                    <th scope="col">fromAccountTypeId</th>
                                    <th scope="col">toAccountTypeId</th>
                                    <th scope="col">transactionType</th>
                                </tr>
                            </thead>
                            <tbody>
                                {transactionCapability.map((transactionDetails, index) => (
                                    <tr key={transactionDetails.id}>
                                        <td>{index + 1}</td>
                                        <td>{transactionDetails.financialInstitutionId}</td>
                                        <td>{transactionDetails.fromAccountTypeId}</td>
                                        <td>{transactionDetails.toAccountTypeId}</td>
                                        <td>{transactionDetails.transactionType}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                ) : (
                    <p><b>No transaction capabilities available</b></p>
                )}
            </div>
        </>
    );
}

export default ViewFiIdDetails;
