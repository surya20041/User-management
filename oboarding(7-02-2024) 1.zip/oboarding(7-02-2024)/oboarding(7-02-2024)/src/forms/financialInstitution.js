import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useFormContext } from '../button/signleButton';  
import './css/style.css';
 
function FinancialInstitution({ onSubmitClick }) {
    const [financialInstitutionId, setFinancialInstitution_Id] = useState("");
    const [bin, setBin] = useState("");
    const [name, setName] = useState("");
    const [coreName, setCoreName] = useState("");
    const [apiType, setApiType] = useState("");
    const [apiUrl, setApiUrl] = useState("");
    const [isEnabled, setIsEnabled] = useState(false);
    const [createdAt, setCreatedAt] = useState("");
    const [transactionType, setTransactionType] = useState("");
    const [minAmount, setMinAmount] = useState("");
    const [maxAmount, setMaxAmount] = useState("");
    const [defAccTypeId, setDefAccTypeId] = useState("");
    const [includeUnlinkedAccounts, setIncludeUnlinkedAccounts] = useState(false);
 
    const { updateForm } = useFormContext();
   // const navigate = useNavigate();
 
    function handleCheckboxChange(e) {
        const value = e.target.value;
        let updatedTransactionType = transactionType.split(',').filter(v => v);
       
        if (e.target.checked) {
            updatedTransactionType = [...updatedTransactionType, value];
        } else {
            updatedTransactionType = updatedTransactionType.filter(v => v !== value);
        }
       
        setTransactionType(updatedTransactionType.join(','));
    }
 
    function submitData(e) {
        e.preventDefault();
 
        const financialInstitutionFormData = {
            financialInstitutionId,
            bin,
            name,
            coreName,
            apiType,
            apiUrl,
            isEnabled,
            createdAt,
            transactionType,
            minAmount,
            maxAmount,
            defAccTypeId,
            includeUnlinkedAccounts
        };
       // const a = 1;
 
       
 
        updateForm('financialInstitution', financialInstitutionFormData);
        // console.log(financialInstitutionFormData);
        const finId =financialInstitutionId;
        onSubmitClick("Transactioncapbality", finId, transactionType);  
       // navigate('/next-form', { state: { fiId, transactionType, a } });
 
       
        /*
        axios.post('http://localhost:8083/onbording/financialInstitution', financialInstitutionFormData)
            .then(response => {
                console.log(response.data.id);
                const a = response.data.id;
                // Navigate to the next form, passing the necessary data
                navigate('/next-form', { state: { financialInstitutionId, transactionType, a } });
            })
            .catch(error => console.error("There was an error submitting the form!", error));
        */
    }
 
    return (
       <>
   
            <form onSubmit={submitData}>
                <div className="row">
                    <div className="col-12 col-lg-3 mb-3">
                        <label htmlFor="financialInstitutionId" className="form-label">Financial Institution ID<span className="text-danger">*</span></label>
                        <input
                            type="text"
                            id="financialInstitutionId"
                            name="financialInstitutionId"
                            className="form-control form-control-lg"
                            value={financialInstitutionId}
                            onChange={(e) => setFinancialInstitution_Id(e.target.value)}
                            required
                        />
                    </div>
                    
                    <div className="col-12 col-lg-3 mb-3">
                        <label htmlFor="name" className="form-label">Name<span className="text-danger">*</span></label>
                        <input
                            type="text"
                            id="name"
                            name="name"
                            className="form-control form-control-lg"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            required
                        />
                    </div>
                    <div className="col-12 col-lg-3 mb-3">
                        <label htmlFor="coreName" className="form-label">Core Name<span className="text-danger">*</span></label>
                        <input
                            type="text"
                            id="coreName"
                            name="coreName"
                            className="form-control form-control-lg"
                            value={coreName}
                            onChange={(e) => setCoreName(e.target.value)}
                            required
                        />
                    </div>
                    <div className="col-12 col-lg-3 mb-3">
                        <label htmlFor="bin" className="form-label">BIN<span className="text-danger">*</span></label>
                        <input
                            type="text"
                            id="bin"
                            name="bin"
                            className="form-control form-control-lg"
                            value={bin}
                            onChange={(e) => setBin(e.target.value)}
                            required
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label htmlFor="apiType" className="form-label">API Type<span className="text-danger">*</span></label>
                        <input
                            type="text"
                            id="apiType"
                            name="apiType"
                            className="form-control form-control-lg"
                            value={apiType}
                            onChange={(e) => setApiType(e.target.value)}
                            required
                        />
                    </div>
                    <div className="col-12 col-lg-8 mb-3">
                        <label htmlFor="apiUrl" className="form-label">API URL<span className="text-danger">*</span></label>
                        <input
                            type="text"
                            id="apiUrl"
                            name="apiUrl"
                            className="form-control form-control-lg"
                            value={apiUrl}
                            onChange={(e) => setApiUrl(e.target.value)}
                            required
                        />
                    </div>
                    <div className="col-12 col-lg-12 mb-3">
                        <label className="form-label">Transaction Type<span className="text-danger">*</span></label><br />
                        {['DISPLAY', 'CASHWITHDRAWAL', 'CASHDEPOSIT', 'CHECKDEPOSIT', 'CASHCHECKDEPOSIT', 'CASHWITHDRAWALREVERSAL', 'CASHDEPOSITREVERSAL', 'CHECKDEPOSITADVICE', 'CASHCHECKDEPOSITREVERSAL', 'TRANSFER', 'TRANSFERREVERSAL', 'BALANCEINQUIRY', 'CASHDEPOSITADVICE', 'CASHCHECKDEPOSITADVICE', 'CHECKDEPOSITADVICE'].map(type => (
                            <div key={type} className="form-check form-check-inline">
                                <input
                                    className="form-check-input"
                                    type="checkbox"
                                    id={`transactionType_${type.toLowerCase()}`}
                                    name="transactionType"
                                    value={type}
                                    onChange={handleCheckboxChange}
                                />
                                <label className="form-check-label" htmlFor={`transactionType_${type.toLowerCase()}`}>{type}</label>
                            </div>
                        ))}
                    </div>
                    <div className="col-12 col-lg-3 mb-3">
                        <label htmlFor="createdAt" className="form-label">Created At<span className="text-danger">*</span></label>
                        <input
                            type="date"
                            id="createdAt"
                            name="createdAt"
                            className="form-control form-control-lg"
                            value={createdAt}
                            onChange={(e) => setCreatedAt(e.target.value)}
                            required
                        />
                    </div>
                    <div className="col-12 col-lg-3 mb-3">
                        <label htmlFor="minAmount" className="form-label">Min Amount<span className="text-danger">*</span></label>
                        <input
                            type="text"
                            id="minAmount"
                            name="minAmount"
                            className="form-control form-control-lg"
                            value={minAmount}
                            onChange={(e) => setMinAmount(e.target.value)}
                            required
                        />
                    </div>
                    <div className="col-12 col-lg-3 mb-3">
                        <label htmlFor="maxAmount" className="form-label">Max Amount<span className="text-danger">*</span></label>
                        <input
                            type="text"
                            id="maxAmount"
                            name="maxAmount"
                            className="form-control form-control-lg"
                            value={maxAmount}
                            onChange={(e) => setMaxAmount(e.target.value)}
                            required
                        />
                    </div>
                    <div className="col-12 col-lg-3 mb-3">
                        <label htmlFor="defAccTypeId" className="form-label">Def account type id<span className="text-danger">*</span></label>
                        <input
                            type="number"  
                            className="form-control form-control-lg"
                            id="defAccTypeId"
                            name="defAccTypeId"
                            value={defAccTypeId}
                            onChange={(e) => setDefAccTypeId(e.target.value)}
                            required
                        />
                    </div>
                    <div className="col-12 col-lg-3 mb-3">
                        <label className="form-label">Include unlinked accounts<span className="text-danger">*</span></label>
                        <input
                            type="radio"                      
                           className="form-check-input"
                            id="includeUnlinkedAccounts"
                            name="includeUnlinkedAccounts"
                            value={includeUnlinkedAccounts}
                            onChange={(e) => setIncludeUnlinkedAccounts(e.target.checked)}
                            required
                        />
                    </div>
                    <div className="col-12 col-lg-3 form-check mt-3 mb-3 radio-enable">
                        <label className="form-check-label">
                            <input
                                className="form-check-input"
                                type="radio"
                                id="isEnabled"
                                name="isEnabled"
                                checked={isEnabled}
                                onChange={(e) => setIsEnabled(e.target.checked)}
                            /> Active <span className="text-danger">*</span>
                        </label>
                    </div>
                    <div className="col-12 text-right">
                        <button type="submit" className="btn btn-primary btn-lg">Next</button>
                    </div>
                </div>
            </form>
            </>
    );
}
 
export default FinancialInstitution;
 