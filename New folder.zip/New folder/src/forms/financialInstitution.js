import React, { useState, useEffect } from 'react';
import { useFormContext } from '../button/signleButton';
import axios from 'axios';
import './css/style.css';
import Select from 'react-select'

const allTranTypes =  [
    { value:'DISPLAY', label:'DISPLAY' },
    { value:'CASHWITHDRAWAL', label:'CASHWITHDRAWAL' },
    { value:'CASHDEPOSIT', label:'CASHDEPOSIT' },
    { value:'CHECKDEPOSIT', label:'CHECKDEPOSIT' },
    { value:'CASHCHECKDEPOSIT', label:'CASHCHECKDEPOSIT' },
    { value:'CASHWITHDRAWALREVERSAL', label:'CASHWITHDRAWALREVERSAL' },
    { value:'CASHDEPOSITREVERSAL', label:'CASHDEPOSITREVERSAL' },
    { value:'CASHCHECKDEPOSITREVERSAL', label:'CASHCHECKDEPOSITREVERSAL' },
    { value:'BALANCEINQUIRY', label:'BALANCEINQUIRY' },
    { value:'CASHDEPOSITADVICE', label:'CASHDEPOSITADVICE' },
    { value:'CASHCHECKDEPOSITADVICE', label:'CASHCHECKDEPOSITADVICE' },
    { value:'CHECKDEPOSITADVICE', label:'CHECKDEPOSITADVICE' },
    { value:'CHECKDEPOSITCASHBACK', label:'CHECKDEPOSITCASHBACK' },
    { value:'TRANSFER', label:'TRANSFER' },
    { value:'TRANSFERREVERSAL', label:'TRANSFERREVERSAL' }
    
   ]

function FinancialInstitution({ onSubmitClick }) {
    const [financialInstitutionId, setFinancialInstitution_Id] = useState("");
    const [bin, setBin] = useState("");
    const [name, setName] = useState("");
    const [coreName, setCoreName] = useState("");
    const [apiType, setApiType] = useState("");
    const [apiUrl, setApiUrl] = useState("");
    const [isEnabled, setIsEnabled] = useState(false);
  // const [createdAt, setCreatedAt] = useState("");
    const [transactionType, setTransactionType] = useState("");
    const [minAmount, setMinAmount] = useState("");
    const [maxAmount, setMaxAmount] = useState("");
    const [defAccTypeId, setDefAccTypeId] = useState("");
    const [includeUnlinkedAccounts, setIncludeUnlinkedAccounts] = useState(false);
    const [accountsData, setAccountsData] = useState([]);

    const { updateForm } = useFormContext();

    useEffect(() => {
        const fetchAccountsData = async () => {
            try {
                const response = await axios.get('http://localhost:8083/onbording/displayAllAccounts');
                const sortedData = Array.isArray(response.data) ? response.data.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)) : [];
                setAccountsData(sortedData);
            } catch (error) {
                console.error("Error fetching data:", error);
            }
        };
        fetchAccountsData();
    }, []);

    // function handleCheckboxChange(e) {
    //     const value = e.target.value;
    //     let updatedTransactionType = transactionType.split(',').filter(v => v);

    //     if (e.target.checked) {
    //         updatedTransactionType = [...updatedTransactionType, value];
    //     } else {
    //         updatedTransactionType = updatedTransactionType.filter(v => v !== value);
    //     }

    //     setTransactionType(updatedTransactionType.join(','));
    // }
    const handleCheckboxChange = (selectedOptions) => {
       
    const updatedTransactionTypeArray = selectedOptions ? selectedOptions.map(option => option.value) : [];
    setTransactionType(updatedTransactionTypeArray.join(','));
        
    }
    function submitData(e) {
        e.preventDefault();

        const financialInstitutionFormData = {
            financialInstitutionId,
            bin,
            name,
            coreName,
            apiType,
            apiUrl,
            isEnabled,
 //createdAt,
            transactionType,
            minAmount,
            maxAmount,
            defAccTypeId,
            includeUnlinkedAccounts,
            createdAt: new Date().toISOString().split('T')[0]
        };

        updateForm('financialInstitution', financialInstitutionFormData);
        const finId = financialInstitutionId;
        onSubmitClick("Transactioncapbality", finId, transactionType);
    }

    return (
        <>
            <form onSubmit={submitData}>
                <div className="row">
                    <div className="col-12 col-lg-3 mb-3 mt-3">
                        <label htmlFor="financialInstitutionId" className="form-label">Financial Institution<span className="text-danger">*</span></label>
                        <input
                            type="text"
                            id="financialInstitutionId"
                            name="financialInstitutionId"
                            className="form-control form-control-lg"
                            value={financialInstitutionId}
                            onChange={(e) => setFinancialInstitution_Id(e.target.value)}
                            required
                        />
                    </div>
                    
                    <div className="col-12 col-lg-3 mb-3 mt-3">
                        <label htmlFor="name" className="form-label">Name<span className="text-danger">*</span></label>
                        <input
                            type="text"
                            id="name"
                            name="name"
                            className="form-control form-control-lg"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            required
                        />
                    </div>
                    <div className="col-12 col-lg-3 mb-3 mt-3">
                        <label htmlFor="coreName" className="form-label">Core Name<span className="text-danger">*</span></label>
                        <input
                            type="text"
                            id="coreName"
                            name="coreName"
                            className="form-control form-control-lg"
                            value={coreName}
                            onChange={(e) => setCoreName(e.target.value)}
                            required
                        />
                    </div>
                    <div className="col-12 col-lg-3 mb-3 mt-3">
                        <label htmlFor="bin" className="form-label">BIN<span className="text-danger">*</span></label>
                        <input
                            type="text"
                            id="bin"
                            name="bin"
                            className="form-control form-control-lg"
                            value={bin}
                            onChange={(e) => setBin(e.target.value)}
                            required
                        />
                    </div>
                    <div className="col-12 col-lg-3 mb-3">
                        <label htmlFor="apiType" className="form-label">API Type<span className="text-danger">*</span></label>
                        <select
                            id="apiType"
                            name="apiType"
                            className="form-control form-control-lg"
                            value={apiType}
                            onChange={(e) => setApiType(e.target.value)}
                            required
                        >
                            <option value="">Select API Type </option>
                            <option value="REST">REST</option>
                            <option value="SOAP">SOAP</option>
                        </select>
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label htmlFor="apiUrl" className="form-label">API URL<span className="text-danger">*</span></label>
                        <input
                            type="text"
                            id="apiUrl"
                            name="apiUrl"
                            className="form-control form-control-lg"
                            value={apiUrl}
                            onChange={(e) => setApiUrl(e.target.value)}
                            required
                        />
                    </div>
                    <div className="col-12 col-lg-3 form-check mt-4 mb-3 radio-enable text-center">
                        <label htmlFor="includeUnlinkedAccounts" className="form-check-label">
                        <input
                            type="checkbox"
                            className="form-check-input"
                            id="includeUnlinkedAccounts"
                            name="includeUnlinkedAccounts"
                            checked={includeUnlinkedAccounts}
                            onChange={(e) => setIncludeUnlinkedAccounts(e.target.checked)}
                        />
                        Include Unlinked Accounts<span className="text-danger">*</span></label>
                    </div>
                    <div className="col-12 col-lg-2 form-check mt-4 mb-3 radio-enable text-center">
                        <label className="form-check-label">
                            <input
                                className="form-check-input"
                                type="checkbox"
                                id="isEnabled"
                                name="isEnabled"
                                checked={isEnabled}
                                onChange={(e) => setIsEnabled(e.target.checked)}
                            /> Active <span className="text-danger">*</span>
                        </label>
                    </div>
                   
                    <div className="col-12 col-lg-12 mb-3">
                    <label className="form-label">Transaction Type:</label> 
                        <Select 
                           options={allTranTypes}
                           value={transactionType.split(',').filter(Boolean).map(value => allTranTypes.find(option => option.value === value))}
          
                           onChange={handleCheckboxChange}
                           isMulti ={true}
                        />
                    </div>
                    {/* <div className="col-12 col-lg-12 mb-3">
                        <label className="form-label">Transaction Type<span className="text-danger">*</span></label><br />
                        {['DISPLAY', 'CASHWITHDRAWAL', 'CASHDEPOSIT', 'CHECKDEPOSIT', 'CASHCHECKDEPOSIT', 'CASHWITHDRAWALREVERSAL', 'CASHDEPOSITREVERSAL', 'CHECKDEPOSITADVICE', 'CASHCHECKDEPOSITREVERSAL', 'TRANSFER', 'TRANSFERREVERSAL', 'BALANCEINQUIRY', 'CASHDEPOSITADVICE', 'CASHCHECKDEPOSITADVICE', 'CHECKDEPOSITADVICE'].map(type => (
                            <div key={type} className="form-check col-3 form-check-inline">
                                <input
                                    className="form-check-input"
                                    type="checkbox"
                                    id={`transactionType_${type.toLowerCase()}`}
                                    name="transactionType"
                                    value={type}
                                    onChange={handleCheckboxChange}
                                />
                                <label className="form-check-label" htmlFor={`transactionType_${type.toLowerCase()}`}>{type}</label>
                            </div>
                        ))}
                    </div> */}
                    <div className="col-12 col-lg-3 mb-3">
                        <label htmlFor="minAmount" className="form-label">Minimum Amount<span className="text-danger">*</span></label>
                        <input
                            type="text"
                            id="minAmount"
                            name="minAmount"
                            className="form-control form-control-lg"
                            value={minAmount}
                            onChange={(e) => setMinAmount(e.target.value)}
                            required
                        />
                    </div>
                    <div className="col-12 col-lg-3 mb-3">
                        <label htmlFor="maxAmount" className="form-label">Maximum Amount<span className="text-danger">*</span></label>
                        <input
                            type="text"
                            id="maxAmount"
                            name="maxAmount"
                            className="form-control form-control-lg"
                            value={maxAmount}
                            onChange={(e) => setMaxAmount(e.target.value)}
                            required
                        />
                    </div>
                    <div className="col-12 col-lg-3 mb-3">
                        <label htmlFor="defAccTypeId" className="form-label">Default Account Type<span className="text-danger">*</span></label>
                        <select
                            className="form-control form-control-lg"
                            id="defAccTypeId"
                            name="defAccTypeId"
                            value={defAccTypeId}
                            onChange={(e) => setDefAccTypeId(e.target.value)}
                            required
                        >
                            <option value="">Select Account Type</option>
                            {accountsData.map((account, index) => (
                                <option key={index} value={account.id}>
                                    {account.description}
                                </option>
                            ))}
                        </select>
                    </div>
                    
                    <div className="col-12 text-right">
                        <button type="submit" className="btn btn-info">Next</button>
                    </div>
                </div>
            </form>
        </>
    );
}

export default FinancialInstitution;
