import React, { useEffect, useState, useCallback } from 'react';
import axios from 'axios';
import AddDataForm from './AddDataForm';
import EditDataForm from './EditDataForm';
import { useNavigate } from 'react-router-dom';

const ViewData = () => {
    const [allData, setAllData] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);
    const [editingItem, setEditingItem] = useState(null);
    const [showAddModal, setShowAddModal] = useState(false);
    const itemsPerPage = 100;
    const navigate = useNavigate();

    const fetchData = useCallback(async () => {
        setIsLoading(true);
        setError(null);
        try {
            const response = await axios.get('http://localhost:8083/onbording/all-app-properties');
            console.log('API Response:', response.data);

            if (Array.isArray(response.data)) {
                setAllData(response.data);
            } else {
                throw new Error('Invalid data format received from server');
            }
        } catch (error) {
            console.error('Failed to fetch data:', error);
            setError('Failed to load data. Please try again later.');
            setAllData([]);
        } finally {
            setIsLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchData();
    }, [fetchData]);

    const handlePageChange = (newPage) => {
        setCurrentPage(newPage);
    };

    const handleEdit = (item) => {
        setEditingItem(item);
    };

    const handleUpdate = async (updatedItem) => {
        try {
            await axios.put(`http://localhost:8083/onbording/edit/${updatedItem.id}`, updatedItem);
            setEditingItem(null);
            fetchData();
        } catch (error) {
            console.error('Failed to update item:', error);
        }
    };

    const handleAdd = () => {
        fetchData();
        setShowAddModal(false);
    };

    const totalPages = Math.ceil(allData.length / itemsPerPage);
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const currentData = allData.slice(startIndex, endIndex);

    if (isLoading) return <div>Loading...</div>;
    if (error) return <div>{error}</div>;

    return (
        <div>
            <h1 className="h3 mb-3">App Properties</h1>
            <div className="row">
                <div className="col-12">
                    <div className="card">
                        <div className="card-body">
                            {editingItem ? (
                                <EditDataForm
                                    data={editingItem}
                                    onUpdate={handleUpdate}
                                    onCancel={() => setEditingItem(null)}
                                />
                            ) : (
                                <>
                                    {currentData.length > 0 ? (
                                        <>
                                            <div className="table-responsive">
                                                <table className="table table-bordered table-hover">
                                                    <thead className="thead-light">
                                                        <tr>
                                                            <th>ID</th>
                                                            <th>App Name</th>
                                                            <th>Environment</th>
                                                            <th>Property Key</th>
                                                            <th>Property Value</th>
                                                            <th>Last Modified Time</th>
                                                            <th>Created Date</th>
                                                            <th>Modified Date</th>
                                                            <th>Created By</th>
                                                            <th>Modified By</th>
                                                            <th>Edit</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {currentData.map((item) => (
                                                            <tr key={item.id}>
                                                                <td>{item.id}</td>
                                                                <td>{item.appName}</td>
                                                                <td>{item.env}</td>
                                                                <td>{item.propKey}</td>
                                                                <td>{item.propVal}</td>
                                                                <td>{item.lastModifiedTime}</td>
                                                                <td>{item.createdDate}</td>
                                                                <td>{item.modifiedDate}</td>
                                                                <td>{item.createdBy}</td>
                                                                <td>{item.modifiedBy}</td>
                                                                <td>
                                                                    <button className="btn btn-sm btn-primary" onClick={() => handleEdit(item)}>
                                                                        <i className="fas fa-pencil-alt"></i>
                                                                    </button>
                                                                </td>
                                                            </tr>
                                                        ))}
                                                    </tbody>
                                                </table>
                                            </div>
                                            <div className="d-flex justify-content-between align-items-center mb-3">
                                                <div>
                                                    <button className="btn btn-secondary me-2" onClick={() => handlePageChange(currentPage - 1)} disabled={currentPage === 1}>
                                                        Previous
                                                    </button>
                                                    <span> Page {currentPage} of {totalPages} </span>
                                                    <button className="btn btn-secondary ms-2" onClick={() => handlePageChange(currentPage + 1)} disabled={currentPage === totalPages}>
                                                        Next
                                                    </button>
                                                </div>
                                                <button type="button" className="btn btn-primary" onClick={() => setShowAddModal(true)}>
                                                    Add App Properties
                                                </button>
                                            </div>
                                            {showAddModal && (
                                                <div className="modal show" style={{ display: 'block' }}>
                                                    <div className="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
                                                        <div className="modal-content">
                                                            <div className="modal-header">
                                                                <h5 className="modal-title">New App Properties</h5>
                                                                <button type="button" className="btn-close" onClick={() => setShowAddModal(false)}></button>
                                                            </div>
                                                            <div className="modal-body">
                                                                <AddDataForm onAdd={handleAdd} onClose={() => setShowAddModal(false)} />
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            )}
                                        </>
                                    ) : (
                                        <p>No data available.</p>
                                    )}
                                </>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ViewData;
