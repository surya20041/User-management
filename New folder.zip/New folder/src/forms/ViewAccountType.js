import React, { useEffect,useState } from "react";

const ViewAccountType=({editData})=>{
    const [account, setAccount] = useState({});
    
    
    useEffect(()=>{
        setAccount(editData)
    }, [editData])
    console.log(account)
    return(
         <>
        <div className="col-12">
            <div className="row">
                <div className="col-4">
                    <p><b>Standardized Account Type:</b> {account.standarizedAccountType}</p>
                    <p><b>Account Type:</b> {account.standarizedAccountType}</p>
                    <p><b>Standardized Account Type:</b> {account.standarizedAccountType}</p>
                    <p><b>Account Type:</b> {account.standarizedAccountType}</p>
                </div>
                <div className="col-4">
                <p><b>Standardized Account Type:</b> {account.standarizedAccountType}</p>
                    <p><b>Account Type:</b> {account.standarizedAccountType}</p>
                    <p><b>Standardized Account Type:</b> {account.standarizedAccountType}</p>
                    <p><b>Account Type:</b> {account.standarizedAccountType}</p>
                </div>
                <div className="col-4">
                <p><b>Standardized Account Type:</b> {account.standarizedAccountType}</p>
                    <p><b>Account Type:</b> {account.standarizedAccountType}</p>
                    <p><b>Standardized Account Type:</b> {account.standarizedAccountType}</p>
                    <p><b>Account Type:</b> {account.standarizedAccountType}</p>
                </div>
            </div>
        </div>


        ///
        <div className="d-flex" >
        <div className="col-3">
        <label className="form-label">Account:</label>
        </div>
        <div className="col-4"> {account.standarizedAccountType}</div>
        </div>
        <div className="d-flex" >
        <div className="col-3">
        <label className="form-label">AccountType:</label>
        </div>
        <div className="col-4"> {account.accountType}</div>
        </div>
        <div className="d-flex" >
        <div className="col-3">
        <label className="form-label">SubType1:</label>
        </div>
        <div className="col-4"> {account.accountSubType}</div>
        </div>
        <div className="d-flex" >
        <div className="col-3">
        <label className="form-label">SubType2:</label>
        </div>
        <div className="col-4"> {account.accountSubType2 == "" ? "null" : account.accountSubType2}</div>
        </div>
        <div className="d-flex" >
        <div className="col-3">
        <label className="form-label">description:</label>
        </div>
        <div className="col-4"> {account.description}</div>
        </div>
        <div className="d-flex" >
        <div className="col-3">
        <label className="form-label">Active:</label>
        </div>
        <div className="col-4"> {account.isEnabled ? "true" : "false"}</div>
        </div>
        <div className="d-flex" >
        <div className="col-3">
        <label className="form-label">Date:</label>
        </div>
        <div className="col-4"> {new Date(account.createdAt).toLocaleString()}</div>
        </div>
        
        </>
    )
}
export default ViewAccountType;