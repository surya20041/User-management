import React, { useEffect, useState } from 'react';
// import { useNavigate } from 'react-router-dom';
import { useFormContext } from '../../button/signleButton';  
import '../css/style.css';
import axios from 'axios';
import UpdatedTransactionForm from './updateTransactioncapbality';

function UpdateFinancialInstitution(props) {
    const [financialInstitutionId, setFinancialInstitution_Id] = useState("");
    const [id, setId] = useState(0);
    const [bin, setBin] = useState("");
    const [name, setName] = useState("");
    const [coreName, setCoreName] = useState("");
    const [apiType, setApiType] = useState("");
    const [apiUrl, setApiUrl] = useState("");
    const [isEnabled, setIsEnabled] = useState(false);
    const [createdAt, setCreatedAt] = useState("");
    const [transactionType, setTransactionType] = useState("");
    const [minAmount, setMinAmount] = useState("");
    const [maxAmount, setMaxAmount] = useState("");
    const [defAccTypeId, setDefAccTypeId] = useState("");
    const [includeUnlinkedAccounts, setIncludeUnlinkedAccounts] = useState(false);
    const [transactionCapabilityView, setTransactionCapabilityView] = useState(true);
    const { updateForm } = useFormContext();
    // const navigate = useNavigate();

    function handleCheckboxChange(e) {
        const value = e.target.value;
        let updatedTransactionType = transactionType ? transactionType.split(',').filter(v => v) : [];
        
        if (e.target.checked) {
            updatedTransactionType = [...updatedTransactionType, value];
        } else {
            updatedTransactionType = updatedTransactionType.filter(v => v !== value);
        }
        
        setTransactionType(updatedTransactionType.join(','));
    }

    const fiId = props.fiId;

    function submitData(e) {
        e.preventDefault();

        const financialInstitutionFormData = { 
            id,
            financialInstitutionId,
            bin,
            name,
            coreName,
            apiType,
            apiUrl,
            isEnabled,
            createdAt,
            transactionType,
            minAmount,
            maxAmount,
            defAccTypeId,
            includeUnlinkedAccounts
        };
       
        updateForm('financialInstitution', financialInstitutionFormData);
       // console.log(financialInstitutionFormData);

        axios.put('http://localhost:8083/onbording/updatedFiId', financialInstitutionFormData)
        .then((res) => {
           
            setTransactionCapabilityView(false); // Change to false to render the other component
            // navigate('/updateTransactionCapability', { state: { id, transactionType } });
        })
        .catch((err) => { 
            console.log(err); 
         });
    }

    useEffect(() => {
        axios.get('http://localhost:8083/onbording/getFiIdDetails?fiId=' + fiId)
        .then((res) => {
            console.log(res.data);
            setFinancialInstitution_Id(res.data.financialInstitutionId);
            setBin(res.data.bin);
            setId(res.data.id);
            setName(res.data.name);
            setCoreName(res.data.coreName);
            setApiType(res.data.apiType);
            setApiUrl(res.data.apiUrl);
            setTransactionType(res.data.transactionType || "");   
            setIsEnabled(res.data.isEnabled);
            setMinAmount(res.data.minAmount);            
            setMaxAmount(res.data.maxAmount);         
            setDefAccTypeId(res.data.defAccTypeId);            
            setIncludeUnlinkedAccounts(res.data.includeUnlinkedAccounts);
        }).catch((err) => {
           // console.log(err);
        });
    }, [fiId]);

    return (
        <>
          {transactionCapabilityView ? (
            <form onSubmit={submitData}>
                <div className="row">
                    <div className="col-12 col-lg-3 mb-3">
                        <label htmlFor="financialInstitutionId" className="form-label">Financial Institution:</label>
                        <input
                            type="text"
                            id="financialInstitutionId"
                            name="financialInstitutionId"
                            className="form-control form-control-lg"
                            value={financialInstitutionId}
                            onChange={(e) => setFinancialInstitution_Id(e.target.value)}
                            readOnly
                        />
                    </div>
                    <div className="col-12 col-lg-3 mb-3">
                        <label htmlFor="name" className="form-label">Name:</label>
                        <input
                            type="text"
                            id="name"
                            name="name"
                            className="form-control form-control-lg"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            required
                        />
                    </div>
                    <div className="col-12 col-lg-3 mb-3">
                        <label htmlFor="coreName" className="form-label">Core Name:</label>
                        <input
                            type="text"
                            id="coreName"
                            name="coreName"
                            className="form-control form-control-lg"
                            value={coreName}
                            onChange={(e) => setCoreName(e.target.value)}
                            required
                        />
                    </div>
                    <div className="col-12 col-lg-3 mb-3">
                        <label htmlFor="bin" className="form-label">BIN:</label>
                        <input
                            type="text"
                            id="bin"
                            name="bin"
                            className="form-control form-control-lg"
                            value={bin}
                            onChange={(e) => setBin(e.target.value)}
                            required
                        />
                    </div>

                    <div className="col-12 col-lg-3 mb-3">
                        <label htmlFor="apiType" className="form-label">API Type:</label>
                        <input
                            type="text"
                            id="apiType"
                            name="apiType"
                            className="form-control form-control-lg"
                            value={apiType}
                            onChange={(e) => setApiType(e.target.value)}
                            required
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label htmlFor="apiUrl" className="form-label">API URL:</label>
                        <input
                            type="text"
                            id="apiUrl"
                            name="apiUrl"
                            className="form-control form-control-lg"
                            value={apiUrl}
                            onChange={(e) => setApiUrl(e.target.value)}
                            required
                        />
                    </div>
                    <div className="col-12 col-lg-3 form-check mt-4 mb-3 radio-enable text-center">
                        <label className="form-check-label">
                        <input
                            type="checkbox"
                            className="form-check-input"
                            id="includeUnlinkedAccounts"
                            name="includeUnlinkedAccounts"
                            checked={includeUnlinkedAccounts}
                            onChange={(e) => setIncludeUnlinkedAccounts(e.target.checked)}
                        />Include Unlinked Accounts:
                        </label>
                    </div>
                    <div className="col-12 col-lg-2 form-check mt-4 mb-3 radio-enable text-center">
                        <label className="form-check-label">
                            <input
                                className="form-check-input"
                                type="checkbox"
                                id="isEnabled"
                                name="isEnabled"
                                checked={isEnabled}
                                onChange={(e) => {
                                    setIsEnabled(e.target.checked);
                                   // console.log(e);
                                }}
                            /> Is Enabled
                        </label>
                    </div>
                    <div className="col-12 col-lg-12 mb-3">
                        <label className="form-label">Transaction Type:</label><br />
                        {['DISPLAY', 'CASHWITHDRAWAL', 'CASHDEPOSIT', 'CHECKDEPOSIT', 'CASHCHECKDEPOSIT', 'CASHWITHDRAWALREVERSAL', 'CASHDEPOSITREVERSAL', 'CHECKDEPOSITADVICE', 'CASHCHECKDEPOSITREVERSAL', 'TRANSFER', 'TRANSFERREVERSAL', 'BALANCEINQUIRY', 'CASHDEPOSITADVICE', 'CASHCHECKDEPOSITADVICE', 'CHECKDEPOSITCASHBACK'].map(type => (
                            <div key={type} className="form-check form-check-inline col-6 col-lg-3">
                                <input
                                 className="form-check-input"
                                    type="checkbox"
                                    id={`transactionType_${type.toLowerCase()}`}
                                    name="transactionType"
                                    value={type}
                                    checked={transactionType.split(',').includes(type)}
                                    onChange={handleCheckboxChange}
                                />
                                <label className="form-check-label" htmlFor={`transactionType_${type.toLowerCase()}`}>{type}</label>
                            </div>
                        ))}
                    </div>
                    <div className="col-12 col-lg-3 mb-3">
                        <label htmlFor="createdAt" className="form-label">Created At:</label>
                        <input
                            type="date"
                            id="createdAt"
                            name="createdAt"
                            className="form-control form-control-lg"
                            value={createdAt}
                            onChange={(e) => setCreatedAt(e.target.value)}
                            required
                        />
                    </div>
                    <div className="col-12 col-lg-3 mb-3">
                        <label htmlFor="minAmount" className="form-label">Minimum Amount:</label>
                        <input
                            type="text"
                            id="minAmount"
                            name="minAmount"
                            className="form-control form-control-lg"
                            value={minAmount}
                            onChange={(e) => setMinAmount(e.target.value)}
                            required
                        />
                    </div>
                    <div className="col-12 col-lg-2 mb-3">
                        <label htmlFor="maxAmount" className="form-label">Maximum Amount:</label>
                        <input
                            type="text"
                            id="maxAmount"
                            name="maxAmount"
                            className="form-control form-control-lg"
                            value={maxAmount}
                            onChange={(e) => setMaxAmount(e.target.value)}
                            required
                        />
                    </div>
                    <div className="col-12 col-lg-3 mb-3">
                        <label htmlFor="defAccTypeId" className="form-label">Default Account Type:</label>
                        <input
                            type="number"
                            className="form-control form-control-lg"
                            id="defAccTypeId"
                            name="defAccTypeId"
                            value={defAccTypeId}
                            onChange={(e) => setDefAccTypeId(e.target.value)}
                            required
                        />
                    </div>
                    
                    <div className="col-12 text-right">
                        <button type="submit" className="btn btn-info ">Next</button>
                    </div>
                </div>
            </form>
          ) : (
            
             <UpdatedTransactionForm id= {id} updatedTransactionType ={transactionType} />
          )}
        </>
    );
}

export default UpdateFinancialInstitution;
