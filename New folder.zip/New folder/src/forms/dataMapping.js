// import { useLocation, useNavigate } from 'react-router-dom';
import React, { useState } from 'react';
import { useFormContext } from '../button/signleButton';
import './css/style.css';
import axios from 'axios';

const DataMapping = ({ onSubmitClick, fiId }) => {
  const [formData, setFormData] = useState({
    flowRouteId: '',
    operation: '',
    script: '',
    isEnabled: false,
    createdAt: '',
    delOperation: ''
  });

  const { updateForm, formMap } = useFormContext();
  // const location = useLocation();
  // const navigate = useNavigate();
  const [showForm, setShowForm] = useState(false);
  // const { financial_institution_id = '', a = '' } = location.state || {};




  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    // console.log(formData)
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value,
    });
      };

  const handleNextForm = (e) => {
    e.preventDefault();
    // const headers = {
    //   'fiId': a
    // };

    // console.log(formData);
    updateForm('dataMappingData', [formData]);
    // updateForm('dataMappingfiId', {headers}); 
    onSubmitClick("core-config");
    const allFormData = {};
    formMap.forEach((value, key) => {
      allFormData[key] = value;
    });

    const financialInstitution = allFormData.financialInstitution;
    const transactionCapabilityData = allFormData.allTransactionDetailsData;
    const flowRoute = allFormData.flowRouteData;
    const dataMapping = allFormData.dataMappingData;
    // const fiId = 1;
    // console.log(fiId)
    const coreConnectivitydetails = allFormData.coreConnectivityData

    axios.post('http://localhost:8083/onbording/submitData', {
      financialInstitution, transactionCapabilityData, flowRoute, dataMapping,
      coreConnectivitydetails 
    })
      .then((res) => {
        alert("Intitution onboarded successfully!!")
       // console.log(res)
      }).catch((err) => { console.log(err) })

    //navigate('/core-config', { state: { financial_institution_id, a }});
    // console.log('Proceeding to the next form with data:', formData);
  };

  const handleOpenForm = (e) => {
    e.preventDefault();
    setShowForm(true);
    //  console.log('Opening a different form.');
  };

  return (
    <div className="main-section">
       <div className="col-12 mt-3 mb-3">
          <b><p className="form-label">Financial Institution: {fiId}</p></b>
        </div>
      {/* <b> <p>Financial Institution ID: {fiId}</p> </b> */}
      {!showForm &&
        <div className="col-12 text-center two-btns">
          <button onClick={handleNextForm} className="btn btn-info">next</button>
          <button onClick={handleOpenForm} className="btn btn-secondary">add script</button>
        </div>}
      {showForm &&
        <form onSubmit={handleNextForm}>

          <div className="row">

            <div className="col-12 col-lg-4 mb-3">
              <label>Operation<span className="text-danger">*</span></label>
              <input
                className="form-control"
                type="text"
                name="operation"
                value={formData.operation}
                onChange={handleChange}
                required
              />
            </div>
            <div className="col-12 col-lg-4 mb-3">
              <label>Created At<span className="text-danger">*</span></label>
              <input
                className="form-control"
                type="date"
                name="createdAt"
                value={formData.createdAt}
                onChange={handleChange}
                required
              />
            </div>
            <div className="col-12 col-lg-4 mb-3">
              <label>Default operation<span className="text-danger">*</span></label>
              <input
                className="form-control"
                type="text"
                name="delOperation"
                value={formData.delOperation}
                onChange={handleChange}
                required
              />
            </div>

            <div className="col-12 col-lg-3 mb-3">
              <label>Script<span className="text-danger">*</span></label>
              <textarea
                className="form-control"
                name="script"
                value={formData.script}
                onChange={handleChange}
                required
              />
            </div>
            <div className="col-12 col-lg-4 mb-3">
              <label>
                <input
                  type="checkbox"
                  name="isEnabled"
                  checked={formData.isEnabled}
                  onChange={handleChange}
                />Active<span className="text-danger">*</span>

              </label>
            </div>
          </div>
          <div className="col-12 text-right">
            <button type="submit" className="btn btn-info btn-lg">next</button>
          </div>
        </form>
      }
    </div>
  );
};

export default DataMapping;
