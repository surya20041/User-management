import axios from "axios";
import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";

function ViewFiIdDetails(viewFiId) {
   // console.log(viewFiId)
    const location = useLocation();
    // const { fiId } = location.state;

    const [financialInstitution, setFinancialInstitution] = useState(null);
    const [transactionCapability, setTransactionCapability] = useState([]);
    const fiId = viewFiId.viewFiId;
    useEffect(() => {
        
    
        axios.get("http://localhost:8083/onbording/getAllData?fiId=" + fiId)
            .then((res) => {
                setFinancialInstitution(res.data.financialInstitution);
                setTransactionCapability(res.data.transactionCapability);
             //   console.log(res.data);
            }).catch((err) => {
              //  console.error("API Error:", err);
            });
    }, [fiId]);

    return (
        <>
            <h1>in the viewDetails</h1>
            {financialInstitution ? (
                <table>
                    <thead>
                        <tr>
                            <th>fiId</th>
                            <th>name</th>
                            <th>bin</th>
                            <th>apiType</th>
                            <th>apiUrl</th>
                            <th>careName</th>
                            <th>createdAt</th>
                            <th>defAccTypeId</th>
                            <th>includeUnlinkedAccounts</th>
                            <th>isEnabled</th>
                            <th>maxAmount</th>
                            <th>minAmount</th>
                            <th>transaction types</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>{financialInstitution.financialInstitutionId}</td>
                            <td>{financialInstitution.name}</td>
                            <td>{financialInstitution.bin}</td>
                            <td>{financialInstitution.apiType}</td>
                            <td>{financialInstitution.apiUrl}</td>
                            <td>{financialInstitution.careName}</td>
                            <td>{financialInstitution.createdAt}</td>
                            <td>{financialInstitution.defAccTypeId}</td>
                            <td>{financialInstitution.includeUnlinkedAccounts}</td>
                            <td>{financialInstitution.isEnabled ? 'Yes' : 'No'}</td>
                            <td>{financialInstitution.maxAmount}</td>
                            <td>{financialInstitution.minAmount}</td>
                            <td>{financialInstitution.transactionType}</td>
                        </tr>
                    </tbody>
                </table>
            ) : (
                <p>No data available</p>
            )}

            {transactionCapability.length > 0 ? (
                <table>
                    <thead>
                        <tr>
                            <th>s.no</th>
                            <th>financialInstitutionId</th>
                            <th>fromAccountTypeId</th>
                            <th>toAccountTypeId</th>
                            <th>transactionType</th>
                        </tr>
                    </thead>
                    <tbody>
                        {transactionCapability.map((transactionDetails, index) => (
                            <tr key={transactionDetails.id}>
                                <td>{index + 1}</td>
                                <td>{transactionDetails.financialInstitutionId}</td>
                                <td>{transactionDetails.fromAccountTypeId}</td>
                                <td>{transactionDetails.toAccountTypeId}</td>
                                <td>{transactionDetails.transactionType}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            ) : (
                <p>No transaction capabilities available</p>
            )}
        </>
    );
}

export default ViewFiIdDetails;
