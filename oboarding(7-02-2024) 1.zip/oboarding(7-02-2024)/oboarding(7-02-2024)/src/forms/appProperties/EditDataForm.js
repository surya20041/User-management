import React, { useState, useEffect } from 'react';
import axios from 'axios';

const EditDataForm = ({ data, onUpdate, onCancel }) => {
    const [appName, setAppName] = useState(data.appName);
    const [env, setEnv] = useState(data.env);
    const [propKey, setPropKey] = useState(data.propKey);
    const [propVal, setPropVal] = useState(data.propVal);
    const [modifiedBy, setModifiedBy] = useState(data.modifiedBy);
    const [createdBy, setCreatedBy] = useState(data.createdBy);
    const [lastModifiedTime, setLastModifiedTime] = useState(data.lastModifiedTime);
    const [createdDate, setCreatedDate] = useState(data.createdDate);
    const [modifiedDate, setModifiedDate] = useState(data.modifiedDate);

    useEffect(() => {
        setAppName(data.appName);
        setEnv(data.env);
        setPropKey(data.propKey);
        setPropVal(data.propVal);
        setModifiedBy(data.modifiedBy);
        setCreatedBy(data.createdBy);
        setLastModifiedTime(data.lastModifiedTime);
        setCreatedDate(data.createdDate);
        setModifiedDate(data.modifiedDate);
    }, [data]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        const updatedItem = {
            id: data.id,
            appName,
            env,
            propKey,
            propVal,
            modifiedBy,
            createdBy,
            lastModifiedTime,
            createdDate,
            modifiedDate
        };

        try {
            await axios.put(`http://localhost:8083/onbording/edit/${data.id}`, updatedItem);
            onUpdate(updatedItem);
        } catch (error) {
            console.error('Failed to update item:', error);
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <div className="row mb-3">
                <label className="col-sm-2 col-form-label">App Name</label>
                <div className="col-sm-10">
                    <input
                        type="text"
                        className="form-control"
                        name="AppName"
                        onChange={(e) => setAppName(e.target.value)}
                        value={appName}
                        required
                    />
                </div>
            </div>
            <div className="row mb-3">
                <label className="col-sm-2 col-form-label">Env</label>
                <div className="col-sm-10">
                    <input
                        type="text"
                        className="form-control"
                        name="Env"
                        onChange={(e) => setEnv(e.target.value)}
                        value={env}
                        required
                    />
                </div>
            </div>
            <div className="row mb-3">
                <label className="col-sm-2 col-form-label">PropKey</label>
                <div className="col-sm-10">
                    <input
                        type="text"
                        className="form-control"
                        name="PropKey"
                        onChange={(e) => setPropKey(e.target.value)}
                        value={propKey}
                        required
                    />
                </div>
            </div>
            <div className="row mb-3">
                <label className="col-sm-2 col-form-label">PropVal</label>
                <div className="col-sm-10">
                    <input
                        type="text"
                        className="form-control"
                        name="PropVal"
                        onChange={(e) => setPropVal(e.target.value)}
                        value={propVal}
                        required
                    />
                </div>
            </div>
            <div className="row mb-3">
                <label className="col-sm-2 col-form-label">Modified By</label>
                <div className="col-sm-10">
                    <input
                        type="text"
                        className="form-control"
                        name="ModifiedBy"
                        onChange={(e) => setModifiedBy(e.target.value)}
                        value={modifiedBy}
                        required
                    />
                </div>
                
            </div>
            <div className="row mb-3">
                <label className="col-sm-2 col-form-label">Created By</label>
                <div className="col-sm-10">
                    <input
                        type="text"
                        className="form-control"
                        name="CreatedBy"
                        onChange={(e) => setCreatedBy(e.target.value)}
                        value={createdBy}
                        required
                    />
                </div>
                
            </div>
            <div className="row mb-3">
                <label className="col-sm-2 col-form-label">Last Modified Time</label>
                <div className="col-sm-10">
                    <input
                        type="text"
                        className="form-control"
                        name="LastModifiedTime"
                        onChange={(e) => setLastModifiedTime(e.target.value)}
                        value={lastModifiedTime}
                        required
                    />
                </div>
            </div>
            <div className="row mb-3">
                <label className="col-sm-2 col-form-label">Created Date</label>
                <div className="col-sm-10">
                    <input
                        type="text"
                        className="form-control"
                        name="CreatedDate"
                        onChange={(e) => setCreatedDate(e.target.value)}
                        value={createdDate}
                        required
                    />
                </div>
            </div>
            <div className="row mb-3">
                <label className="col-sm-2 col-form-label">Modified Date</label>
                <div className="col-sm-10">
                    <input
                        type="text"
                        className="form-control"
                        name="ModifiedDate"
                        onChange={(e) => setModifiedDate(e.target.value)}
                        value={modifiedDate}
                        required
                    />
                </div>
            </div>
            <div className="d-flex justify-content-between">
                <button type="submit" className="btn btn-primary">Update</button>
                <button type="button" className="btn btn-secondary" onClick={onCancel}>Cancel</button>
            </div>
        </form>
    );
};

export default EditDataForm;
