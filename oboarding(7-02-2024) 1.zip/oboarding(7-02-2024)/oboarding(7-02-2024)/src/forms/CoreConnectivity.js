import axios from 'axios';
import { useLocation, useNavigate } from 'react-router-dom';
import React, { useState, useEffect } from 'react';
import './css/style.css';
import { useFormContext } from '../button/signleButton';  


const CoreConnectivity = ({fiId}) => {
  const [formData, setFormData] = useState({
    financialInstitutionId: '',
    coreName: '',
    host: '',
    port: '',
    basepath: '',
    messageId: '',
    branchId: '',
    processorUser: '',
    deviceType: '',
    deviceNumber: '',
    userName: '',
    password: '',
    adminPassword: '',
    findbyServicePath: '',
    accountServicePath: '',
    transactionServicePath: '',
    activeFlag: false,
    createdDate: '',
    modifiedDate: '',
    createdBy: '',
    modifiedBy: '',
  });

  const { updateForm } = useFormContext();
  const location = useLocation();
  const navigate = useNavigate();
  // const { financial_institution_id = '', a = '' } = location.state || {};

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value,
    });
  };

  
  const handleSubmit = (e) => {
    e.preventDefault();
    
    console.log(formData);
    updateForm('coreConnectivityData', formData);
    alert("Institution onboarded successfully")
  //  navigate('/submit-form');


  //   axios.post('http://localhost:8083/onbording/coreconnectivitydetails', formData)
  //     .then((response) => {
  //       console.log(response);
  //       // Optionally update createdDate and modifiedDate from the response
  //     })
  //     .catch((err) => console.log(err));

  //   console.log(formData);
  };

  useEffect(() => {
    const currentDate = new Date().toISOString().split('T')[0];
    setFormData((prevFormData) => ({
      ...prevFormData,
      createdDate: currentDate,
      modifiedDate: currentDate,
    }));
    setFormData((prevFormData) => ({
      ...prevFormData,
      financialInstitutionId: fiId
    })) ;
  }, []);
  
  return (
    <div className="container">
      {/* <h1>Core Connectivity Form</h1> */}
      <form onSubmit={handleSubmit}>
        <div className="row">
          <div className=" mt-3">
          <b><p>Financial Institution ID: {fiId}</p> </b>
          </div>
        
          {/* <div className="col-12 col-lg-3 mb-3">
            <label htmlFor="financialInstitutionId" className="form-label">Financial Institution ID:</label>
            <input
              type="text"
              id="financialInstitutionId"
              name="financialInstitutionId"
              className="form-control form-control-lg"
              value={formData.financialInstitutionId}
              onChange={handleChange}
              required
            />
          </div> */}

          <div className="col-12 col-lg-3 mb-3">
            <label htmlFor="coreName" className="form-label">Core Name<span className="text-danger">*</span></label>
            <input
              type="text"
              id="coreName"
              name="coreName"
              className="form-control form-control-lg"
              value={formData.coreName}
              onChange={handleChange}
              required
            />
          </div>

          <div className="col-12 col-lg-3 mb-3">
            <label htmlFor="host" className="form-label">Host<span className="text-danger">*</span></label>
            <input
              type="text"
              id="host"
              name="host"
              className="form-control form-control-lg"
              value={formData.host}
              onChange={handleChange}
              required
            />
          </div>

          <div className="col-12 col-lg-3 mb-3">
            <label htmlFor="port" className="form-label">Port<span className="text-danger">*</span></label>
            <input
              type="text"
              id="port"
              name="port"
              className="form-control form-control-lg"
              value={formData.port}
              onChange={handleChange}
              required
            />
          </div>

          <div className="col-12 col-lg-3 mb-3">
            <label htmlFor="basepath" className="form-label">Base Path<span className="text-danger">*</span></label>
            <input
              type="text"
              id="basepath"
              name="basepath"
              className="form-control form-control-lg"
              value={formData.basepath}
              onChange={handleChange}
              required
            />
          </div>

          <div className="col-12 col-lg-3 mb-3">
            <label htmlFor="messageId" className="form-label">Message ID<span className="text-danger">*</span></label>
            <input
              type="text"
              id="messageId"
              name="messageId"
              className="form-control form-control-lg"
              value={formData.messageId}
              onChange={handleChange}
              required
            />
          </div>

          <div className="col-12 col-lg-3 mb-3">
            <label htmlFor="branchId" className="form-label">Branch ID<span className="text-danger">*</span></label>
            <input
              type="text"
              id="branchId"
              name="branchId"
              className="form-control form-control-lg"
              value={formData.branchId}
              onChange={handleChange}
              required
            />
          </div>

          <div className="col-12 col-lg-3 mb-3">
            <label htmlFor="processorUser" className="form-label">Processor User<span className="text-danger">*</span></label>
            <input
              type="text"
              id="processorUser"
              name="processorUser"
              className="form-control form-control-lg"
              value={formData.processorUser}
              onChange={handleChange}
              required
            />
          </div>

          <div className="col-12 col-lg-3 mb-3">
            <label htmlFor="deviceType" className="form-label">Device Type<span className="text-danger">*</span></label>
            <input
              type="text"
              id="deviceType"
              name="deviceType"
              className="form-control form-control-lg"
              value={formData.deviceType}
              onChange={handleChange}
              required
            />
          </div>

          <div className="col-12 col-lg-3 mb-3">
            <label htmlFor="deviceNumber" className="form-label">Device Number<span className="text-danger">*</span></label>
            <input
              type="text"
              id="deviceNumber"
              name="deviceNumber"
              className="form-control form-control-lg"
              value={formData.deviceNumber}
              onChange={handleChange}
              required
            />
          </div>

          <div className="col-12 col-lg-3 mb-3">
            <label htmlFor="userName" className="form-label">User Name<span className="text-danger">*</span></label>
            <input
              type="text"
              id="userName"
              name="userName"
              className="form-control form-control-lg"
              value={formData.userName}
              onChange={handleChange}
              required
            />
          </div>

          <div className="col-12 col-lg-3 mb-3">
            <label htmlFor="password" className="form-label">Password<span className="text-danger">*</span></label>
            <input
              type="password"
              id="password"
              name="password"
              className="form-control form-control-lg"
              value={formData.password}
              onChange={handleChange}
              required
            />
          </div>

          <div className="col-12 col-lg-3 mb-3">
            <label htmlFor="adminPassword" className="form-label">Admin Password<span className="text-danger">*</span></label>
            <input
              type="password"
              id="adminPassword"
              name="adminPassword"
              className="form-control form-control-lg"
              value={formData.adminPassword}
              onChange={handleChange}
              required
            />
          </div>

          <div className="col-12 col-lg-3 mb-3">
            <label htmlFor="findbyServicePath" className="form-label">Find By Service Path<span className="text-danger">*</span></label>
            <input
              type="text"
              id="findbyServicePath"
              name="findbyServicePath"
              className="form-control form-control-lg"
              value={formData.findbyServicePath}
              onChange={handleChange}
              required
            />
          </div>

          <div className="col-12 col-lg-3 mb-3">
            <label htmlFor="accountServicePath" className="form-label">Account Service Path<span className="text-danger">*</span></label>
            <input
              type="text"
              id="accountServicePath"
              name="accountServicePath"
              className="form-control form-control-lg"
              value={formData.accountServicePath}
              onChange={handleChange}
              required
            />
          </div>

          <div className="col-12 col-lg-3 mb-3">
            <label htmlFor="transactionServicePath" className="form-label">Transaction Service Path<span className="text-danger">*</span></label>
            <input
              type="text"
              id="transactionServicePath"
              name="transactionServicePath"
              className="form-control form-control-lg"
              value={formData.transactionServicePath}
              onChange={handleChange}
              required
            />
          </div>

          

          <div className="col-12 col-lg-3 mb-3">
            <label htmlFor="createdDate" className="form-label">Created Date</label>
            <input
              type="text"
              id="createdDate"
              name="createdDate"
              className="form-control form-control-lg"
              value={formData.createdDate}
              readOnly
            />
          </div>

          <div className="col-12 col-lg-3 mb-3">
            <label htmlFor="modifiedDate" className="form-label">Modified Date:</label>
            <input
              type="text"
              id="modifiedDate"
              name="modifiedDate"
              className="form-control form-control-lg"
              value={formData.modifiedDate}
              readOnly
            />
          </div>

          <div className="col-12 col-lg-3 mb-3">
            <label htmlFor="createdBy" className="form-label">Created By:</label>
            <input
              type="text"
              id="createdBy"
              name="createdBy"
              className="form-control form-control-lg"
              value={formData.createdBy}
              onChange={handleChange}
            />
          </div>

          <div className="col-12 col-lg-3 mb-3">
            <label htmlFor="modifiedBy" className="form-label">Modified By:</label>
            <input
              type="text"
              id="modifiedBy"
              name="modifiedBy"
              className="form-control form-control-lg"
              value={formData.modifiedBy}
              onChange={handleChange}
            />
          </div>
          <div className="col-12 col-lg-3 form-check mt-12  ">
            <label className="form-check-label" htmlFor="activeFlag">
              <input
                className="form-check-input"
                type="checkbox"
                id="activeFlag"
                name="activeFlag"
                checked={formData.activeFlag}
                onChange={handleChange}
              /> Active <span className="text-danger">*</span>
            </label>
          </div>
          
          <div className="col-12 text-right">
            <button type="submit" className="btn btn-primary btn-lg">next</button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default CoreConnectivity;
