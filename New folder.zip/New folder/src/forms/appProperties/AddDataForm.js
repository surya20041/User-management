import React, { useState } from 'react';
import axios from 'axios';

const AddDataForm = ({ onAdd, onClose }) => {
    const [applicationName, setApplicationName] = useState("");
    const [environment, setEnvironment] = useState("");
    const [propertyKey, setPropertyKey] = useState("");
    const [propertyVal, setPropertyVal] = useState("");
    const [lastModifiedTime, setLastModifiedTime] = useState("");
    const [createdDate, setCreatedDate] = useState("");
    const [modifiedDate, setModifiedDate] = useState("");
    const [createdBy, setCreatedBy] = useState("");
    const [modifiedBy, setModifiedBy] = useState("");

    const handleSubmit = async (e) => {
        e.preventDefault();
        const newData = {
            applicationName,
            environment,
            propertyKey,
            propertyVal,
            createdBy,
            modifiedBy,
            lastModifiedTime,
            createdDate,
            modifiedDate
        };

        try {
            const response = await axios.post("http://localhost:8083/onbording/add", newData);
            console.log('Response:', response.data);
            
            onAdd(); // Call the onAdd function to refresh the data in the parent component
            resetForm();
            onClose(); // Call the onClose function to close the modal
            alert("Data added successfully!");
        } catch (err) {
            console.log('Error:', err);
            alert("Failed to add data. Please try again.");
        }
    };

    const resetForm = () => {
        setApplicationName("");
        setEnvironment("");
        setPropertyKey("");
        setPropertyVal("");
        setCreatedBy("");
        setModifiedBy("");
        setLastModifiedTime("");
        setCreatedDate("");
        setModifiedDate("");
    };

    return (
        <div className='col-lg-12'>
            <form onSubmit={handleSubmit}>
                <div className="row">
                    <div className="col-12 col-lg-3 mt-3 mb-3">
                        <label className="form-label">Application Name</label>
                        <input
                            type="text"
                            className="form-control form-control-lg"
                            name="ApplicationName"
                            onChange={(e) => setApplicationName(e.target.value)}
                            value={applicationName}
                            required
                        />
                </div>
                <div className="col-12 col-lg-3 mt-3 mb-3">
                <label className="form-label">Environment</label>
                    <select
                        className="form-control form-control-lg form-select"
                        name="Environment"
                        onChange={(e) => setEnvironment(e.target.value)}
                        value={environment}
                        required
                    >
                        <option value="">Select Environment</option>
                        <option value="local">Local</option>
                        <option value="dev">Dev</option>
                        <option value="qa">QA</option>
                        <option value="uat">UAT</option>
                    </select>
                       {/* <label className="form-label">Env</label>
                        <input
                            type="text"
                            className="form-control form-control-lg"
                            name="Environment"
                            onChange={(e) => setEnvironment(e.target.value)}
                            value={environment}
                            required
                        /> */}
            
                </div>
                <div className="col-12 col-lg-3 mt-3 mb-3">
                    <label className="form-label">Property Key</label>
                    <input
                            type="text"
                            className="form-control form-control-lg"
                            name="PropertyKey"
                            onChange={(e) => setPropertyKey(e.target.value)}
                            value={propertyKey}
                            required
                        />
                </div>
               
                <div className="col-12 col-lg-3 mt-3 mb-3">
                <label className="form-label">Property Val</label>
                <input
                            type="text"
                            className="form-control form-control-lg"
                            name="PropertyVal"
                            onChange={(e) => setPropertyVal(e.target.value)}
                            value={propertyVal}
                            required
                        />
                    
                </div>
               
                <div className="col-12 col-lg-3 mb-3">
                        <label className="form-label">Last Modified Time</label>
                        <input
                            type="date"
                            className="form-control form-control-lg"
                            name="LastModifiedTime"
                            onChange={(e) => setLastModifiedTime(e.target.value)}
                            value={lastModifiedTime}
                            required
                        />
                </div>
               
                <div className="col-12 col-lg-3 mb-3">
                <label className="form-label">Created Date</label>
                <input
                            type="date"
                            className="form-control form-control-lg"
                            name="CreatedDate"
                            onChange={(e) => setCreatedDate(e.target.value)}
                            value={createdDate}
                            required
                        />
                </div>
                
                <div className="col-12 col-lg-3 mb-3">
                <label className="form-label">Modified Date</label>
                <input
                            type="date"
                            className="form-control form-control-lg"
                            name="ModifiedDate"
                            onChange={(e) => setModifiedDate(e.target.value)}
                            value={modifiedDate}
                            required
                        />
                </div>
                
                <div className="col-12 col-lg-3 mb-3">
                <label className="form-label">Created By</label>
                <input
                            type="text"
                            className="form-control form-control-lg"
                            name="CreatedBy"
                            onChange={(e) => setCreatedBy(e.target.value)}
                            value={createdBy}
                            required
                        />
                </div>
               
                <div className="col-12 col-lg-3 mb-3">
                <label className="form-label">Modified By</label>
                <input
                            type="text"
                            className="form-control form-control-lg"
                            name="ModifiedBy"
                            onChange={(e) => setModifiedBy(e.target.value)}
                            value={modifiedBy}
                            required
                        />
                </div>
                <div className="col-12 mt-4 text-right two-btns">
                    {/* <button type="button" className="btn btn-secondary me-2" onClick={resetForm}>Reset</button> */}
                    <button type="submit" className="btn btn-info ">Add </button>
                    {/* <button type="button" className="btn btn-danger" onClick={onClose}>Close</button> */}
                </div>
                </div>
            </form>
        </div>
        
    );
};

export default AddDataForm;
