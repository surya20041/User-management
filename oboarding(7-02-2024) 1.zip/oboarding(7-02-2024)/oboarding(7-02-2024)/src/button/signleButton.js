import React, { createContext, useState, useContext } from 'react';

// Create the context
const FormContext = createContext();

// Create a provider component
export const FormProvider = ({ children }) => {
  const [formMap, setFormMap] = useState(new Map());

  const updateForm = (key, value) => {
    setFormMap(prevMap => new Map(prevMap).set(key, value));
  };
 // console.log("Data from the useContext file:-",formMap)

  return (
    <FormContext.Provider value={{ formMap, updateForm }}>
      {children}
    </FormContext.Provider>
  );
};

// Create a custom hook to use the FormContext
export const useFormContext = () => useContext(FormContext);
