import axios from 'axios';
import React, { useEffect, useState } from 'react';
// import { useLocation, useNavigate } from 'react-router-dom';
import { useFormContext } from '../button/signleButton';
import Select from 'react-select';
import './css/style.css';
 
const TransactionForm = ({ onSubmitClick, fiId, fiIdTransactionType }) => {
  const initialFormData = {
    financialInstitutionId: 0,
    fromAccountTypeIds: 0,
    toAccountTypeIds: {},
    transactionType: '',
    coreInterfaceOperation: '',
    isEnabled: false,
    createdAt: '',
    isoCode: ''
  };
 
  const [formData, setFormData] = useState(initialFormData);
  const { updateForm } = useFormContext();
  const [enableFromAccountTypeId, setEnableFromAccountTypeId] = useState(false);
  const [allTransactionDetails, setAllTransactionDetails] = useState([]);
  // const location = useLocation();
  // const navigate = useNavigate();
 
  const transactionTypeArray = fiIdTransactionType.split(',');
  const [accountTypes, setAccountTypes] = useState([]);
 
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
 
    setFormData((prevFormData) => ({
      ...prevFormData,
      [name]: type === 'checkbox' ? checked : name === 'isEnabled' ? value === 'true' : value
    }));
  };
 
  const handleAccountTypeChange = (selectedOptions) => {
    setFormData((prevFormData) => ({
      ...prevFormData,
      toAccountTypeIds: selectedOptions.reduce((acc, option) => {
        acc[option.value] = option.label;
        return acc;
      }, {})
    }));
  };
 
  const handleTransactionTypeChange = (e) => {
    const { value } = e.target;
    setFormData((prevFormData) => ({
      ...prevFormData,
      transactionType: value
    }));
  };
 
  useEffect(() => {
    if (formData.transactionType === "TRANSFER" || formData.transactionType === "TRANSFERREVERSAL") {
      setEnableFromAccountTypeId(true);
    } else {
      setEnableFromAccountTypeId(false);
    }
  }, [formData.transactionType]);
 
  useEffect(() => {
    axios.get("http://localhost:8083/onbording/accountType")
      .then((response) => {
        const descriptions = response.data.map(accountType => ({ value: accountType.id, label: accountType.description }));
        setAccountTypes(descriptions);
      }).catch((error) => {
        console.error(error);
      });
  }, []);
 
  const handleSubmit = (e) => {
    e.preventDefault();
 
    const toAccountType = Object.keys(formData.toAccountTypeIds).reduce((acc, key) => {
      acc[key] = [parseInt(key)];
      return acc;
    }, {});
    const fromAccountType = formData.fromAccountTypeIds;
 
    const date =  new Date().toISOString().split('T')[0];
    
    const transactionCapabilityData = {
      financialInstitutionId: fiId,
      toAccountType,
      fromAccountType,
      coreInterfaceOperation: formData.coreInterfaceOperation,
      isEnabled: formData.isEnabled,
      createdAt: date,
      isoCode: formData.isoCode
    };
 
    setAllTransactionDetails((previousValues) => {
      if (!Array.isArray(previousValues)) {
        previousValues = [];
      }
      return [
        ...previousValues,
        transactionCapabilityData
      ];
    });
 
    // Reset form data to initial state
    setFormData(initialFormData);
  };
 
  useEffect(() => {
    if (allTransactionDetails.length > 0) {
      console.log("Updated transaction details:", allTransactionDetails);
    }
  }, [allTransactionDetails]);
 
  const isChecked = (field, id) => {
    if (field === 'fromAccountTypeIds') {
      return formData[field] === id;
    }
    return (formData[field]?.[formData.transactionType] || []).includes(id);
  };
 
  const submitAllDetails = () => {
    updateForm('allTransactionDetailsData', allTransactionDetails);
    onSubmitClick("flow-route");
  };
 
  return (
    <form onSubmit={handleSubmit}>
      <div className='row'>
        <div className="col-12 mt-3 mb-3">
          <b><p className="form-label">Financial Institution ID: {fiId}</p></b>
        </div>
        <div className="col-12 mb-3">
          <label className="form-label">Transaction Types<span className="text-danger">*</span></label>
          <select
            id="transactionTypes"
            name="transactionType"
            className="form-select"
            value={formData.transactionType}
            onChange={handleTransactionTypeChange}
          >
            <option value="">Select Transaction Type<span className="text-danger">*</span></option>
            {transactionTypeArray.map((type) => (
              <option key={type} value={type}>{type}</option>
            ))}
          </select>
        </div>
 
        {enableFromAccountTypeId && (
          <div className="col-12 col-lg-12 mb-3">
          <label className="form-label">From Account Types<span className="text-danger">*</span></label>
          <Select
            options={accountTypes}
            onChange={handleAccountTypeChange}        
          />
        </div>
          // <div className="col-12 mb-3 mt-3">
          //   <div className="accordion accordion-flush" id="accordionFlushExample">
          //     <div className="accordion-item">
          //       <h2 className="accordion-header" id="flush-headingOne">
          //         <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
          //           From Account Type IDs:
          //         </button>
          //       </h2>
          //       <div id="flush-collapseOne" className="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
          //         <div className="accordion-body">
          //           {accountTypes.map((accountType) => (
          //             <div key={accountType.value} className="form-check form-check-inline">
          //               <input
          //                 type="checkbox"
          //                 className="form-check-input"
          //                 id={`from-${accountType.value}`}
          //                 name="fromAccountTypeIds"
          //                 value={accountType.value}
          //                 checked={isChecked('fromAccountTypeIds', accountType.value)}
          //                 onChange={(e) => handleAccountTypeChange(e, 'fromAccountTypeIds')}
          //               />
          //               <label className="form-check-label" htmlFor={`from-${accountType.value}`}>{accountType.label}</label>
          //             </div>
          //           ))}
          //         </div>
          //       </div>
          //     </div>
          //   </div>
          // </div>
        )}
        <div className="col-12 col-lg-12 mb-3">
          <label className="form-label">To Account Types<span className="text-danger">*</span></label>
          <Select
          
            options={accountTypes}
            onChange={handleAccountTypeChange}
            isMulti={true}
            
          />
        </div>
 
        <div className="col-12 col-lg-3 mb-3">
          <label className="form-label">Core Interface Operation<span className="text-danger">*</span></label>
          <input
            type="text"
            className="form-control"
            name="coreInterfaceOperation"
            value={formData.coreInterfaceOperation}
            onChange={handleChange}
          />
        </div>
 
       
          
 
        {/* <div className="col-12 col-lg-3 mb-3">
          <label className="form-label">Created At<span className="text-danger">*</span></label>
          <input
            type="date"
            className="form-control"
            name="createdAt"
            value={formData.createdAt}
            onChange={handleChange}
          />
        </div>
  */}
        <div className="col-12 col-lg-3 mb-3">
          <label className="form-label">ISO Code<span className="text-danger">*</span></label>
          <input
            type="text"
            className="form-control"
            name="isoCode"
            value={formData.isoCode}
            onChange={handleChange}
          />
        </div>
        <div className="col-12 col-lg-2 form-check mt-4 mb-3 radio-enable text-center">
          <label className="form-check-label">
            <input
              className="form-check-input"
              type="checkbox"
              name="isEnabled"
              value={formData.isEnabled}
              checked={formData.isEnabled === true}
              onChange={() => {
                setFormData({...formData, isEnabled: true});
                console.log(formData);
              }}
            /> Is Enabled
          </label>
          </div>
 
        <div className="col-12 mb-3">
          <button type="submit" className="btn btn-primary">add</button>
          <button type="button" className="btn btn-secondary" onClick={submitAllDetails}>next</button>
        </div>
      </div>
    </form>
  );
};
 
export default TransactionForm;