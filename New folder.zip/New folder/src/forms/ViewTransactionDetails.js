import React,{useState,useEffect} from "react";

const ViewTransactionDetails=({editData})=>{

    const [account, setAccount] = useState({});

    useEffect(()=>{
        setAccount(editData)
    }, [editData])

    return(

        <>
        <div className="d-flex" >
        <div className="col-3">
        <label className="form-label">From Account Number:</label>
        </div>
        <div className="col-4"> {account.fromAccountNumber}</div>
        </div>
        <div className="d-flex" >
        <div className="col-3">
        <label className="form-label">From Account Type:</label>
        </div>
        <div className="col-4"> {account.fromAccountType}</div>
        </div>
        <div className="d-flex" >
        <div className="col-3">
        <label className="form-label">To Account Number:</label>
        </div>
        <div className="col-4"> {account.toAccountNumber}</div>
        </div>
        <div className="d-flex" >
        <div className="col-3">
        <label className="form-label">To Account Type:</label>
        </div>
        <div className="col-4"> {account.toAccountType}</div>
        </div>
        <div className="d-flex" >
        <div className="col-3">
        <label className="form-label">Acquirer Id:</label>
        </div>
        <div className="col-4"> {account.acquirerid}</div>
        </div>
        <div className="d-flex" >
        <div className="col-3">
        <label className="form-label">Institution Id:</label>
        </div>
        <div className="col-4"> {account.instId}</div>
        </div>
        <div className="d-flex" >
        <div className="col-3">
        <label className="form-label">Auth Id:</label>
        </div>
        <div className="col-4"> {account.authId}</div>
        </div>
        <div className="d-flex" >
        <div className="col-3">
        <label className="form-label">RRN:</label>
        </div>
        <div className="col-4"> {account.rrn}</div>
        </div>
        <div className="d-flex" >
        <div className="col-3">
        <label className="form-label">Terminal Id:</label>
        </div>
        <div className="col-4"> {account.terminalId}</div>
        </div>
        <div className="d-flex" >
        <div className="col-3">
        <label className="form-label">Transaction Type:</label>
        </div>
        <div className="col-4"> {account.transactionType}</div>
        </div>
        <div className="d-flex" >
        <div className="col-3">
        <label className="form-label">Amount:</label>
        </div>
        <div className="col-4"> {account.amount}</div>
        </div>
        <div className="d-flex" >
        <div className="col-3">
        <label className="form-label">Date:</label>
        </div>
        <div className="col-4"> {new Date(account.date).toLocaleString()}</div>
        </div>
        
        </>
    )
}
export default ViewTransactionDetails;