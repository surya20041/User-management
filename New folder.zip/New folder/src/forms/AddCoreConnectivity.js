import React, { useState } from "react";
import axios from "axios";
import 'bootstrap/dist/css/bootstrap.min.css';



const AddCoreConnectivity = () => {
    const [financialInstitutionId, setFinancialInstitutionId] = useState("");
    const [coreName, setCoreName] = useState("");
    const [host, setHost] = useState("");
    const [port, setPort] = useState("");
    const [basepath, setBasepath] = useState("");
    const [messageId, setMessageId] = useState("");
    const [branchId, setBranchId] = useState("");
    const [processorUser, setProcessorUser] = useState("");
    const [deviceType, setDeviceType] = useState("");
    const [deviceNumber, setDeviceNumber] = useState("");
    const [userName, setUserName] = useState("");
    const [password, setPassword] = useState("");
    const [adminPassword, setAdminPassword] = useState("");
    const [findbyServicePath, setFindbyServicePath] = useState("");
    const [accountServicePath, setAccountServicePath] = useState("");
    const [transactionServicePath, setTransactionServicePath] = useState("");
    const [activeFlag, setActiveFlag] = useState(false);
    const [createdBy, setCreatedBy] = useState("");
    const [formDataArray, setFormDataArray] = useState([]);
    const [modalVisible, setModalVisible] = useState(false);
    const [errorModalVisible, setErrorModalVisible] = useState(false);

    const handleAddInputData = () => {
        const coreData = {
            financialInstitutionId,
            coreName,
            host,
            port,
            basepath,
            messageId,
            branchId,
            processorUser,
            deviceType,
            deviceNumber,
            userName,
            password,
            adminPassword,
            findbyServicePath,
            accountServicePath,
            transactionServicePath,
            activeFlag,
            createdBy,
            createdDate: new Date().toISOString(), // Set current date
            modifiedDate: new Date().toISOString(), // Set current date
        };
        setFormDataArray([...formDataArray, coreData]);
        setFinancialInstitutionId("");
        setCoreName("");
        setHost("");
        setPort("");
        setBasepath("");
        setMessageId("");
        setBranchId("");
        setProcessorUser("");
        setDeviceType("");
        setDeviceNumber("");
        setUserName("");
        setPassword("");
        setAdminPassword("");
        setFindbyServicePath("");
        setAccountServicePath("");
        setTransactionServicePath("");
        setActiveFlag(false);
        setCreatedBy("");
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const coreData = {
            financialInstitutionId,
            coreName,
            host,
            port,
            basepath,
            messageId,
            branchId,
            processorUser,
            deviceType,
            deviceNumber,
            userName,
            password,
            adminPassword,
            findbyServicePath,
            accountServicePath,
            transactionServicePath,
            activeFlag,
            createdBy,
            createdDate: new Date().toISOString(), // Set current date
            modifiedDate: new Date().toISOString(), // Set current date
        };
        const updatedFormDataArray = [...formDataArray, coreData];
        try {
          //  console.log("Sending data:", updatedFormDataArray);
            const response = await axios.post("http://localhost:8083/onbording/addCoreData", updatedFormDataArray);
          //  console.log("Response received:", response.data);
            setFormDataArray([]);
            setFinancialInstitutionId("");
            setCoreName("");
            setHost("");
            setPort("");
            setBasepath("");
            setMessageId("");
            setBranchId("");
            setProcessorUser("");
            setDeviceType("");
            setDeviceNumber("");
            setUserName("");
            setPassword("");
            setAdminPassword("");
            setFindbyServicePath("");
            setAccountServicePath("");
            setTransactionServicePath("");
            setActiveFlag(false);
            setCreatedBy("");
            setModalVisible(true);
        } catch (error) {
            console.error("There was an error adding the core connectivity details!", error);
            setErrorModalVisible(true);
        }
    };

    return (
        <div className="col-lg-12">
            <form onSubmit={handleSubmit}>
                <div className="row">
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Financial Institution ID<span className="text-danger">*</span></label>
                         <input
                
                            type="text"
                            className="form-control"
                            name="financialInstitutionId"
                            onChange={(e) => setFinancialInstitutionId(e.target.value)}
                            value={financialInstitutionId}
                            required
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Core Name<span className="text-danger">*</span></label>
                         <input
              
                            type="text"
                            className="form-control"
                            name="coreName"
                            onChange={(e) => setCoreName(e.target.value)}
                            value={coreName}
                            required
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Host<span className="text-danger">*</span></label>
                         <input
                
                            type="text"
                            className="form-control"
                            name="host"
                            onChange={(e) => setHost(e.target.value)}
                            value={host}
                            required
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Port<span className="text-danger">*</span></label>
                         <input
                required
                            type="text"
                            className="form-control"
                            name="port"
                            onChange={(e) => setPort(e.target.value)}
                            value={port}
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Basepath<span className="text-danger">*</span></label>
                         <input
                required
                            type="text"
                            className="form-control"
                            name="basepath"
                            onChange={(e) => setBasepath(e.target.value)}
                            value={basepath}
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Message ID<span className="text-danger">*</span></label>
                         <input
                required
                            type="text"
                            className="form-control"
                            name="messageId"
                            onChange={(e) => setMessageId(e.target.value)}
                            value={messageId}
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Branch ID<span className="text-danger">*</span></label>
                         <input
                required
                            type="text"
                            className="form-control"
                            name="branchId"
                            onChange={(e) => setBranchId(e.target.value)}
                            value={branchId}
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Processor User<span className="text-danger">*</span></label>
                         <input
                required
                            type="text"
                            className="form-control"
                            name="processorUser"
                            onChange={(e) => setProcessorUser(e.target.value)}
                            value={processorUser}
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Device Type<span className="text-danger">*</span></label>
                         <input
                required
                            type="text"
                            className="form-control"
                            name="deviceType"
                            onChange={(e) => setDeviceType(e.target.value)}
                            value={deviceType}
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Device Number<span className="text-danger">*</span></label>
                         <input
                required
                            type="text"
                            className="form-control"
                            name="deviceNumber"
                            onChange={(e) => setDeviceNumber(e.target.value)}
                            value={deviceNumber}
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">User Name<span className="text-danger">*</span></label>
                         <input
                required
                            type="text"
                            className="form-control"
                            name="userName"
                            onChange={(e) => setUserName(e.target.value)}
                            value={userName}
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Password<span className="text-danger">*</span></label>
                         <input
                required
                            type="password"
                            className="form-control"
                            name="password"
                            onChange={(e) => setPassword(e.target.value)}
                            value={password}
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Admin Password<span className="text-danger">*</span></label>
                         <input
                required
                            type="password"
                            className="form-control"
                            name="adminPassword"
                            onChange={(e) => setAdminPassword(e.target.value)}
                            value={adminPassword}
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Findby Service Path<span className="text-danger">*</span></label>
                         <input
                required
                            type="text"
                            className="form-control"
                            name="findbyServicePath"
                            onChange={(e) => setFindbyServicePath(e.target.value)}
                            value={findbyServicePath}
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Account Service Path<span className="text-danger">*</span></label>
                         <input
                required
                            type="text"
                            className="form-control"
                            name="accountServicePath"
                            onChange={(e) => setAccountServicePath(e.target.value)}
                            value={accountServicePath}
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Transaction Service Path<span className="text-danger">*</span></label>
                         <input
                required
                            type="text"
                            className="form-control"
                            name="transactionServicePath"
                            onChange={(e) => setTransactionServicePath(e.target.value)}
                            value={transactionServicePath}
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-3">
                        <label className="form-label">Created By<span className="text-danger">*</span></label>
                         <input
                            required
                            type="text"
                            className="form-control"
                            name="createdBy"
                            onChange={(e) => setCreatedBy(e.target.value)}
                            value={createdBy}
                        />
                    </div>
                    <div className="col-12 col-lg-4 mb-4 ">
                        <label className="form-check-label ">Active Flag</label>
                         <input
                
                            required
                            type="checkbox"
                            className="form-check-input "
                            name="activeFlag"
                            onChange={(e) => setActiveFlag(e.target.checked)}
                            checked={activeFlag}
                        />
                    </div>
                    
                    <div className="col-12">
                        <button type="button" className="btn btn-secondary me-3" onClick={handleAddInputData}>Add More</button>
                        <button type="submit" className="btn btn-primary">Submit</button>
                    </div>
                </div>
            </form>
             {/* //Success modal */}
             {modalVisible && (
                <div className="modal fade show custom-modal  box-required-size" style={{ display: "block" }} tabIndex="-1">
                    <div className="modal-dialog col-sm-3">
                        <div className="modal-content">
                            <div className="modal-header bg-success text-white">
                                <h5 className="modal-title">Added</h5>
                                <button type="button" className="btn-close" onClick={() => setModalVisible(false)}></button>
                            </div>
                            <div className="modal-body success.res">
                                <p>Core Details successfully added</p>
                            </div>
                        </div>
                    </div>
                </div>
            )}
            {/* Error Modal */}
            {errorModalVisible && (
                <div className="modal" tabIndex="-1" role="dialog" style={{ display: 'block' }}>
                    <div className="modal-dialog" role="document">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title">Error</h5>
                                <button type="button" className="close" onClick={() => setErrorModalVisible(false)}>
                                    <span>&times;</span>
                                </button>
                            </div>
                            <div className="modal-body">
                                <p>There was an error adding the core connectivity details!</p>
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-primary" onClick={() => setErrorModalVisible(false)}>OK</button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default AddCoreConnectivity;
