import React, { useEffect, useState } from "react";
import axios from "axios";
import SignUp from "../SignUp/SignUp";
import EditUserModal from "../EditUserModal/EditUserModal";

function UserManagement() {

    const [allUsers, setAllUsers] = useState([]);
    const [userDetails, setUserDetails] = useState({});
    const [search, setSearch] = useState('');
function allDetails(){
    axios.get('http://localhost:8080/getusersdata')
    .then((res) => {
        setAllUsers(res.data)
       // console.log(res.data)

    }).catch((err) => {
        console.log(err);
    })
}
    useEffect(() => {
        allDetails()
    }, [])
    const handleToggleActivation = async (user) => {
     try {
        
     
            await fetch(`http://localhost:8080/updateuseractivation/${user.id}?isActive=${!user.active}`, {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                },
            });
            allDetails()
        } catch (error) {
        
        }
        }
    return (
        <>
            <div className="row">
                <h1 className="h3 mb-3">User Management</h1>
                <div className="col-12">
                    <div className="card">
                        <div className="card-body">
                            <div className="card-header">
                                <form className="row form-inline search-box my-2 my-lg-0">
                                    <div className="col-lg-10">
                                        <input className="form-control-lg mr-sm-2" type="search" placeholder="Search" onChange={(e) => {setSearch(e.target.value)}} aria-label="Search" />
                                    </div>
                                    <div className="col-lg-2">
                                        <button className="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                                    </div>
                                </form>
                            </div>
                            <table className="table table-striped table-hover ">

                                <thead>
                                    <tr>
                                        <th scope="col">S.no</th>
                                        <th scope="col">User Name</th>
                                        <th scope="col">Mail Id</th>
                                        <th scope="col">Active</th>
                                        <th scope="col">Password</th>
                                        <th scope="col">Role</th>
                                        <th scope="col">Edit</th>
                                        <th scope="col">Enable/ Disable</th>
                                    </tr>
                                </thead>
                                {allUsers.filter((usersDetails) =>{
                                    return( 
                                        search === '' ? usersDetails :
                                        usersDetails.userName.toLowerCase().startsWith(search.toLowerCase())
                                    || usersDetails.mailID.toLowerCase().startsWith(search.toLowerCase())
                                    || usersDetails.role.toLowerCase().startsWith(search.toLowerCase()))
                                }).map((value, index) => (
                                    <tbody>
                                        <tr key={index}>
                                            <td>{index + 1}</td>
                                            <td>{value.userName}</td>
                                            <td>{value.mailID}</td>
                                            <td>{value.isActive ? 'true' : 'false'}</td>
                                            {/* <td>{value.passWord}</td> */}
                                            <td><p>******</p></td>
                                            <td>{value.role}</td>


                                            {/* <div className="modal fade" id="viewinstitution" tabindex="-1" aria-labelledby="view-institution" aria-hidden="true">
                                                <div className="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
                                                    <div className="modal-content">
                                                        <div className="modal-header">
                                                            <h5 className="modal-title" id="view-institution">View Institution Details</h5>
                                                            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div className="modal-body">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div> */}
                                            <td>
                                                <a data-bs-toggle="modal" data-bs-target="#editinstitution" onClick={() => {  setUserDetails(value)}}>

                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-pencil" viewBox="0 0 16 16">
                                                        <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325" />
                                                    </svg>
                                                </a>
                                            </td>
                                            <div className="modal fade" id="editinstitution" tabindex="-1" aria-labelledby="edit-institution" aria-hidden="true">
                                                <div className="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
                                                    <div className="modal-content">
                                                        <div className="modal-header">
                                                            <h5 className="modal-title" id="edit-institution">Edit User Details</h5>
                                                            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div className="modal-body">
                                                            <EditUserModal user= {userDetails} setIsEditingUser = {false} refreshUsers={allDetails}/>   
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <td>
                                                <a onClick={() => { handleToggleActivation(value) }}>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-trash" viewBox="0 0 16 16">
                                                        <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z" />
                                                        <path d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z" />
                                                    </svg>
                                                </a>
                                            </td>
                                        </tr>

                                        {/* Add more rows as needed */}
                                    </tbody>
                                ))}
                            </table>
                            <div className="float-end" data-bs-toggle="modal" data-bs-target="#newinstitution" >
                                <button type="button" className="btn btn-primary">
                                    Add user
                                </button>
                            </div>
                            <div className="modal fade" id="newinstitution" tabindex="-1" aria-labelledby="Institution" aria-hidden="true">
                                <div className="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
                                    <div className="modal-content">
                                        <div className="modal-header">
                                            <h5 className="modal-title" id="Institution">New User</h5>
                                            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div className="modal-body">
                                            <SignUp refreshUsers={allDetails} />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </>
    )
}

export default UserManagement;