import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import SignIn from './forms/SignIn/SignIn';
import Dashboard from './forms/Dashboard';
import ViewFiIdDetails from './forms/ViewDetails';
import UpdateFinancialInstitution from './forms/updateDetails/updateFinancialInstitution';
import UpdatedTransactionForm from './forms/updateDetails/updateTransactioncapbality';
import EditAccounts1 from './forms/EditAccountsTypes';
import ViewAccountType from './forms/ViewAccountType';
import AddAccountType from './forms/AddAccountType';
import AddDataForm from './forms/appProperties/AddDataForm';
import EditDataForm from './forms/appProperties/EditDataForm';
import ViewData from './forms/appProperties/ViewData';
import CoreConnectivityDetails from './forms/CoreConnectivityDetails';
import '@fortawesome/fontawesome-free/css/all.min.css';
import { UserContextProvider, UserContext } from './UserContextProvider';
import ForgotPassword from './forms/SignIn/forgotPassword';


export const userContext = React.createContext();

function App() {
  const [isLogin, setIsLogin] = useState(true);
  const [userLoggedIn, setUserLoggedIn] = useState(false);
  const [loggedInUser, setLoggedInUser] = useState("");
  const [usersData, setUsersData] = useState([]);
  const [loginUserName, setLoginUserName] = useState('');
  return (
    <userContext.Provider
      value={{
        usersData,
        setUsersData,
        setUserLoggedIn,
        setIsLogin,
        setLoggedInUser,
        userLoggedIn,
        setLoginUserName
      }}
    >
      <Router>
        <AppRoutes isLogin={isLogin} userLoggedIn={userLoggedIn}  loginUserName={loginUserName}/>
        
      </Router>
     </userContext.Provider>

 


  
  );
}

function AppRoutes({ isLogin, userLoggedIn, loginUserName}) {
  const navigate = useNavigate();
  useEffect(() => {
 
    if (!isLogin) {
      navigate('/');
    } else if (!userLoggedIn) {
      navigate('/');
    } else {
      navigate('/dashboard',{ state: { singleUserName: loginUserName } });
    }
  }, [isLogin, userLoggedIn, navigate]);

  return (
    <Routes>
      <Route path='/' element={<SignIn />} />
      <Route path='/dashboard' element={<Dashboard />} />
      <Route path='/viewDetails' element={<ViewFiIdDetails />} />
      <Route path='/updateFiId' element={<UpdateFinancialInstitution />} />
      <Route path='/updateTransactionCapability' element={<UpdatedTransactionForm />} />
      <Route path='/addAccountType' element={<AddAccountType />} />
      <Route path='/view-account-data' element={<ViewAccountType />} />
      <Route path='/editAccounts' element={<EditAccounts1 />} />
      <Route path='/addAppProperties' element={<AddDataForm />} />
      <Route path='/editAppProperties' element={<EditDataForm />} />
      <Route path='/viewAppProperites' element={<ViewData />} />
      <Route path='/forgotPassword' element={<ForgotPassword />} />
    </Routes>
  );
}

export default App;
