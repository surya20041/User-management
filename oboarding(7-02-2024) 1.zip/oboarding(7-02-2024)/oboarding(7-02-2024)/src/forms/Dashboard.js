import React, { useState } from "react";
import './css/app.css'
import dashBoardLogo from '../images/dashBoardLogo.png'
import SearchIng from './AccountType'
import FinancialInstitutionView from "./viewDashboard/FinacialInstitutionView";
import ViewData from "./appProperties/ViewData";
import TransactionDataDetails from "./TransactionDataDetails";

function Dashboard() {
  const [activeSection, setActiveSection] = useState("dashboard");

  const dashboard = () => setActiveSection("dashboard");
  const accountType = () => setActiveSection("account");
  const appProperties = () => setActiveSection("appProperties");
  const transactionData = () => setActiveSection("transactionData");

  return (
    <div className="wrapper">
      <nav id="sidebar" className="sidebar js-sidebar">
        <div className="sidebar-content js-simplebar">
          <a className="sidebar-brand" href="index.html">
            <img src={dashBoardLogo} alt="Dashboard Logo" />
          </a>
          <ul className="sidebar-nav">
            <li className={`sidebar-item ${activeSection === "dashboard" ? "active" : ""}`}>
              <a className="sidebar-link" onClick={dashboard}>
                <i className="align-middle" data-feather="sliders"></i> 
                <span className="align-middle">Financial Institution</span>
              </a>
            </li>
            <li className={`sidebar-item ${activeSection === "account" ? "active" : ""}`}>
              <a className="sidebar-link" onClick={accountType}>
                <i className="align-middle" data-feather="sliders"></i> 
                <span className="align-middle">Accounts</span>
              </a>
            </li>
            <li className={`sidebar-item ${activeSection === "appProperties" ? "active" : ""}`}>
              <a className="sidebar-link" onClick={appProperties}>
                <i className="align-middle" data-feather="sliders"></i> 
                <span className="align-middle">App Properties</span>
              </a>
            </li>
            <li className={`sidebar-item ${activeSection === "transactionData" ? "active" : ""}`}>
              <a className="sidebar-link" onClick={transactionData}>
                <i className="align-middle" data-feather="sliders"></i> 
                <span className="align-middle">Transaction Data</span>
              </a>
            </li>
          </ul>
        </div>
      </nav>
      <div className="main">
        <nav className="navbar navbar-expand navbar-light navbar-bg">
          {/* <a className="sidebar-toggle js-sidebar-toggle">
            <i className="hamburger align-self-center"></i>
          </a> */}
          <div className="navbar-collapse collapse">
            <ul className="navbar-nav navbar-align">
              <li className="nav-item dropdown">
                <a className="nav-icon dropdown-toggle d-inline-block d-sm-none" href="#" data-bs-toggle="dropdown">
                  <i className="align-middle" data-feather="settings"></i>
                </a>
                <a className="nav-link dropdown-toggle d-none d-sm-inline-block" href="#" data-bs-toggle="dropdown">
                  <span className="text-dark">Hi Admin</span>
                </a>
                <div className="dropdown-menu dropdown-menu-end">
                  <a className="dropdown-item" href="#"><i className="align-middle me-1" data-feather="user"></i> Profile</a>
                  <div className="dropdown-divider"></div>
                  <a className="dropdown-item" href="#">Log out</a>
                </div>
              </li>
            </ul>
          </div>
        </nav>
        <main className="content">
          <div className="container-fluid p-0">
            {activeSection === "dashboard" && <FinancialInstitutionView />}
            {activeSection === "account" && <SearchIng />}
            {activeSection === "appProperties" && <ViewData />}
            {activeSection === "transactionData" && <TransactionDataDetails />}
            
          </div>
        </main>
        <footer className="footer">
          <div className="container-fluid">
            <div className="row text-muted">
              <div className="col-12 text-center">
                <p className="mb-0">Admin Dashboard - Techrev Solutions</p>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}

export default Dashboard;
